import { 
  FitnessPlan, 
  MealPlan, 
  FitnessCategory, 
  MealCategory,
  EducationalContent,
  MotivationalContent,
  Exercise,
  DailyMeal,
  Meal,
  FitnessDay
} from '../../types/content';

// Fitness Categories
export const fitnessCategories: FitnessCategory[] = [
  {
    id: '1',
    name: 'Weight Loss',
    description: 'Programs designed to help you shed unwanted pounds through a combination of cardio, strength training, and flexibility exercises.',
    image: 'https://images.pexels.com/photos/4098228/pexels-photo-4098228.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '2',
    name: 'Muscle Building',
    description: 'Focused on building lean muscle mass through progressive resistance training and proper nutrition.',
    image: 'https://images.pexels.com/photos/1229356/pexels-photo-1229356.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '3',
    name: 'General Fitness',
    description: 'Well-rounded programs that improve overall health, endurance, strength, and flexibility.',
    image: 'https://images.pexels.com/photos/6551144/pexels-photo-6551144.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '4',
    name: 'Traditional Ethiopian Dance',
    description: 'Fitness routines that incorporate traditional Ethiopian dance movements for a fun and culturally relevant workout.',
    image: 'https://images.pexels.com/photos/3775566/pexels-photo-3775566.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  }
];

// Sample exercises
const exercises: Exercise[] = [
  {
    id: '1',
    name: 'Squats',
    sets: 3,
    reps: 12,
    description: 'A compound exercise that targets multiple muscle groups including quadriceps, hamstrings, and glutes.',
    image: 'https://images.pexels.com/photos/4162487/pexels-photo-4162487.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '2',
    name: 'Push-ups',
    sets: 3,
    reps: 10,
    description: 'An upper body exercise that strengthens the chest, shoulders, and triceps.',
    image: 'https://images.pexels.com/photos/4162454/pexels-photo-4162454.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '3',
    name: 'Lunges',
    sets: 3,
    reps: 10,
    description: 'A unilateral exercise that targets the quadriceps, hamstrings, and glutes.',
    image: 'https://images.pexels.com/photos/6455824/pexels-photo-6455824.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '4',
    name: 'Plank',
    duration: 30,
    description: 'A core strengthening exercise that also engages the shoulders, arms, and glutes.',
    image: 'https://images.pexels.com/photos/6740056/pexels-photo-6740056.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '5',
    name: 'Eskista (Ethiopian Shoulder Dance)',
    duration: 15,
    description: 'Traditional Ethiopian dance that focuses on rapid shoulder movements, providing a cardiovascular workout.',
    image: 'https://images.pexels.com/photos/3775566/pexels-photo-3775566.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '6',
    name: 'Jumping Jacks',
    duration: 2,
    description: 'A full-body cardiovascular exercise that also improves coordination.',
    image: 'https://images.pexels.com/photos/4162507/pexels-photo-4162507.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '7',
    name: 'Mountain Climbers',
    duration: 1,
    description: 'A dynamic exercise that targets the core, shoulders, and legs while raising your heart rate.',
    image: 'https://images.pexels.com/photos/6551255/pexels-photo-6551255.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '8',
    name: 'Dumbbell Rows',
    sets: 3,
    reps: 12,
    description: 'A back exercise that also engages the biceps and shoulders.',
    image: 'https://images.pexels.com/photos/4162451/pexels-photo-4162451.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  }
];

// Sample fitness days
const fitnessDays: FitnessDay[] = [
  {
    day: 1,
    exercises: [exercises[0], exercises[1], exercises[3], exercises[5]],
    restDay: false
  },
  {
    day: 2,
    exercises: [exercises[2], exercises[7], exercises[4], exercises[6]],
    restDay: false
  },
  {
    day: 3,
    exercises: [],
    restDay: true
  },
  {
    day: 4,
    exercises: [exercises[0], exercises[1], exercises[3], exercises[6]],
    restDay: false
  },
  {
    day: 5,
    exercises: [exercises[2], exercises[7], exercises[4], exercises[5]],
    restDay: false
  },
  {
    day: 6,
    exercises: [],
    restDay: true
  },
  {
    day: 7,
    exercises: [exercises[0], exercises[1], exercises[2], exercises[3], exercises[4]],
    restDay: false
  }
];

// Fitness Plans
export const fitnessPlans: FitnessPlan[] = [
  {
    id: '1',
    title: 'Ethiopian Beginner Weight Loss Program',
    description: 'A gentle introduction to fitness designed for Ethiopians looking to lose weight in a culturally appropriate way. This program combines traditional dance movements with modern exercise techniques.',
    categoryId: '1',
    level: 'beginner',
    duration: 4,
    schedule: fitnessDays,
    createdBy: '1',
    image: 'https://images.pexels.com/photos/4098036/pexels-photo-4098036.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '2',
    title: 'Traditional Strength Builder',
    description: 'Build muscle and strength with this program that incorporates traditional Ethiopian movements with proven strength training exercises.',
    categoryId: '2',
    level: 'intermediate',
    duration: 8,
    schedule: fitnessDays,
    createdBy: '1',
    image: 'https://images.pexels.com/photos/6551076/pexels-photo-6551076.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '3',
    title: 'Eskista Cardio',
    description: 'A high-energy cardio program based on the traditional Ethiopian shoulder dance, Eskista. This program will improve your cardiovascular health while connecting you with cultural dance traditions.',
    categoryId: '4',
    level: 'beginner',
    duration: 6,
    schedule: fitnessDays,
    createdBy: '1',
    image: 'https://images.pexels.com/photos/3775566/pexels-photo-3775566.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '4',
    title: 'Holistic Wellness Program',
    description: 'A balanced fitness program that improves overall health, combining strength, flexibility, and cardiovascular exercises with traditional Ethiopian movement patterns.',
    categoryId: '3',
    level: 'intermediate',
    duration: 12,
    schedule: fitnessDays,
    createdBy: '1',
    image: 'https://images.pexels.com/photos/6551095/pexels-photo-6551095.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  }
];

// Meal Categories
export const mealCategories: MealCategory[] = [
  {
    id: '1',
    name: 'Weight Loss',
    description: 'Low-calorie meal plans featuring Ethiopian foods to support your weight loss goals.',
    image: 'https://images.pexels.com/photos/5938/food-salad-healthy-lunch.jpg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '2',
    name: 'Muscle Building',
    description: 'Protein-rich Ethiopian meals to support muscle growth and recovery.',
    image: 'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '3',
    name: 'Balanced Nutrition',
    description: 'Well-rounded meal plans featuring traditional Ethiopian foods for overall health.',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  },
  {
    id: '4',
    name: 'Vegetarian',
    description: 'Plant-based Ethiopian meal plans rich in proteins and essential nutrients.',
    image: 'https://images.pexels.com/photos/1414651/pexels-photo-1414651.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750'
  }
];

// Sample meals
const ethiopianMeals: Meal[] = [
  {
    id: '1',
    name: 'Injera with Misir Wot',
    description: 'Fermented flatbread served with spiced red lentil stew.',
    ingredients: ['Teff flour', 'Water', 'Red lentils', 'Onions', 'Garlic', 'Berbere spice', 'Vegetable oil'],
    nutritionInfo: {
      calories: 320,
      protein: 12,
      carbs: 54,
      fat: 6,
      fiber: 10
    },
    preparationTime: 30,
    cookingTime: 45,
    servings: 2,
    image: 'https://images.pexels.com/photos/5949885/pexels-photo-5949885.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    isEthiopian: true
  },
  {
    id: '2',
    name: 'Doro Wat',
    description: 'Spicy chicken stew that is rich in protein.',
    ingredients: ['Chicken', 'Onions', 'Garlic', 'Ginger', 'Berbere spice', 'Eggs', 'Clarified butter'],
    nutritionInfo: {
      calories: 420,
      protein: 35,
      carbs: 18,
      fat: 24,
      fiber: 3
    },
    preparationTime: 40,
    cookingTime: 90,
    servings: 4,
    image: 'https://images.pexels.com/photos/7363671/pexels-photo-7363671.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    isEthiopian: true
  },
  {
    id: '3',
    name: 'Gomen (Collard Greens)',
    description: 'Nutritious collard greens sautéed with spices.',
    ingredients: ['Collard greens', 'Onions', 'Garlic', 'Green chilies', 'Vegetable oil', 'Spices'],
    nutritionInfo: {
      calories: 130,
      protein: 4,
      carbs: 12,
      fat: 8,
      fiber: 6
    },
    preparationTime: 15,
    cookingTime: 25,
    servings: 4,
    image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    isEthiopian: true
  },
  {
    id: '4',
    name: 'Shiro (Chickpea Stew)',
    description: 'A thick, spicy stew made from ground chickpeas or broad bean meal.',
    ingredients: ['Chickpea flour', 'Onions', 'Garlic', 'Tomatoes', 'Berbere spice', 'Vegetable oil'],
    nutritionInfo: {
      calories: 280,
      protein: 14,
      carbs: 40,
      fat: 7,
      fiber: 12
    },
    preparationTime: 10,
    cookingTime: 30,
    servings: 4,
    image: 'https://images.pexels.com/photos/604969/pexels-photo-604969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    isEthiopian: true
  },
  {
    id: '5',
    name: 'Kitfo',
    description: 'Minced raw beef seasoned with spices and clarified butter.',
    ingredients: ['Lean beef', 'Mitmita (spice blend)', 'Clarified butter', 'Cottage cheese', 'Collard greens'],
    nutritionInfo: {
      calories: 380,
      protein: 32,
      carbs: 2,
      fat: 28,
      fiber: 0
    },
    preparationTime: 20,
    cookingTime: 5,
    servings: 2,
    image: 'https://images.pexels.com/photos/4559180/pexels-photo-4559180.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    isEthiopian: true
  },
  {
    id: '6',
    name: 'Tibs (Sautéed Meat)',
    description: 'Sautéed meat dishes (usually beef) cooked with vegetables and spices.',
    ingredients: ['Beef', 'Onions', 'Tomatoes', 'Jalapeño peppers', 'Rosemary', 'Vegetable oil'],
    nutritionInfo: {
      calories: 350,
      protein: 30,
      carbs: 10,
      fat: 22,
      fiber: 2
    },
    preparationTime: 15,
    cookingTime: 20,
    servings: 3,
    image: 'https://images.pexels.com/photos/1604653/pexels-photo-1604653.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    isEthiopian: true
  }
];

// Sample daily meals
const dailyMeals: DailyMeal[] = [
  {
    day: 1,
    breakfast: [ethiopianMeals[3]],
    lunch: [ethiopianMeals[0], ethiopianMeals[2]],
    dinner: [ethiopianMeals[1]],
    snacks: [],
    totalCalories: 1000
  },
  {
    day: 2,
    breakfast: [ethiopianMeals[3]],
    lunch: [ethiopianMeals[5], ethiopianMeals[2]],
    dinner: [ethiopianMeals[0]],
    snacks: [],
    totalCalories: 950
  },
  {
    day: 3,
    breakfast: [ethiopianMeals[0]],
    lunch: [ethiopianMeals[2], ethiopianMeals[3]],
    dinner: [ethiopianMeals[5]],
    snacks: [],
    totalCalories: 1050
  },
  {
    day: 4,
    breakfast: [ethiopianMeals[3]],
    lunch: [ethiopianMeals[0]],
    dinner: [ethiopianMeals[4], ethiopianMeals[2]],
    snacks: [],
    totalCalories: 1100
  },
  {
    day: 5,
    breakfast: [ethiopianMeals[0]],
    lunch: [ethiopianMeals[3], ethiopianMeals[2]],
    dinner: [ethiopianMeals[1]],
    snacks: [],
    totalCalories: 1000
  },
  {
    day: 6,
    breakfast: [ethiopianMeals[3]],
    lunch: [ethiopianMeals[5]],
    dinner: [ethiopianMeals[0], ethiopianMeals[2]],
    snacks: [],
    totalCalories: 980
  },
  {
    day: 7,
    breakfast: [ethiopianMeals[3]],
    lunch: [ethiopianMeals[2], ethiopianMeals[0]],
    dinner: [ethiopianMeals[1]],
    snacks: [],
    totalCalories: 1020
  }
];

// Meal Plans
export const mealPlans: MealPlan[] = [
  {
    id: '1',
    title: 'Ethiopian Weight Loss Meal Plan',
    description: 'A nutritious and delicious meal plan featuring traditional Ethiopian dishes, designed to help you lose weight while enjoying the flavors you love.',
    categoryId: '1',
    duration: 7,
    meals: dailyMeals,
    createdBy: '2',
    image: 'https://images.pexels.com/photos/5938/food-salad-healthy-lunch.jpg?auto=compress&cs=tinysrgb&w=1260&h=750',
    calorieRange: {
      min: 1200,
      max: 1500
    }
  },
  {
    id: '2',
    title: 'Ethiopian Muscle Building Diet',
    description: 'A high-protein meal plan featuring Ethiopian dishes to support muscle growth and recovery after your workouts.',
    categoryId: '2',
    duration: 7,
    meals: dailyMeals,
    createdBy: '2',
    image: 'https://images.pexels.com/photos/1640770/pexels-photo-1640770.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    calorieRange: {
      min: 2000,
      max: 2500
    }
  },
  {
    id: '3',
    title: 'Traditional Ethiopian Balanced Diet',
    description: 'A well-rounded meal plan featuring traditional Ethiopian foods to support your overall health and wellness.',
    categoryId: '3',
    duration: 7,
    meals: dailyMeals,
    createdBy: '2',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    calorieRange: {
      min: 1800,
      max: 2200
    }
  },
  {
    id: '4',
    title: 'Ethiopian Vegetarian Plan',
    description: 'A plant-based meal plan featuring traditional Ethiopian vegetarian dishes that are rich in protein and essential nutrients.',
    categoryId: '4',
    duration: 7,
    meals: dailyMeals,
    createdBy: '2',
    image: 'https://images.pexels.com/photos/1414651/pexels-photo-1414651.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    calorieRange: {
      min: 1600,
      max: 2000
    }
  }
];

// Educational Content
export const educationalContent: EducationalContent[] = [
  {
    id: '1',
    title: 'The Nutritional Benefits of Teff',
    content: `Teff, the tiny grain used to make injera (Ethiopian flatbread), is a nutritional powerhouse. Here's why you should include it in your diet:

    1. Rich in Essential Nutrients: Teff contains important minerals like iron, calcium, and magnesium.
    
    2. High in Protein: Teff provides all essential amino acids, making it a complete protein source.
    
    3. Gluten-Free: Naturally gluten-free, teff is suitable for those with celiac disease or gluten sensitivity.
    
    4. High in Fiber: Helps with digestion and provides a feeling of fullness.
    
    5. Low Glycemic Index: Causes a slower rise in blood sugar, beneficial for managing diabetes.
    
    6. Rich in Antioxidants: Contains polyphenols and phytates that help combat oxidative stress.
    
    Incorporating teff into your diet can be as simple as enjoying traditional injera or adding teff flour to baked goods. Its mild, nutty flavor makes it versatile for many recipes.`,
    category: 'nutrition',
    image: 'https://images.pexels.com/photos/3758598/pexels-photo-3758598.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    createdAt: '2023-04-15T10:30:00Z',
    author: 'Nutritionist Team'
  },
  {
    id: '2',
    title: 'Incorporating Traditional Ethiopian Movement into Modern Fitness',
    content: `Ethiopian traditional dances and movements can be excellent forms of exercise. Here's how to incorporate them into your modern fitness routine:

    1. Eskista (Shoulder Dance): This energetic dance primarily involves rapid shoulder movements. Practicing Eskista for 15-20 minutes can be an excellent cardiovascular workout that also strengthens your upper body.
    
    2. Tigrigna Dance: The jumping and squatting movements in Tigrigna dances are perfect for lower body strength training.
    
    3. Gurage Dance: The fast-paced footwork provides an excellent cardio workout while improving coordination.
    
    4. Movement Integration: Even if you're following a standard workout routine, you can incorporate Ethiopian dance movements as warm-up exercises or between strength training sets.
    
    5. Music Motivation: Traditional Ethiopian music can be motivating during workouts, helping you maintain rhythm and energy.
    
    6. Cultural Connection: Connecting with traditional movements provides not just physical benefits but also a meaningful cultural connection.
    
    Remember to start slowly if you're new to these movements, and gradually increase intensity as your fitness level improves.`,
    category: 'fitness',
    image: 'https://images.pexels.com/photos/3775566/pexels-photo-3775566.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    createdAt: '2023-05-02T14:45:00Z',
    author: 'Fitness Team'
  },
  {
    id: '3',
    title: 'Balancing Traditional Ethiopian Diet with Modern Nutrition Science',
    content: `Ethiopian cuisine is rich in flavors and tradition, but how does it align with modern nutrition principles? Here's a guide to enjoying Ethiopian food while optimizing your health:

    1. Portion Control with Injera: While injera is nutritious, it's also calorie-dense. Consider using smaller pieces as your base.
    
    2. Vegetable Wats (Stews): Ethiopian cuisine offers many vegetable-based wats like misir (lentils), kik (split peas), and gomen (collard greens). These are rich in protein, fiber, and micronutrients.
    
    3. Reducing Oil: Traditional wats can be high in oil. You can reduce the oil while cooking at home without sacrificing flavor.
    
    4. Protein Sources: Beyond meat dishes like doro wat (chicken stew) and kitfo (minced beef), explore plant-based proteins like shiro (chickpea stew).
    
    5. Spice Benefits: Ethiopian berbere spice blend contains capsaicin, which may boost metabolism and has anti-inflammatory properties.
    
    6. Fermentation Benefits: Injera's fermentation process increases nutrient availability and supports gut health.
    
    7. Fasting Traditions: Ethiopian Orthodox fasting periods (which are plant-based) align well with modern recommendations for occasional plant-focused eating.
    
    By making mindful choices, you can honor traditional Ethiopian culinary practices while meeting modern nutritional needs.`,
    category: 'nutrition',
    image: 'https://images.pexels.com/photos/5510098/pexels-photo-5510098.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    createdAt: '2023-06-10T09:15:00Z',
    author: 'Nutritionist Team'
  },
  {
    id: '4',
    title: 'Mental Health Benefits of Regular Exercise',
    content: `Exercise isn't just good for your physical health—it has profound effects on mental wellbeing as well. Here's how staying active can support your mental health:

    1. Stress Reduction: Physical activity reduces levels of stress hormones like cortisol and adrenaline while stimulating endorphin production.
    
    2. Anxiety Management: Regular exercise has been shown to decrease symptoms of anxiety, with effects sometimes comparable to medication.
    
    3. Depression Relief: Studies indicate that consistent exercise can be as effective as antidepressants for mild to moderate depression in some individuals.
    
    4. Cognitive Function: Exercise improves blood flow to the brain, enhancing cognitive function and potentially reducing the risk of dementia.
    
    5. Sleep Improvement: Regular physical activity helps regulate sleep patterns, addressing insomnia and improving sleep quality.
    
    6. Self-Esteem Boost: Achieving fitness goals, no matter how small, can significantly improve self-confidence and body image.
    
    7. Social Connection: Group fitness activities provide opportunities for social interaction, countering isolation and loneliness.
    
    8. Emotional Regulation: Exercise can serve as a healthy coping mechanism for processing difficult emotions.
    
    Remember that consistency is more important than intensity. Even moderate activity like walking for 30 minutes daily can provide significant mental health benefits.`,
    category: 'mental-health',
    image: 'https://images.pexels.com/photos/4098366/pexels-photo-4098366.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    createdAt: '2023-07-22T11:20:00Z',
    author: 'Fitness Team'
  }
];

// Motivational Content
export const motivationalContent: MotivationalContent[] = [
  {
    id: '1',
    title: 'Finding Strength in Ethiopian Endurance Traditions',
    content: `Ethiopia has a rich history of endurance athletics, producing some of the world's greatest long-distance runners. This tradition of excellence stems from a cultural mindset that values perseverance, consistency, and mental fortitude.

    When facing your own fitness challenges, remember the spirit of Ethiopian runners who train at high altitudes with limited resources, yet achieve remarkable results through unwavering dedication. Their success isn't just about natural talent—it's about the daily commitment to improvement regardless of circumstances.
    
    As the Ethiopian proverb says, "Little by little, an egg will walk." This wisdom reminds us that progress comes through consistent small efforts accumulated over time. You don't need to transform overnight; each workout and healthy meal is a step toward your goals.
    
    Embrace the Ethiopian athletic mindset: focus on the process rather than immediate results, cultivate mental toughness during challenging workouts, and find joy in the discipline of daily practice. Whether you're just beginning your fitness journey or pushing through a plateau, let Ethiopia's tradition of excellence inspire your own path to wellness.`,
    image: 'https://images.pexels.com/photos/4033146/pexels-photo-4033146.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    createdAt: '2023-08-05T08:30:00Z',
    author: 'Motivation Team'
  },
  {
    id: '2',
    title: 'The Journey of a Thousand Miles Begins with One Step',
    content: `When beginning your fitness journey, the distance between where you are and where you want to be can seem overwhelming. The good news? You don't have to travel the entire distance today.

    An Ethiopian farmer doesn't harvest before planting seeds. Similarly, your fitness results will come after consistent effort. The most important step is the one you take today, however small it might seem.
    
    Remember that even Ethiopia's world-class athletes began with basic training. They didn't become champions overnight but through years of incremental improvement. Your journey follows the same principle: progressive steps leading to transformative change.
    
    On days when motivation wanes, recall the Ethiopian concept of "chuchu," the persistent spirit that keeps you moving forward despite obstacles. This resilience has helped generations of Ethiopians overcome challenges, and it can fuel your fitness journey too.
    
    Don't measure your progress against others but against your yesterday self. Celebrate small victories—completing one more repetition, making a healthier food choice, or simply showing up when you didn't feel like it. These moments of perseverance build the foundation for lasting change.
    
    As you continue your wellness journey, embrace the wisdom found in the Ethiopian coffee ceremony: take time to pause, connect with your purpose, and appreciate the process itself. The path to health is not just about the destination but about transforming your relationship with your body and mind along the way.`,
    image: 'https://images.pexels.com/photos/235922/pexels-photo-235922.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    createdAt: '2023-09-18T15:45:00Z',
    author: 'Motivation Team'
  },
  {
    id: '3',
    title: 'The Power of Community in Achieving Your Health Goals',
    content: `In Ethiopian culture, the concept of "debo" refers to community members coming together to help each other with difficult tasks. This principle of collective support and mutual encouragement holds valuable lessons for your fitness journey.

    Research consistently shows that those with strong social support are more likely to adhere to exercise programs and achieve their health goals. When you connect with others who share your wellness aspirations, you gain accountability partners, cheerleaders, and sources of wisdom.
    
    In Ethiopia, important life events are rarely celebrated alone—they're community experiences. Similarly, sharing your fitness milestones with others amplifies their significance and provides motivation to continue. Don't hesitate to acknowledge your progress and allow others to celebrate with you.
    
    During challenging phases of your journey, remember the Ethiopian proverb: "When spider webs unite, they can tie up a lion." The combined encouragement of a supportive community can help you overcome obstacles that might seem insurmountable when faced alone.
    
    Consider finding or creating your own "fitness debo"—whether through group classes, online communities, or workout partners. By supporting others and allowing yourself to be supported, you create a positive cycle of motivation that benefits everyone involved.
    
    As you progress, look for opportunities to mentor those beginning their own health journeys. In Ethiopian tradition, sharing knowledge is considered a responsibility. By guiding others, you not only reinforce your own commitment but also contribute to a healthier community—a true win-win.`,
    image: 'https://images.pexels.com/photos/6551176/pexels-photo-6551176.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    createdAt: '2023-10-22T13:10:00Z',
    author: 'Motivation Team'
  },
  {
    id: '4',
    title: 'Finding Balance: Wisdom from Ethiopian Traditions',
    content: `Ethiopian culture has long emphasized balance and moderation as keys to a fulfilling life. This wisdom is particularly relevant to modern fitness journeys, where sustainability matters more than short-term extremes.

    Consider the Ethiopian meal tradition of gursha—sharing food from a common plate, taking what you need without excess. This principle applies beautifully to nutrition: eat mindfully, take what your body needs, and find pleasure in nourishment without overindulgence.
    
    In Ethiopian Orthodox tradition, fasting periods are balanced with celebrations. This rhythm recognizes the importance of both discipline and joy. Your fitness journey should similarly include both structured commitment and moments of flexibility and celebration.
    
    When pursuing your health goals, remember the concept of "fetha"—justice or fairness—but apply it to how you treat yourself. Be disciplined but not punitive. Missed workouts or imperfect eating days aren't moral failures but natural parts of a balanced journey.
    
    Ethiopian coffee ceremonies teach the value of intentional breaks and mindful presence. In your fitness routine, incorporate recovery periods and mindfulness practices that allow your body and mind to integrate the benefits of your efforts.
    
    As the Ethiopian proverb states, "The one who has patience will have what they want." Sustainable transformation comes through balanced, consistent habits maintained over time, not through unsustainable extremes that lead to burnout.
    
    Embrace this balanced approach to wellness—one that honors both discipline and self-compassion, effort and recovery, tradition and innovation. This middle path is where lasting health thrives.`,
    image: 'https://images.pexels.com/photos/5836780/pexels-photo-5836780.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
    createdAt: '2023-11-14T10:25:00Z',
    author: 'Motivation Team'
  }
];