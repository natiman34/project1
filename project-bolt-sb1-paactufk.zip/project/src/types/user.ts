export enum UserRole {
  USER = 'user',
  ADMIN_SUPER = 'admin_super',
  ADMIN_NUTRITIONIST = 'admin_nutritionist',
  ADMIN_FITNESS = 'admin_fitness',
}

export interface BMIResult {
  id: string;
  height: number;
  weight: number;
  bmi: number;
  category: string;
  date: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  bmiResults: BMIResult[];
  createdAt: string;
  image?: string;
}

export interface AdminUser extends User {
  specialization?: string;
  bio?: string;
}