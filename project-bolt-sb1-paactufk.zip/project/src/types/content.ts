export interface FitnessCategory {
  id: string;
  name: string;
  description: string;
  image: string;
}

export interface FitnessPlan {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  duration: number; // in weeks
  schedule: FitnessDay[];
  createdBy: string; // admin id
  image: string;
}

export interface FitnessDay {
  day: number;
  exercises: Exercise[];
  restDay: boolean;
}

export interface Exercise {
  id: string;
  name: string;
  sets?: number;
  reps?: number;
  duration?: number; // in minutes
  description: string;
  image?: string;
  videoUrl?: string;
}

export interface MealCategory {
  id: string;
  name: string;
  description: string;
  image: string;
}

export interface MealPlan {
  id: string;
  title: string;
  description: string;
  categoryId: string;
  duration: number; // in days
  meals: DailyMeal[];
  createdBy: string; // admin id
  image: string;
  calorieRange: {
    min: number;
    max: number;
  };
}

export interface DailyMeal {
  day: number;
  breakfast: Meal[];
  lunch: Meal[];
  dinner: Meal[];
  snacks: Meal[];
  totalCalories: number;
}

export interface Meal {
  id: string;
  name: string;
  description: string;
  ingredients: string[];
  nutritionInfo: NutritionInfo;
  preparationTime: number; // in minutes
  cookingTime: number; // in minutes
  servings: number;
  image: string;
  isEthiopian: boolean;
  recipe?: string;
}

export interface NutritionInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber?: number;
  sugar?: number;
}

export interface Testimonial {
  id: string;
  name: string;
  message: string;
  photo?: string;
  rating: number;
  date: string;
}

export interface Feedback {
  id: string;
  userId?: string;
  name: string;
  email: string;
  message: string;
  date: string;
  resolved: boolean;
}

export interface EducationalContent {
  id: string;
  title: string;
  content: string;
  category: 'nutrition' | 'fitness' | 'mental-health';
  image?: string;
  createdAt: string;
  author: string;
}

export interface MotivationalContent {
  id: string;
  title: string;
  content: string;
  image?: string;
  createdAt: string;
  author: string;
}