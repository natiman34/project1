import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FitnessPlan, FitnessCategory } from '../../types/content';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

interface FitnessPlansProps {
  categories: FitnessCategory[];
  plans: FitnessPlan[];
}

const FitnessPlans: React.FC<FitnessPlansProps> = ({ categories, plans }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const navigate = useNavigate();
  
  const filteredPlans = plans.filter((plan) => {
    return (
      (selectedCategory === 'all' || plan.categoryId === selectedCategory) &&
      (selectedLevel === 'all' || plan.level === selectedLevel)
    );
  });
  
  const getCategoryName = (categoryId: string) => {
    const category = categories.find((cat) => cat.id === categoryId);
    return category ? category.name : '';
  };
  
  const handleViewPlan = (planId: string) => {
    navigate(`/services/fitness/${planId}`);
  };
  
  return (
    <div>
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Fitness Plans</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Discover our culturally tailored fitness programs designed by Ethiopian experts to help you achieve your goals
        </p>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <h2 className="text-lg font-semibold mb-4">Filter Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
              Category
            </label>
            <select
              id="category"
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="all">All Categories</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="level" className="block text-sm font-medium text-gray-700 mb-1">
              Difficulty Level
            </label>
            <select
              id="level"
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
              value={selectedLevel}
              onChange={(e) => setSelectedLevel(e.target.value)}
            >
              <option value="all">All Levels</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Fitness Categories */}
      {selectedCategory === 'all' && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Fitness Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Card key={category.id} hover>
                <Card.Image 
                  src={category.image} 
                  alt={category.name}
                  className="h-48"
                />
                <Card.Body>
                  <Card.Title className="mb-2">{category.name}</Card.Title>
                  <p className="text-gray-600 text-sm mb-4">
                    {category.description}
                  </p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    View Plans
                  </Button>
                </Card.Body>
              </Card>
            ))}
          </div>
        </div>
      )}
      
      {/* Fitness Plans */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          {selectedCategory !== 'all' 
            ? `${getCategoryName(selectedCategory)} Plans` 
            : 'All Fitness Plans'}
        </h2>
        
        {filteredPlans.length === 0 ? (
          <div className="bg-white rounded-lg p-8 text-center">
            <p className="text-gray-600">No plans found matching your criteria.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => {
                setSelectedCategory('all');
                setSelectedLevel('all');
              }}
            >
              Reset Filters
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPlans.map((plan) => (
              <Card key={plan.id} hover className="h-full">
                <Card.Image 
                  src={plan.image} 
                  alt={plan.title}
                  className="h-48"
                />
                <Card.Body>
                  <div className="flex justify-between items-start mb-2">
                    <Card.Title>{plan.title}</Card.Title>
                    <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                      plan.level === 'beginner' 
                        ? 'bg-green-100 text-green-800' 
                        : plan.level === 'intermediate' 
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-red-100 text-red-800'
                    }`}>
                      {plan.level.charAt(0).toUpperCase() + plan.level.slice(1)}
                    </span>
                  </div>
                  
                  <p className="text-sm text-gray-500 mb-2">
                    {getCategoryName(plan.categoryId)} • {plan.duration} weeks
                  </p>
                  
                  <p className="text-gray-600 mb-4 line-clamp-3">
                    {plan.description}
                  </p>
                  
                  <Button 
                    variant="primary"
                    fullWidth
                    onClick={() => handleViewPlan(plan.id)}
                  >
                    View Plan
                  </Button>
                </Card.Body>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default FitnessPlans;