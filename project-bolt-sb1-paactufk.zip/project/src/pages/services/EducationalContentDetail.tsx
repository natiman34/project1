import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { EducationalContent } from '../../types/content';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { Share2, ArrowLeft, BookOpen, Clock } from 'lucide-react';

interface EducationalContentDetailProps {
  content: EducationalContent[];
}

const EducationalContentDetail: React.FC<EducationalContentDetailProps> = ({ content }) => {
  const { id } = useParams<{ id: string }>();
  const [article, setArticle] = useState<EducationalContent | null>(null);
  const [relatedArticles, setRelatedArticles] = useState<EducationalContent[]>([]);
  
  useEffect(() => {
    if (id) {
      const foundArticle = content.find((c) => c.id === id);
      
      if (foundArticle) {
        setArticle(foundArticle);
        
        // Get related articles in the same category (excluding current one)
        const related = content
          .filter((c) => c.id !== id && c.category === foundArticle.category)
          .slice(0, 3);
        
        setRelatedArticles(related);
      }
    }
  }, [id, content]);
  
  if (!article) {
    return (
      <div className="text-center py-20">
        <p className="text-gray-600">Article not found</p>
      </div>
    );
  }
  
  // Format the article content with paragraphs
  const formattedContent = article.content.split('\n\n').map((paragraph, index) => (
    <p key={index} className="mb-6">{paragraph}</p>
  ));
  
  // Determine category color
  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'nutrition':
        return 'bg-green-100 text-green-800';
      case 'fitness':
        return 'bg-blue-100 text-blue-800';
      case 'mental-health':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  // Determine category name
  const getCategoryName = (category: string) => {
    switch (category) {
      case 'nutrition':
        return 'Nutrition';
      case 'fitness':
        return 'Fitness';
      case 'mental-health':
        return 'Mental Health';
      default:
        return 'General';
    }
  };
  
  // Calculate reading time (roughly 200 words per minute)
  const readingTime = Math.max(1, Math.ceil(article.content.split(' ').length / 200));
  
  return (
    <div>
      {/* Back Link */}
      <div className="mb-6">
        <Link 
          to="/services/education" 
          className="inline-flex items-center text-green-600 hover:text-green-700"
        >
          <ArrowLeft size={16} className="mr-1" />
          Back to all resources
        </Link>
      </div>
      
      {/* Article Header */}
      <div className="mb-8">
        <span className={`inline-block mb-4 px-3 py-1 rounded-full text-xs font-medium ${getCategoryColor(article.category)}`}>
          {getCategoryName(article.category)}
        </span>
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{article.title}</h1>
        <div className="flex flex-wrap items-center text-gray-600 text-sm gap-y-2">
          <span>By {article.author}</span>
          <span className="mx-2">•</span>
          <span>{new Date(article.createdAt).toLocaleDateString()}</span>
          <span className="mx-2">•</span>
          <span className="flex items-center">
            <Clock size={14} className="mr-1" />
            {readingTime} min read
          </span>
        </div>
      </div>
      
      {/* Featured Image */}
      <div className="mb-8 rounded-xl overflow-hidden">
        <img 
          src={article.image} 
          alt={article.title} 
          className="w-full h-[400px] object-cover"
        />
      </div>
      
      {/* Article Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="prose prose-lg max-w-none">
            {formattedContent}
          </div>
          
          {/* Share Section */}
          <div className="mt-10 pt-6 border-t">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-gray-900">Share this article</h3>
              </div>
              <div className="flex space-x-3">
                <button className="p-2 rounded-full bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.63 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"></path>
                  </svg>
                </button>
                <button className="p-2 rounded-full bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors">
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                    <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84"></path>
                  </svg>
                </button>
                <button className="p-2 rounded-full bg-green-50 text-green-600 hover:bg-green-100 transition-colors">
                  <Share2 size={20} />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Sidebar */}
        <div>
          {/* Table of Contents */}
          <Card className="mb-6">
            <Card.Body>
              <div className="flex items-center mb-4">
                <BookOpen size={18} className="text-green-600 mr-2" />
                <h3 className="font-semibold text-lg">Quick Summary</h3>
              </div>
              
              <div className="pl-4 border-l-2 border-green-200">
                <p className="text-gray-600 text-sm leading-relaxed">
                  This article explores {article.title.toLowerCase()}, providing key insights on 
                  how this knowledge can benefit your health journey through an Ethiopian cultural perspective.
                </p>
              </div>
            </Card.Body>
          </Card>
          
          {/* Related Articles */}
          {relatedArticles.length > 0 && (
            <Card>
              <Card.Body>
                <h3 className="font-semibold text-lg mb-4">Related Articles</h3>
                <div className="space-y-4">
                  {relatedArticles.map((related) => (
                    <div key={related.id} className="flex items-start">
                      <div className="flex-shrink-0 w-16 h-16 rounded overflow-hidden mr-3">
                        <img 
                          src={related.image} 
                          alt={related.title} 
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div>
                        <Link 
                          to={`/services/education/${related.id}`} 
                          className="font-medium text-gray-900 hover:text-green-600 transition-colors line-clamp-2"
                        >
                          {related.title}
                        </Link>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(related.createdAt).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="mt-4">
                  <Link 
                    to={`/services/education?category=${article.category}`}
                    className="text-green-600 hover:text-green-700 text-sm font-medium"
                  >
                    View all {getCategoryName(article.category)} articles →
                  </Link>
                </div>
              </Card.Body>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default EducationalContentDetail;