import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MealPlan, MealCategory } from '../../types/content';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

interface NutritionPlansProps {
  categories: MealCategory[];
  plans: MealPlan[];
}

const NutritionPlans: React.FC<NutritionPlansProps> = ({ categories, plans }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [calorieRange, setCalorieRange] = useState<string>('all');
  const navigate = useNavigate();
  
  const filteredPlans = plans.filter((plan) => {
    if (selectedCategory !== 'all' && plan.categoryId !== selectedCategory) {
      return false;
    }
    
    if (calorieRange !== 'all') {
      if (calorieRange === 'low' && plan.calorieRange.max > 1500) {
        return false;
      } else if (calorieRange === 'medium' && (plan.calorieRange.min < 1500 || plan.calorieRange.max > 2000)) {
        return false;
      } else if (calorieRange === 'high' && plan.calorieRange.min < 2000) {
        return false;
      }
    }
    
    return true;
  });
  
  const getCategoryName = (categoryId: string) => {
    const category = categories.find((cat) => cat.id === categoryId);
    return category ? category.name : '';
  };
  
  const handleViewPlan = (planId: string) => {
    navigate(`/services/nutrition/${planId}`);
  };
  
  return (
    <div>
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Nutrition Plans</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Discover our balanced meal plans featuring traditional Ethiopian foods to support your health goals
        </p>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <h2 className="text-lg font-semibold mb-4">Filter Plans</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
              Category
            </label>
            <select
              id="category"
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="all">All Categories</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label htmlFor="calories" className="block text-sm font-medium text-gray-700 mb-1">
              Calorie Range
            </label>
            <select
              id="calories"
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
              value={calorieRange}
              onChange={(e) => setCalorieRange(e.target.value)}
            >
              <option value="all">All Calorie Ranges</option>
              <option value="low">Low Calorie (&lt;1500 kcal)</option>
              <option value="medium">Medium Calorie (1500-2000 kcal)</option>
              <option value="high">High Calorie (&gt;2000 kcal)</option>
            </select>
          </div>
        </div>
      </div>
      
      {/* Meal Categories */}
      {selectedCategory === 'all' && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Meal Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Card key={category.id} hover>
                <Card.Image 
                  src={category.image} 
                  alt={category.name}
                  className="h-48"
                />
                <Card.Body>
                  <Card.Title className="mb-2">{category.name}</Card.Title>
                  <p className="text-gray-600 text-sm mb-4">
                    {category.description}
                  </p>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    View Plans
                  </Button>
                </Card.Body>
              </Card>
            ))}
          </div>
        </div>
      )}
      
      {/* Meal Plans */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          {selectedCategory !== 'all' 
            ? `${getCategoryName(selectedCategory)} Plans` 
            : 'All Meal Plans'}
        </h2>
        
        {filteredPlans.length === 0 ? (
          <div className="bg-white rounded-lg p-8 text-center">
            <p className="text-gray-600">No plans found matching your criteria.</p>
            <Button 
              variant="outline" 
              className="mt-4"
              onClick={() => {
                setSelectedCategory('all');
                setCalorieRange('all');
              }}
            >
              Reset Filters
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPlans.map((plan) => (
              <Card key={plan.id} hover className="h-full">
                <Card.Image 
                  src={plan.image} 
                  alt={plan.title}
                  className="h-48"
                />
                <Card.Body>
                  <div className="flex justify-between items-start mb-2">
                    <Card.Title>{plan.title}</Card.Title>
                  </div>
                  
                  <div className="flex items-center mb-2">
                    <span className="text-sm text-gray-500">
                      {getCategoryName(plan.categoryId)} • {plan.duration} days
                    </span>
                  </div>
                  
                  <div className="mb-3 bg-green-50 text-green-800 text-xs font-medium px-2 py-1 rounded inline-block">
                    {plan.calorieRange.min} - {plan.calorieRange.max} kcal
                  </div>
                  
                  <p className="text-gray-600 mb-4 line-clamp-3">
                    {plan.description}
                  </p>
                  
                  <Button 
                    variant="primary"
                    fullWidth
                    onClick={() => handleViewPlan(plan.id)}
                  >
                    View Plan
                  </Button>
                </Card.Body>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NutritionPlans;