import { useNavigate } from 'react-router-dom';
import { EducationalContent as EducationalContentType } from '../../types/content';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

interface EducationalContentProps {
  content: EducationalContentType[];
}

const EducationalContent: React.FC<EducationalContentProps> = ({ content }) => {
  const navigate = useNavigate();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  const filteredContent = content.filter(
    (article) => selectedCategory === 'all' || article.category === selectedCategory
  );
  
  const handleViewArticle = (contentId: string) => {
    navigate(`/services/education/${contentId}`);
  };
  
  return (
    <div>
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Educational Resources</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Learn about nutrition, fitness, and health through an Ethiopian cultural lens
        </p>
      </div>
      
      {/* Category Filter */}
      <div className="flex justify-center mb-10">
        <div className="inline-flex bg-gray-100 rounded-lg p-1">
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              selectedCategory === 'all'
                ? 'bg-white text-gray-800 shadow'
                : 'text-gray-600 hover:text-gray-800'
            }`}
            onClick={() => setSelectedCategory('all')}
          >
            All Topics
          </button>
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              selectedCategory === 'nutrition'
                ? 'bg-white text-gray-800 shadow'
                : 'text-gray-600 hover:text-gray-800'
            }`}
            onClick={() => setSelectedCategory('nutrition')}
          >
            Nutrition
          </button>
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              selectedCategory === 'fitness'
                ? 'bg-white text-gray-800 shadow'
                : 'text-gray-600 hover:text-gray-800'
            }`}
            onClick={() => setSelectedCategory('fitness')}
          >
            Fitness
          </button>
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              selectedCategory === 'mental-health'
                ? 'bg-white text-gray-800 shadow'
                : 'text-gray-600 hover:text-gray-800'
            }`}
            onClick={() => setSelectedCategory('mental-health')}
          >
            Mental Health
          </button>
        </div>
      </div>
      
      {/* Educational Articles */}
      {filteredContent.length === 0 ? (
        <div className="text-center py-10">
          <p className="text-gray-600">No articles found in this category.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredContent.map((article) => (
            <Card key={article.id} hover className="h-full">
              <Card.Image 
                src={article.image} 
                alt={article.title}
                className="h-48"
              />
              <Card.Body>
                <div className="flex justify-between items-start mb-2">
                  <Card.Title>{article.title}</Card.Title>
                  <span 
                    className={`text-xs font-medium px-2 py-1 rounded-full ${
                      article.category === 'nutrition' 
                        ? 'bg-green-100 text-green-800' 
                        : article.category === 'fitness' 
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-purple-100 text-purple-800'
                    }`}
                  >
                    {article.category === 'nutrition' 
                      ? 'Nutrition' 
                      : article.category === 'fitness' 
                        ? 'Fitness'
                        : 'Mental Health'}
                  </span>
                </div>
                
                <p className="text-sm text-gray-500 mb-3">
                  {new Date(article.createdAt).toLocaleDateString()} • By {article.author}
                </p>
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {article.content.substring(0, 150)}...
                </p>
                <Button 
                  variant="outline"
                  onClick={() => handleViewArticle(article.id)}
                >
                  Read More
                </Button>
              </Card.Body>
            </Card>
          ))}
        </div>
      )}
      
      {/* Search and Request Section */}
      <div className="mt-16 bg-white rounded-xl shadow-sm p-8 md:p-10">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">
              Looking for specific information?
            </h2>
            <p className="text-gray-600">
              Search our resources or request a topic related to Ethiopian health and fitness.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-semibold text-lg mb-3">Search Resources</h3>
              <div className="flex">
                <input
                  type="text"
                  placeholder="Enter keywords..."
                  className="flex-grow px-4 py-2 rounded-l-md border border-gray-300 focus:ring-green-500 focus:border-green-500"
                />
                <button className="bg-green-600 text-white px-4 py-2 rounded-r-md hover:bg-green-700 transition-colors">
                  Search
                </button>
              </div>
            </div>
            
            <div>
              <h3 className="font-semibold text-lg mb-3">Request a Topic</h3>
              <div className="flex">
                <input
                  type="text"
                  placeholder="Suggest a topic..."
                  className="flex-grow px-4 py-2 rounded-l-md border border-gray-300 focus:ring-green-500 focus:border-green-500"
                />
                <button className="bg-green-600 text-white px-4 py-2 rounded-r-md hover:bg-green-700 transition-colors">
                  Submit
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EducationalContent;