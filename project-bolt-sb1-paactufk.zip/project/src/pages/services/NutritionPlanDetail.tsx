import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MealPlan, DailyMeal } from '../../types/content';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { useAuth } from '../../contexts/AuthContext';

interface NutritionPlanDetailProps {
  plans: MealPlan[];
}

const NutritionPlanDetail: React.FC<NutritionPlanDetailProps> = ({ plans }) => {
  const { id } = useParams<{ id: string }>();
  const [plan, setPlan] = useState<MealPlan | null>(null);
  const [selectedDay, setSelectedDay] = useState<number>(1);
  const { currentUser } = useAuth();
  
  useEffect(() => {
    if (id) {
      const foundPlan = plans.find((p) => p.id === id);
      if (foundPlan) {
        setPlan(foundPlan);
      }
    }
  }, [id, plans]);
  
  if (!plan) {
    return (
      <div className="text-center py-20">
        <p className="text-gray-600">Meal plan not found</p>
      </div>
    );
  }
  
  const dayMeal = plan.meals.find((meal) => meal.day === selectedDay);
  
  // Nutrition summary for the selected day
  const nutritionSummary = dayMeal ? {
    calories: dayMeal.totalCalories,
    protein: [...dayMeal.breakfast, ...dayMeal.lunch, ...dayMeal.dinner, ...dayMeal.snacks]
      .reduce((sum, meal) => sum + meal.nutritionInfo.protein, 0),
    carbs: [...dayMeal.breakfast, ...dayMeal.lunch, ...dayMeal.dinner, ...dayMeal.snacks]
      .reduce((sum, meal) => sum + meal.nutritionInfo.carbs, 0),
    fat: [...dayMeal.breakfast, ...dayMeal.lunch, ...dayMeal.dinner, ...dayMeal.snacks]
      .reduce((sum, meal) => sum + meal.nutritionInfo.fat, 0),
  } : null;
  
  return (
    <div>
      {/* Hero Section */}
      <div className="relative rounded-xl overflow-hidden mb-8">
        <div className="absolute inset-0">
          <img 
            src={plan.image} 
            alt={plan.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30"></div>
        </div>
        
        <div className="relative py-16 px-8 text-white">
          <div className="max-w-3xl">
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{plan.title}</h1>
            
            <div className="flex flex-wrap gap-4 mb-6">
              <div className="bg-black/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <span className="text-sm">Duration</span>
                <p className="font-semibold">{plan.duration} Days</p>
              </div>
              
              <div className="bg-black/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <span className="text-sm">Calories</span>
                <p className="font-semibold">{plan.calorieRange.min}-{plan.calorieRange.max} kcal</p>
              </div>
              
              <div className="bg-black/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <span className="text-sm">Meals</span>
                <p className="font-semibold">
                  {dayMeal && (dayMeal.breakfast.length + dayMeal.lunch.length + 
                  dayMeal.dinner.length + dayMeal.snacks.length)} per day
                </p>
              </div>
            </div>
            
            <p className="text-lg">{plan.description}</p>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <Card.Body>
              <h2 className="text-2xl font-bold mb-6">Meal Plan</h2>
              
              {/* Day Selector */}
              <div className="flex flex-wrap gap-2 mb-8">
                {plan.meals.map((meal) => (
                  <button
                    key={meal.day}
                    onClick={() => setSelectedDay(meal.day)}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                      selectedDay === meal.day
                        ? 'bg-green-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Day {meal.day}
                  </button>
                ))}
              </div>
              
              {/* Day Meals */}
              {dayMeal && (
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-semibold">
                      Day {dayMeal.day} Meals
                    </h3>
                    
                    {nutritionSummary && (
                      <div className="text-sm text-gray-700">
                        <span className="font-medium">{nutritionSummary.calories} kcal</span> | 
                        <span className="ml-2">P: {nutritionSummary.protein}g</span> | 
                        <span className="ml-2">C: {nutritionSummary.carbs}g</span> | 
                        <span className="ml-2">F: {nutritionSummary.fat}g</span>
                      </div>
                    )}
                  </div>
                  
                  {/* Breakfast */}
                  <div className="mb-8">
                    <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                      <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full mr-2">
                        Breakfast
                      </span>
                    </h4>
                    
                    <div className="space-y-4">
                      {dayMeal.breakfast.map((meal) => (
                        <div 
                          key={meal.id} 
                          className="border rounded-lg overflow-hidden flex flex-col md:flex-row"
                        >
                          <div className="md:w-1/4">
                            <img 
                              src={meal.image} 
                              alt={meal.name} 
                              className="w-full h-40 object-cover"
                            />
                          </div>
                          <div className="p-4 md:w-3/4">
                            <div className="flex justify-between items-start">
                              <h5 className="text-lg font-semibold">{meal.name}</h5>
                              {meal.isEthiopian && (
                                <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                                  Ethiopian
                                </span>
                              )}
                            </div>
                            
                            <p className="text-gray-600 text-sm mt-1 mb-3">{meal.description}</p>
                            
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Calories</span>
                                <span className="font-medium">{meal.nutritionInfo.calories} kcal</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Protein</span>
                                <span className="font-medium">{meal.nutritionInfo.protein}g</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Carbs</span>
                                <span className="font-medium">{meal.nutritionInfo.carbs}g</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Fat</span>
                                <span className="font-medium">{meal.nutritionInfo.fat}g</span>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap gap-2">
                              {meal.ingredients.slice(0, 5).map((ingredient, idx) => (
                                <span 
                                  key={idx} 
                                  className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded"
                                >
                                  {ingredient}
                                </span>
                              ))}
                              {meal.ingredients.length > 5 && (
                                <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                                  +{meal.ingredients.length - 5} more
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Lunch */}
                  <div className="mb-8">
                    <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                      <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full mr-2">
                        Lunch
                      </span>
                    </h4>
                    
                    <div className="space-y-4">
                      {dayMeal.lunch.map((meal) => (
                        <div 
                          key={meal.id} 
                          className="border rounded-lg overflow-hidden flex flex-col md:flex-row"
                        >
                          <div className="md:w-1/4">
                            <img 
                              src={meal.image} 
                              alt={meal.name} 
                              className="w-full h-40 object-cover"
                            />
                          </div>
                          <div className="p-4 md:w-3/4">
                            <div className="flex justify-between items-start">
                              <h5 className="text-lg font-semibold">{meal.name}</h5>
                              {meal.isEthiopian && (
                                <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                                  Ethiopian
                                </span>
                              )}
                            </div>
                            
                            <p className="text-gray-600 text-sm mt-1 mb-3">{meal.description}</p>
                            
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Calories</span>
                                <span className="font-medium">{meal.nutritionInfo.calories} kcal</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Protein</span>
                                <span className="font-medium">{meal.nutritionInfo.protein}g</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Carbs</span>
                                <span className="font-medium">{meal.nutritionInfo.carbs}g</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Fat</span>
                                <span className="font-medium">{meal.nutritionInfo.fat}g</span>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap gap-2">
                              {meal.ingredients.slice(0, 5).map((ingredient, idx) => (
                                <span 
                                  key={idx} 
                                  className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded"
                                >
                                  {ingredient}
                                </span>
                              ))}
                              {meal.ingredients.length > 5 && (
                                <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                                  +{meal.ingredients.length - 5} more
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Dinner */}
                  <div className="mb-8">
                    <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full mr-2">
                        Dinner
                      </span>
                    </h4>
                    
                    <div className="space-y-4">
                      {dayMeal.dinner.map((meal) => (
                        <div 
                          key={meal.id} 
                          className="border rounded-lg overflow-hidden flex flex-col md:flex-row"
                        >
                          <div className="md:w-1/4">
                            <img 
                              src={meal.image} 
                              alt={meal.name} 
                              className="w-full h-40 object-cover"
                            />
                          </div>
                          <div className="p-4 md:w-3/4">
                            <div className="flex justify-between items-start">
                              <h5 className="text-lg font-semibold">{meal.name}</h5>
                              {meal.isEthiopian && (
                                <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                                  Ethiopian
                                </span>
                              )}
                            </div>
                            
                            <p className="text-gray-600 text-sm mt-1 mb-3">{meal.description}</p>
                            
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Calories</span>
                                <span className="font-medium">{meal.nutritionInfo.calories} kcal</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Protein</span>
                                <span className="font-medium">{meal.nutritionInfo.protein}g</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Carbs</span>
                                <span className="font-medium">{meal.nutritionInfo.carbs}g</span>
                              </div>
                              <div className="bg-gray-50 p-2 rounded text-center">
                                <span className="block text-xs text-gray-500">Fat</span>
                                <span className="font-medium">{meal.nutritionInfo.fat}g</span>
                              </div>
                            </div>
                            
                            <div className="flex flex-wrap gap-2">
                              {meal.ingredients.slice(0, 5).map((ingredient, idx) => (
                                <span 
                                  key={idx} 
                                  className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded"
                                >
                                  {ingredient}
                                </span>
                              ))}
                              {meal.ingredients.length > 5 && (
                                <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                                  +{meal.ingredients.length - 5} more
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Snacks */}
                  {dayMeal.snacks.length > 0 && (
                    <div>
                      <h4 className="font-medium text-gray-900 mb-4 flex items-center">
                        <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full mr-2">
                          Snacks
                        </span>
                      </h4>
                      
                      <div className="space-y-4">
                        {dayMeal.snacks.map((meal) => (
                          <div 
                            key={meal.id} 
                            className="border rounded-lg overflow-hidden flex flex-col md:flex-row"
                          >
                            <div className="md:w-1/4">
                              <img 
                                src={meal.image} 
                                alt={meal.name} 
                                className="w-full h-40 object-cover"
                              />
                            </div>
                            <div className="p-4 md:w-3/4">
                              <div className="flex justify-between items-start">
                                <h5 className="text-lg font-semibold">{meal.name}</h5>
                                {meal.isEthiopian && (
                                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded">
                                    Ethiopian
                                  </span>
                                )}
                              </div>
                              
                              <p className="text-gray-600 text-sm mt-1 mb-3">{meal.description}</p>
                              
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-3">
                                <div className="bg-gray-50 p-2 rounded text-center">
                                  <span className="block text-xs text-gray-500">Calories</span>
                                  <span className="font-medium">{meal.nutritionInfo.calories} kcal</span>
                                </div>
                                <div className="bg-gray-50 p-2 rounded text-center">
                                  <span className="block text-xs text-gray-500">Protein</span>
                                  <span className="font-medium">{meal.nutritionInfo.protein}g</span>
                                </div>
                                <div className="bg-gray-50 p-2 rounded text-center">
                                  <span className="block text-xs text-gray-500">Carbs</span>
                                  <span className="font-medium">{meal.nutritionInfo.carbs}g</span>
                                </div>
                                <div className="bg-gray-50 p-2 rounded text-center">
                                  <span className="block text-xs text-gray-500">Fat</span>
                                  <span className="font-medium">{meal.nutritionInfo.fat}g</span>
                                </div>
                              </div>
                              
                              <div className="flex flex-wrap gap-2">
                                {meal.ingredients.slice(0, 5).map((ingredient, idx) => (
                                  <span 
                                    key={idx} 
                                    className="text-xs bg-green-50 text-green-700 px-2 py-1 rounded"
                                  >
                                    {ingredient}
                                  </span>
                                ))}
                                {meal.ingredients.length > 5 && (
                                  <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">
                                    +{meal.ingredients.length - 5} more
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </Card.Body>
          </Card>
        </div>
        
        {/* Sidebar */}
        <div>
          <div className="space-y-6">
            {!currentUser ? (
              <Card>
                <Card.Body className="text-center">
                  <h3 className="font-semibold text-lg mb-2">Want to save this meal plan?</h3>
                  <p className="text-gray-600 mb-4">
                    Create an account to save this meal plan to your profile.
                  </p>
                  <Link to="/register">
                    <Button variant="primary" fullWidth>
                      Sign Up Now
                    </Button>
                  </Link>
                  <p className="mt-4 text-sm text-gray-500">
                    Already have an account? <Link to="/login" className="text-green-600">Log in</Link>
                  </p>
                </Card.Body>
              </Card>
            ) : (
              <Card>
                <Card.Body>
                  <h3 className="font-semibold text-lg mb-4">Plan Actions</h3>
                  <div className="space-y-3">
                    <Button variant="primary" fullWidth>
                      Save to My Plans
                    </Button>
                    <Button variant="outline" fullWidth>
                      Download PDF
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            )}
            
            <Card>
              <Card.Body>
                <h3 className="font-semibold text-lg mb-4">Nutrition Tips</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Stay hydrated by drinking at least 8 glasses of water daily</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Eat slowly and mindfully to improve digestion</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Stick to the portion sizes recommended in the plan</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Prepare meals in advance when possible to ensure you stay on track</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Adjust portions based on your individual calorie needs</span>
                  </li>
                </ul>
              </Card.Body>
            </Card>
            
            <Card>
              <Card.Body>
                <h3 className="font-semibold text-lg mb-4">Ethiopian Ingredients Guide</h3>
                <div className="space-y-3">
                  <div>
                    <h4 className="font-medium text-gray-900">Teff</h4>
                    <p className="text-sm text-gray-600">
                      The tiny grain used to make injera, rich in protein, fiber, and minerals.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Berbere</h4>
                    <p className="text-sm text-gray-600">
                      A spice blend containing chili peppers, garlic, ginger, and other spices, adding flavor and metabolism-boosting properties.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Niter Kibbeh</h4>
                    <p className="text-sm text-gray-600">
                      Clarified butter infused with spices. Use sparingly for authentic flavor.
                    </p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900">Shiro</h4>
                    <p className="text-sm text-gray-600">
                      Powdered chickpeas or broad beans, a protein-rich base for stews.
                    </p>
                  </div>
                </div>
                <div className="mt-4">
                  <Link to="/services/education" className="text-green-600 hover:underline text-sm">
                    Learn more about Ethiopian ingredients →
                  </Link>
                </div>
              </Card.Body>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NutritionPlanDetail;