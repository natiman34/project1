import { useNavigate } from 'react-router-dom';
import { MotivationalContent as MotivationalContentType } from '../../types/content';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';

interface MotivationalContentProps {
  content: MotivationalContentType[];
}

const MotivationalContent: React.FC<MotivationalContentProps> = ({ content }) => {
  const navigate = useNavigate();
  
  const handleViewArticle = (contentId: string) => {
    navigate(`/services/motivation/${contentId}`);
  };
  
  return (
    <div>
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Motivational Content</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Find inspiration and motivation for your health and fitness journey through culturally relevant content
        </p>
      </div>
      
      {/* Featured Article */}
      {content.length > 0 && (
        <div className="mb-12">
          <div className="relative rounded-xl overflow-hidden">
            <div className="absolute inset-0">
              <img 
                src={content[0].image} 
                alt={content[0].title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent"></div>
            </div>
            
            <div className="relative pt-40 pb-12 px-6 md:px-10 text-white">
              <div className="max-w-3xl">
                <h2 className="text-2xl md:text-3xl font-bold mb-4">{content[0].title}</h2>
                <p className="text-gray-200 mb-6">
                  {content[0].content.substring(0, 180)}...
                </p>
                <Button 
                  variant="primary"
                  onClick={() => handleViewArticle(content[0].id)}
                >
                  Read More
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* All Articles */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {content.slice(1).map((article) => (
          <Card key={article.id} hover className="h-full">
            <Card.Image 
              src={article.image} 
              alt={article.title}
              className="h-48"
            />
            <Card.Body>
              <Card.Title className="mb-2">{article.title}</Card.Title>
              <p className="text-sm text-gray-500 mb-3">
                {new Date(article.createdAt).toLocaleDateString()} • By {article.author}
              </p>
              <p className="text-gray-600 mb-4 line-clamp-3">
                {article.content.substring(0, 150)}...
              </p>
              <Button 
                variant="outline"
                onClick={() => handleViewArticle(article.id)}
              >
                Read More
              </Button>
            </Card.Body>
          </Card>
        ))}
      </div>
      
      {/* Subscribe Section */}
      <div className="mt-16 bg-green-50 rounded-xl p-8 md:p-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Stay Motivated on Your Fitness Journey
          </h2>
          <p className="text-gray-600 mb-6">
            Subscribe to receive weekly motivational content, success stories, 
            and tips to keep you inspired on your health and fitness journey.
          </p>
          
          <div className="max-w-md mx-auto">
            <form className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                placeholder="Your email address"
                className="flex-grow px-4 py-2 rounded-md border border-gray-300 focus:ring-green-500 focus:border-green-500"
              />
              <Button variant="primary">
                Subscribe
              </Button>
            </form>
            <p className="text-xs text-gray-500 mt-3">
              We respect your privacy. Unsubscribe at any time.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MotivationalContent;