import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FitnessPlan } from '../../types/content';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { useAuth } from '../../contexts/AuthContext';

interface FitnessPlanDetailProps {
  plans: FitnessPlan[];
}

const FitnessPlanDetail: React.FC<FitnessPlanDetailProps> = ({ plans }) => {
  const { id } = useParams<{ id: string }>();
  const [plan, setPlan] = useState<FitnessPlan | null>(null);
  const [selectedDay, setSelectedDay] = useState<number>(1);
  const { currentUser } = useAuth();
  
  useEffect(() => {
    if (id) {
      const foundPlan = plans.find((p) => p.id === id);
      if (foundPlan) {
        setPlan(foundPlan);
      }
    }
  }, [id, plans]);
  
  if (!plan) {
    return (
      <div className="text-center py-20">
        <p className="text-gray-600">Plan not found</p>
      </div>
    );
  }
  
  const daySchedule = plan.schedule.find((day) => day.day === selectedDay);
  
  return (
    <div>
      {/* Hero Section */}
      <div className="relative rounded-xl overflow-hidden mb-8">
        <div className="absolute inset-0">
          <img 
            src={plan.image} 
            alt={plan.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/30"></div>
        </div>
        
        <div className="relative py-16 px-8 text-white">
          <div className="max-w-3xl">
            <span className={`inline-block mb-4 text-xs font-semibold px-3 py-1 rounded-full ${
              plan.level === 'beginner' 
                ? 'bg-green-100 text-green-800' 
                : plan.level === 'intermediate' 
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-red-100 text-red-800'
            }`}>
              {plan.level.charAt(0).toUpperCase() + plan.level.slice(1)}
            </span>
            
            <h1 className="text-3xl md:text-4xl font-bold mb-4">{plan.title}</h1>
            
            <div className="flex flex-wrap gap-4 mb-6">
              <div className="bg-black/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <span className="text-sm">Duration</span>
                <p className="font-semibold">{plan.duration} Weeks</p>
              </div>
              
              <div className="bg-black/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <span className="text-sm">Weekly Sessions</span>
                <p className="font-semibold">
                  {plan.schedule.filter(day => !day.restDay).length} Days
                </p>
              </div>
              
              <div className="bg-black/20 backdrop-blur-sm rounded-lg px-4 py-2">
                <span className="text-sm">Rest Days</span>
                <p className="font-semibold">
                  {plan.schedule.filter(day => day.restDay).length} Days/Week
                </p>
              </div>
            </div>
            
            <p className="text-lg">{plan.description}</p>
          </div>
        </div>
      </div>
      
      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <Card>
            <Card.Body>
              <h2 className="text-2xl font-bold mb-6">Weekly Schedule</h2>
              
              {/* Day Selector */}
              <div className="flex flex-wrap gap-2 mb-8">
                {plan.schedule.map((day) => (
                  <button
                    key={day.day}
                    onClick={() => setSelectedDay(day.day)}
                    className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                      selectedDay === day.day
                        ? 'bg-green-600 text-white'
                        : day.restDay
                          ? 'bg-gray-100 text-gray-400'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Day {day.day}
                    {day.restDay && ' (Rest)'}
                  </button>
                ))}
              </div>
              
              {/* Day Details */}
              {daySchedule && (
                <div>
                  <h3 className="text-xl font-semibold mb-4">
                    {daySchedule.restDay 
                      ? 'Rest Day' 
                      : `Day ${daySchedule.day} Workout`}
                  </h3>
                  
                  {daySchedule.restDay ? (
                    <div className="bg-green-50 p-6 rounded-lg">
                      <p className="text-gray-700">
                        Today is a rest day. Rest is an essential part of any fitness program, 
                        allowing your muscles to recover and grow stronger. Use this time to 
                        stretch, hydrate, and prepare for your next workout.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {daySchedule.exercises.map((exercise, index) => (
                        <div 
                          key={exercise.id} 
                          className="border rounded-lg overflow-hidden flex flex-col md:flex-row"
                        >
                          <div className="md:w-1/3">
                            <img 
                              src={exercise.image} 
                              alt={exercise.name} 
                              className="w-full h-48 object-cover"
                            />
                          </div>
                          <div className="p-6 md:w-2/3">
                            <div className="flex justify-between items-start">
                              <h4 className="text-lg font-semibold">{exercise.name}</h4>
                              <span className="bg-gray-100 text-gray-700 text-xs px-2 py-1 rounded">
                                Exercise {index + 1}
                              </span>
                            </div>
                            
                            <p className="text-gray-600 mt-2 mb-4">{exercise.description}</p>
                            
                            <div className="flex flex-wrap gap-4">
                              {exercise.sets && (
                                <div className="bg-green-50 px-3 py-1 rounded">
                                  <span className="text-green-800 font-medium">{exercise.sets} Sets</span>
                                </div>
                              )}
                              
                              {exercise.reps && (
                                <div className="bg-green-50 px-3 py-1 rounded">
                                  <span className="text-green-800 font-medium">{exercise.reps} Reps</span>
                                </div>
                              )}
                              
                              {exercise.duration && (
                                <div className="bg-green-50 px-3 py-1 rounded">
                                  <span className="text-green-800 font-medium">{exercise.duration} min</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </Card.Body>
          </Card>
        </div>
        
        {/* Sidebar */}
        <div>
          <div className="space-y-6">
            {!currentUser ? (
              <Card>
                <Card.Body className="text-center">
                  <h3 className="font-semibold text-lg mb-2">Want to save this plan?</h3>
                  <p className="text-gray-600 mb-4">
                    Create an account to save this plan to your profile.
                  </p>
                  <Link to="/register">
                    <Button variant="primary" fullWidth>
                      Sign Up Now
                    </Button>
                  </Link>
                  <p className="mt-4 text-sm text-gray-500">
                    Already have an account? <Link to="/login" className="text-green-600">Log in</Link>
                  </p>
                </Card.Body>
              </Card>
            ) : (
              <Card>
                <Card.Body>
                  <h3 className="font-semibold text-lg mb-4">Plan Actions</h3>
                  <div className="space-y-3">
                    <Button variant="primary" fullWidth>
                      Save to My Plans
                    </Button>
                    <Button variant="outline" fullWidth>
                      Download PDF
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            )}
            
            <Card>
              <Card.Body>
                <h3 className="font-semibold text-lg mb-4">Tips for Success</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Always warm up for 5-10 minutes before starting</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Stay hydrated throughout your workout</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Focus on proper form rather than speed</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Listen to your body and modify exercises if needed</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Don't skip rest days - they're essential for recovery</span>
                  </li>
                </ul>
              </Card.Body>
            </Card>
            
            <Card>
              <Card.Body>
                <h3 className="font-semibold text-lg mb-4">Ethiopian Nutrition Tips</h3>
                <p className="text-gray-700 mb-4">
                  For optimal results with this fitness plan, consider these nutrition tips using 
                  traditional Ethiopian foods:
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Include protein-rich dishes like misir wot (lentil stew)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Moderate your injera portions based on your goals</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Add more vegetables like gomen (collard greens) to your meals</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-green-600 mr-2">•</span>
                    <span className="text-gray-700">Incorporate berbere spice for metabolism-boosting benefits</span>
                  </li>
                </ul>
                <Link to="/services/nutrition" className="text-green-600 hover:underline inline-block mt-4 text-sm">
                  View our Ethiopian meal plans →
                </Link>
              </Card.Body>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FitnessPlanDetail;