import { useState } from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { mealPlans, mealCategories } from '../../components/utils/MockData';
import { Plus, FileText, Edit, Trash2, Filter, Eye } from 'lucide-react';
import { MealPlan } from '../../types/content';

const AdminNutrition = () => {
  const [plans, setPlans] = useState(mealPlans);
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [calorieFilter, setCalorieFilter] = useState('all');
  
  // Filter plans based on category and calories
  const filteredPlans = plans.filter((plan) => {
    const matchesCategory = categoryFilter === 'all' || plan.categoryId === categoryFilter;
    
    let matchesCalories = true;
    if (calorieFilter === 'low') {
      matchesCalories = plan.calorieRange.max <= 1500;
    } else if (calorieFilter === 'medium') {
      matchesCalories = plan.calorieRange.min >= 1500 && plan.calorieRange.max <= 2000;
    } else if (calorieFilter === 'high') {
      matchesCalories = plan.calorieRange.min >= 2000;
    }
    
    return matchesCategory && matchesCalories;
  });
  
  const getCategoryName = (categoryId: string) => {
    const category = mealCategories.find((cat) => cat.id === categoryId);
    return category ? category.name : '';
  };
  
  const handleDeletePlan = (planId: string) => {
    if (window.confirm('Are you sure you want to delete this meal plan?')) {
      setPlans(plans.filter((plan) => plan.id !== planId));
    }
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">Nutrition Plans Management</h2>
        <Button 
          variant="primary" 
          leftIcon={<Plus size={16} />}
        >
          Create New Plan
        </Button>
      </div>
      
      {/* Filters */}
      <Card className="mb-6">
        <Card.Body className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Category Filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-400" />
              </div>
              <select
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="all">All Categories</option>
                {mealCategories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Calorie Filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-400" />
              </div>
              <select
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={calorieFilter}
                onChange={(e) => setCalorieFilter(e.target.value)}
              >
                <option value="all">All Calorie Ranges</option>
                <option value="low">Low Calorie (&lt;1500 kcal)</option>
                <option value="medium">Medium Calorie (1500-2000 kcal)</option>
                <option value="high">High Calorie (&gt;2000 kcal)</option>
              </select>
            </div>
            
            {/* Status */}
            <div className="text-right md:text-center">
              <span className="text-gray-600">
                Showing {filteredPlans.length} of {plans.length} plans
              </span>
            </div>
          </div>
        </Card.Body>
      </Card>
      
      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPlans.map((plan) => (
          <PlanCard 
            key={plan.id} 
            plan={plan} 
            getCategoryName={getCategoryName}
            onDelete={handleDeletePlan}
          />
        ))}
        
        {filteredPlans.length === 0 && (
          <div className="col-span-3 p-8 text-center text-gray-500">
            No meal plans found matching your criteria.
          </div>
        )}
      </div>
      
      {/* Categories Section */}
      <div className="mt-12">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-bold text-gray-900">Meal Categories</h3>
          <Button 
            variant="outline" 
            size="sm"
            leftIcon={<Plus size={16} />}
          >
            Add Category
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {mealCategories.map((category) => (
            <Card key={category.id}>
              <div className="h-32 overflow-hidden">
                <img 
                  src={category.image} 
                  alt={category.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <Card.Body className="p-4">
                <h4 className="font-semibold text-gray-900">{category.name}</h4>
                <p className="text-gray-600 text-sm truncate">{category.description}</p>
                <div className="flex justify-end mt-2 space-x-2">
                  <button className="text-indigo-600 hover:text-indigo-900">
                    <Edit size={16} />
                  </button>
                  <button className="text-red-600 hover:text-red-900">
                    <Trash2 size={16} />
                  </button>
                </div>
              </Card.Body>
            </Card>
          ))}
        </div>
      </div>
      
      {/* Ethiopian Meals Section */}
      <div className="mt-12">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-bold text-gray-900">Ethiopian Meals Database</h3>
          <Button 
            variant="outline" 
            size="sm"
            leftIcon={<Plus size={16} />}
          >
            Add Meal
          </Button>
        </div>
        
        <Card>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Meal
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Calories
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Protein
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Carbs
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Fats
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {/* Each plan's meals would be here */}
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 flex-shrink-0 mr-3">
                        <img 
                          className="h-10 w-10 rounded-full object-cover" 
                          src="https://images.pexels.com/photos/5949885/pexels-photo-5949885.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                          alt="Injera with Misir Wot"
                        />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">Injera with Misir Wot</div>
                        <div className="text-xs text-gray-500">Ethiopian</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    320 kcal
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    12g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    54g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    6g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button className="text-indigo-600 hover:text-indigo-900 mr-3">
                      <Edit size={16} />
                    </button>
                    <button className="text-red-600 hover:text-red-900">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
                
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 flex-shrink-0 mr-3">
                        <img 
                          className="h-10 w-10 rounded-full object-cover" 
                          src="https://images.pexels.com/photos/7363671/pexels-photo-7363671.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                          alt="Doro Wat"
                        />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">Doro Wat</div>
                        <div className="text-xs text-gray-500">Ethiopian</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    420 kcal
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    35g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    18g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    24g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button className="text-indigo-600 hover:text-indigo-900 mr-3">
                      <Edit size={16} />
                    </button>
                    <button className="text-red-600 hover:text-red-900">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
                
                <tr>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="h-10 w-10 flex-shrink-0 mr-3">
                        <img 
                          className="h-10 w-10 rounded-full object-cover" 
                          src="https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                          alt="Gomen"
                        />
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">Gomen (Collard Greens)</div>
                        <div className="text-xs text-gray-500">Ethiopian</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    130 kcal
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    4g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    12g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                    8g
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button className="text-indigo-600 hover:text-indigo-900 mr-3">
                      <Edit size={16} />
                    </button>
                    <button className="text-red-600 hover:text-red-900">
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
};

interface PlanCardProps {
  plan: MealPlan;
  getCategoryName: (categoryId: string) => string;
  onDelete: (planId: string) => void;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, getCategoryName, onDelete }) => {
  return (
    <Card className="h-full">
      <div className="h-40 overflow-hidden">
        <img 
          src={plan.image} 
          alt={plan.title} 
          className="w-full h-full object-cover"
        />
      </div>
      <Card.Body className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-gray-900">{plan.title}</h3>
          <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-800">
            {plan.calorieRange.min}-{plan.calorieRange.max} kcal
          </span>
        </div>
        <p className="text-sm text-gray-600 mb-2">{getCategoryName(plan.categoryId)}</p>
        <p className="text-gray-600 text-sm line-clamp-2 mb-3">
          {plan.description}
        </p>
        
        <div className="flex justify-between text-xs text-gray-500 mb-3">
          <span>{plan.duration} days</span>
          <span>{plan.meals[0].breakfast.length + plan.meals[0].lunch.length + 
                 plan.meals[0].dinner.length + plan.meals[0].snacks.length} meals/day</span>
        </div>
        
        <div className="flex justify-end space-x-2">
          <button className="text-gray-600 hover:text-gray-900">
            <Eye size={16} />
          </button>
          <button className="text-indigo-600 hover:text-indigo-900">
            <Edit size={16} />
          </button>
          <button 
            className="text-red-600 hover:text-red-900"
            onClick={() => onDelete(plan.id)}
          >
            <Trash2 size={16} />
          </button>
        </div>
      </Card.Body>
    </Card>
  );
};

export default AdminNutrition;