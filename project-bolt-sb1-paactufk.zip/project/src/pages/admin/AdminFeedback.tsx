import { useState } from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { Search, Filter, Mail, Check, X, AlertCircle } from 'lucide-react';

// Mock feedback data
const mockFeedback = [
  {
    id: '1',
    name: 'Meron Alemu',
    email: 'meron@example.com',
    message: 'I love the meal plans, but would appreciate more vegetarian Ethiopian options. Traditional fasting dishes would be a great addition!',
    date: '2023-06-15T14:30:00Z',
    resolved: false,
  },
  {
    id: '2',
    name: 'Abebe Bikila',
    email: 'abebe@example.com',
    message: 'The fitness videos are amazing. Could you add more traditional dance workouts? I think it would make exercising more fun and culturally relevant.',
    date: '2023-06-14T10:15:00Z',
    resolved: false,
  },
  {
    id: '3',
    name: 'Kidist Mulatu',
    email: 'kidist@example.com',
    message: 'Having some issues with the BMI calculator on mobile devices. The buttons are not responsive and sometimes the calculation is incorrect.',
    date: '2023-06-12T09:45:00Z',
    resolved: true,
  },
  {
    id: '4',
    name: 'Solomon Teferra',
    email: 'solomon@example.com',
    message: 'I appreciate the cultural approach to fitness, but I think some of the nutritional advice could be more specific to different regions of Ethiopia.',
    date: '2023-06-10T16:20:00Z',
    resolved: true,
  },
  {
    id: '5',
    name: 'Tigist Haile',
    email: 'tigist@example.com',
    message: 'Just wanted to say thank you for creating this platform. It has helped me stay connected to my culture while working on my health goals.',
    date: '2023-06-08T11:30:00Z',
    resolved: true,
  },
];

const AdminFeedback = () => {
  const [feedback, setFeedback] = useState(mockFeedback);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [expandedFeedback, setExpandedFeedback] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  
  // Filter feedback based on search term and status filter
  const filteredFeedback = feedback.filter((item) => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.message.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = 
      statusFilter === 'all' || 
      (statusFilter === 'resolved' && item.resolved) || 
      (statusFilter === 'unresolved' && !item.resolved);
    
    return matchesSearch && matchesStatus;
  });
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setStatusFilter(e.target.value);
  };
  
  const handleMarkResolved = (feedbackId: string) => {
    setFeedback(
      feedback.map((item) =>
        item.id === feedbackId ? { ...item, resolved: true } : item
      )
    );
  };
  
  const handleReplySubmit = (feedbackId: string) => {
    if (replyText.trim() === '') return;
    
    // In a real app, this would send an email or store the reply
    alert(`Reply sent to the user: ${replyText}`);
    
    // Mark as resolved after reply
    handleMarkResolved(feedbackId);
    setReplyText('');
    setExpandedFeedback(null);
  };
  
  const toggleExpandFeedback = (feedbackId: string) => {
    if (expandedFeedback === feedbackId) {
      setExpandedFeedback(null);
    } else {
      setExpandedFeedback(feedbackId);
      setReplyText('');
    }
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">User Feedback</h2>
        <div className="flex items-center">
          <span className="mr-2 px-2 py-1 bg-red-100 text-red-800 text-sm rounded-full">
            {feedback.filter(item => !item.resolved).length} Unresolved
          </span>
          <span className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded-full">
            {feedback.filter(item => item.resolved).length} Resolved
          </span>
        </div>
      </div>
      
      {/* Filters */}
      <Card className="mb-6">
        <Card.Body className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Search */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search feedback..."
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={searchTerm}
                onChange={handleSearch}
              />
            </div>
            
            {/* Status Filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-400" />
              </div>
              <select
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={statusFilter}
                onChange={handleFilterChange}
              >
                <option value="all">All Status</option>
                <option value="resolved">Resolved</option>
                <option value="unresolved">Unresolved</option>
              </select>
            </div>
            
            {/* Status */}
            <div className="text-right md:text-center">
              <span className="text-gray-600">
                Showing {filteredFeedback.length} of {feedback.length} feedback items
              </span>
            </div>
          </div>
        </Card.Body>
      </Card>
      
      {/* Feedback List */}
      <div className="space-y-4">
        {filteredFeedback.length > 0 ? (
          filteredFeedback.map((item) => (
            <Card key={item.id} className={item.resolved ? 'border-green-100' : 'border-red-100'}>
              <Card.Body className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start">
                    <div className="mr-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        item.resolved ? 'bg-green-100' : 'bg-red-100'
                      }`}>
                        {item.resolved ? (
                          <Check size={18} className="text-green-600" />
                        ) : (
                          <AlertCircle size={18} className="text-red-600" />
                        )}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{item.name}</h3>
                      <p className="text-sm text-gray-600">{item.email}</p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(item.date).toLocaleDateString()} at {new Date(item.date).toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex space-x-2">
                    {!item.resolved && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        leftIcon={<Check size={14} />}
                        onClick={() => handleMarkResolved(item.id)}
                      >
                        Mark Resolved
                      </Button>
                    )}
                    
                    {!item.resolved && (
                      <Button 
                        variant="primary" 
                        size="sm"
                        leftIcon={<Mail size={14} />}
                        onClick={() => toggleExpandFeedback(item.id)}
                      >
                        Reply
                      </Button>
                    )}
                  </div>
                </div>
                
                <div className="mt-4 p-3 bg-gray-50 rounded-md">
                  <p className="text-gray-700">{item.message}</p>
                </div>
                
                {expandedFeedback === item.id && (
                  <div className="mt-4">
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Reply to {item.name}
                    </label>
                    <textarea
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      rows={4}
                      value={replyText}
                      onChange={(e) => setReplyText(e.target.value)}
                      placeholder="Type your reply here..."
                    ></textarea>
                    <div className="flex justify-end mt-2 space-x-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setExpandedFeedback(null)}
                      >
                        Cancel
                      </Button>
                      <Button 
                        variant="primary" 
                        size="sm"
                        onClick={() => handleReplySubmit(item.id)}
                      >
                        Send Reply
                      </Button>
                    </div>
                  </div>
                )}
                
                {item.resolved && (
                  <div className="mt-4 flex items-center">
                    <Check size={16} className="text-green-600 mr-2" />
                    <span className="text-sm text-green-600">Resolved</span>
                  </div>
                )}
              </Card.Body>
            </Card>
          ))
        ) : (
          <div className="text-center py-8 text-gray-500">
            No feedback found matching your criteria.
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminFeedback;