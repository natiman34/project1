import { useState } from 'react';
import { Routes, Route, Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  LayoutDashboard, 
  Users, 
  Dumbbell, 
  Utensils, 
  BookOpen, 
  MessageSquare, 
  Settings, 
  LogOut,
  Menu,
  X
} from 'lucide-react';
import Button from '../../components/ui/Button';

// Admin Components
import AdminOverview from './AdminOverview';
import AdminUsers from './AdminUsers';
import AdminFitness from './AdminFitness';
import AdminNutrition from './AdminNutrition';
import AdminContent from './AdminContent';
import AdminFeedback from './AdminFeedback';
import AdminSettings from './AdminSettings';

const Dashboard = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/');
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  // Close sidebar when route changes
  React.useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);
  
  // Determine user role for display
  const getRoleDisplay = () => {
    switch (currentUser?.role) {
      case 'admin_super':
        return 'Super Admin';
      case 'admin_nutritionist':
        return 'Nutritionist Admin';
      case 'admin_fitness':
        return 'Fitness Admin';
      default:
        return 'Admin';
    }
  };
  
  const isActive = (path: string) => {
    return location.pathname === path || 
           (path !== '/admin' && location.pathname.startsWith(path));
  };
  
  const sidebar = (
    <div className="w-64 h-full bg-gray-800 text-white flex flex-col">
      {/* Sidebar Header */}
      <div className="p-4 border-b border-gray-700">
        <Link to="/admin" className="flex items-center">
          <div className="font-bold text-xl flex items-center">
            <span className="text-red-500">ሁል</span>
            <span className="text-yellow-500">ጊዜ</span>
            <span className="text-green-500">ጤና</span>
            <span className="ml-2 text-white">Admin</span>
          </div>
        </Link>
      </div>
      
      {/* Admin Info */}
      <div className="p-4 border-b border-gray-700 mb-4">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center mr-3">
            <span className="text-white font-bold">{currentUser?.name.charAt(0)}</span>
          </div>
          <div>
            <p className="font-medium">{currentUser?.name}</p>
            <p className="text-xs text-gray-400">{getRoleDisplay()}</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="flex-grow">
        <ul className="space-y-1 px-2">
          <li>
            <Link
              to="/admin"
              className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                isActive('/admin') && !isActive('/admin/users') && !isActive('/admin/fitness') && 
                !isActive('/admin/nutrition') && !isActive('/admin/content') && 
                !isActive('/admin/feedback') && !isActive('/admin/settings')
                  ? 'bg-gray-700 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              <LayoutDashboard className="mr-3 h-5 w-5" />
              Dashboard
            </Link>
          </li>
          
          {/* Only visible to super admin */}
          {currentUser?.role === 'admin_super' && (
            <li>
              <Link
                to="/admin/users"
                className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                  isActive('/admin/users')
                    ? 'bg-gray-700 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <Users className="mr-3 h-5 w-5" />
                Users Management
              </Link>
            </li>
          )}
          
          {/* Visible to super admin and fitness admin */}
          {(currentUser?.role === 'admin_super' || currentUser?.role === 'admin_fitness') && (
            <li>
              <Link
                to="/admin/fitness"
                className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                  isActive('/admin/fitness')
                    ? 'bg-gray-700 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <Dumbbell className="mr-3 h-5 w-5" />
                Fitness Plans
              </Link>
            </li>
          )}
          
          {/* Visible to super admin and nutritionist admin */}
          {(currentUser?.role === 'admin_super' || currentUser?.role === 'admin_nutritionist') && (
            <li>
              <Link
                to="/admin/nutrition"
                className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                  isActive('/admin/nutrition')
                    ? 'bg-gray-700 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <Utensils className="mr-3 h-5 w-5" />
                Nutrition Plans
              </Link>
            </li>
          )}
          
          {/* Visible to all admins */}
          <li>
            <Link
              to="/admin/content"
              className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                isActive('/admin/content')
                  ? 'bg-gray-700 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              <BookOpen className="mr-3 h-5 w-5" />
              Content Management
            </Link>
          </li>
          
          {/* Only visible to super admin */}
          {currentUser?.role === 'admin_super' && (
            <li>
              <Link
                to="/admin/feedback"
                className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                  isActive('/admin/feedback')
                    ? 'bg-gray-700 text-white'
                    : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                }`}
              >
                <MessageSquare className="mr-3 h-5 w-5" />
                User Feedback
              </Link>
            </li>
          )}
          
          <li>
            <Link
              to="/admin/settings"
              className={`flex items-center px-4 py-3 rounded-md transition-colors ${
                isActive('/admin/settings')
                  ? 'bg-gray-700 text-white'
                  : 'text-gray-300 hover:bg-gray-700 hover:text-white'
              }`}
            >
              <Settings className="mr-3 h-5 w-5" />
              Settings
            </Link>
          </li>
        </ul>
      </nav>
      
      {/* Logout */}
      <div className="p-4 border-t border-gray-700">
        <button
          onClick={handleLogout}
          className="flex items-center w-full px-4 py-2 text-gray-300 hover:text-white transition-colors"
        >
          <LogOut className="mr-3 h-5 w-5" />
          Logout
        </button>
      </div>
    </div>
  );
  
  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar for desktop */}
      <div className="hidden md:block">
        {sidebar}
      </div>
      
      {/* Mobile sidebar */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="fixed inset-0 bg-gray-600 bg-opacity-75" onClick={toggleSidebar}></div>
          <div className="relative z-10 h-full">
            {sidebar}
          </div>
        </div>
      )}
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="bg-white shadow-sm z-10">
          <div className="px-4 sm:px-6 py-4 flex justify-between items-center">
            <div className="flex items-center">
              {/* Mobile menu button */}
              <button
                className="md:hidden mr-2 text-gray-600 hover:text-gray-900"
                onClick={toggleSidebar}
              >
                {sidebarOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
              
              <h1 className="text-xl font-bold text-gray-900">
                {location.pathname === '/admin' && 'Dashboard'}
                {location.pathname === '/admin/users' && 'Users Management'}
                {location.pathname === '/admin/fitness' && 'Fitness Plans'}
                {location.pathname === '/admin/nutrition' && 'Nutrition Plans'}
                {location.pathname === '/admin/content' && 'Content Management'}
                {location.pathname === '/admin/feedback' && 'User Feedback'}
                {location.pathname === '/admin/settings' && 'Settings'}
              </h1>
            </div>
            
            <div className="flex items-center space-x-3">
              <Link to="/">
                <Button variant="outline" size="sm">
                  View Site
                </Button>
              </Link>
            </div>
          </div>
        </header>
        
        {/* Page Content */}
        <main className="flex-1 overflow-auto bg-gray-100">
          <div className="p-6">
            <Routes>
              <Route path="/" element={<AdminOverview />} />
              <Route path="/users" element={<AdminUsers />} />
              <Route path="/fitness" element={<AdminFitness />} />
              <Route path="/nutrition" element={<AdminNutrition />} />
              <Route path="/content" element={<AdminContent />} />
              <Route path="/feedback" element={<AdminFeedback />} />
              <Route path="/settings" element={<AdminSettings />} />
            </Routes>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;