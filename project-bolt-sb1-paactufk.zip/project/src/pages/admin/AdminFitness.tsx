import { useState } from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { fitnessPlans, fitnessCategories } from '../../components/utils/MockData';
import { Plus, FileText, Edit, Trash2, Filter, Eye } from 'lucide-react';
import { FitnessPlan } from '../../types/content';

const AdminFitness = () => {
  const [plans, setPlans] = useState(fitnessPlans);
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [levelFilter, setLevelFilter] = useState('all');
  
  // Filter plans based on category and level
  const filteredPlans = plans.filter((plan) => {
    const matchesCategory = categoryFilter === 'all' || plan.categoryId === categoryFilter;
    const matchesLevel = levelFilter === 'all' || plan.level === levelFilter;
    
    return matchesCategory && matchesLevel;
  });
  
  const getCategoryName = (categoryId: string) => {
    const category = fitnessCategories.find((cat) => cat.id === categoryId);
    return category ? category.name : '';
  };
  
  const handleDeletePlan = (planId: string) => {
    if (window.confirm('Are you sure you want to delete this fitness plan?')) {
      setPlans(plans.filter((plan) => plan.id !== planId));
    }
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">Fitness Plans Management</h2>
        <Button 
          variant="primary" 
          leftIcon={<Plus size={16} />}
        >
          Create New Plan
        </Button>
      </div>
      
      {/* Filters */}
      <Card className="mb-6">
        <Card.Body className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Category Filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-400" />
              </div>
              <select
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
              >
                <option value="all">All Categories</option>
                {fitnessCategories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>
            
            {/* Level Filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-400" />
              </div>
              <select
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={levelFilter}
                onChange={(e) => setLevelFilter(e.target.value)}
              >
                <option value="all">All Levels</option>
                <option value="beginner">Beginner</option>
                <option value="intermediate">Intermediate</option>
                <option value="advanced">Advanced</option>
              </select>
            </div>
            
            {/* Status */}
            <div className="text-right md:text-center">
              <span className="text-gray-600">
                Showing {filteredPlans.length} of {plans.length} plans
              </span>
            </div>
          </div>
        </Card.Body>
      </Card>
      
      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPlans.map((plan) => (
          <PlanCard 
            key={plan.id} 
            plan={plan} 
            getCategoryName={getCategoryName}
            onDelete={handleDeletePlan}
          />
        ))}
        
        {filteredPlans.length === 0 && (
          <div className="col-span-3 p-8 text-center text-gray-500">
            No fitness plans found matching your criteria.
          </div>
        )}
      </div>
      
      {/* Categories Section */}
      <div className="mt-12">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-bold text-gray-900">Fitness Categories</h3>
          <Button 
            variant="outline" 
            size="sm"
            leftIcon={<Plus size={16} />}
          >
            Add Category
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {fitnessCategories.map((category) => (
            <Card key={category.id}>
              <div className="h-32 overflow-hidden">
                <img 
                  src={category.image} 
                  alt={category.name} 
                  className="w-full h-full object-cover"
                />
              </div>
              <Card.Body className="p-4">
                <h4 className="font-semibold text-gray-900">{category.name}</h4>
                <p className="text-gray-600 text-sm truncate">{category.description}</p>
                <div className="flex justify-end mt-2 space-x-2">
                  <button className="text-indigo-600 hover:text-indigo-900">
                    <Edit size={16} />
                  </button>
                  <button className="text-red-600 hover:text-red-900">
                    <Trash2 size={16} />
                  </button>
                </div>
              </Card.Body>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

interface PlanCardProps {
  plan: FitnessPlan;
  getCategoryName: (categoryId: string) => string;
  onDelete: (planId: string) => void;
}

const PlanCard: React.FC<PlanCardProps> = ({ plan, getCategoryName, onDelete }) => {
  return (
    <Card className="h-full">
      <div className="h-40 overflow-hidden">
        <img 
          src={plan.image} 
          alt={plan.title} 
          className="w-full h-full object-cover"
        />
      </div>
      <Card.Body className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-gray-900">{plan.title}</h3>
          <span className={`text-xs px-2 py-1 rounded-full ${
            plan.level === 'beginner' 
              ? 'bg-green-100 text-green-800' 
              : plan.level === 'intermediate' 
                ? 'bg-amber-100 text-amber-800'
                : 'bg-red-100 text-red-800'
          }`}>
            {plan.level.charAt(0).toUpperCase() + plan.level.slice(1)}
          </span>
        </div>
        <p className="text-sm text-gray-600 mb-2">{getCategoryName(plan.categoryId)}</p>
        <p className="text-gray-600 text-sm line-clamp-2 mb-3">
          {plan.description}
        </p>
        
        <div className="flex justify-between text-xs text-gray-500 mb-3">
          <span>{plan.duration} weeks</span>
          <span>{plan.schedule.filter(d => !d.restDay).length} workouts/week</span>
        </div>
        
        <div className="flex justify-end space-x-2">
          <button className="text-gray-600 hover:text-gray-900">
            <Eye size={16} />
          </button>
          <button className="text-indigo-600 hover:text-indigo-900">
            <Edit size={16} />
          </button>
          <button 
            className="text-red-600 hover:text-red-900"
            onClick={() => onDelete(plan.id)}
          >
            <Trash2 size={16} />
          </button>
        </div>
      </Card.Body>
    </Card>
  );
};

export default AdminFitness;