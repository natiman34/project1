import React, { useState } from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { Search, Filter, Edit, Trash2, UserPlus, Check, X } from 'lucide-react';
import { UserRole } from '../../types/user';

// Mock users data
const mockUsers = [
  {
    id: '1',
    name: 'Abebe Bikila',
    email: 'abebe@example.com',
    role: UserRole.USER,
    createdAt: '2023-04-15T10:00:00Z',
    lastLogin: '2023-06-10T14:30:00Z',
  },
  {
    id: '2',
    name: 'Tigist Tufa',
    email: 'tigist@example.com',
    role: UserRole.USER,
    createdAt: '2023-03-22T11:20:00Z',
    lastLogin: '2023-06-12T09:15:00Z',
  },
  {
    id: '3',
    name: 'Haile Gebrselassie',
    email: 'haile@example.com',
    role: UserRole.ADMIN_FITNESS,
    createdAt: '2023-01-10T08:45:00Z',
    lastLogin: '2023-06-11T16:20:00Z',
  },
  {
    id: '4',
    name: 'Meseret Defar',
    email: 'meseret@example.com',
    role: UserRole.ADMIN_NUTRITIONIST,
    createdAt: '2023-02-05T13:30:00Z',
    lastLogin: '2023-06-09T11:45:00Z',
  },
  {
    id: '5',
    name: 'Kenenisa Bekele',
    email: 'kenenisa@example.com',
    role: UserRole.ADMIN_SUPER,
    createdAt: '2022-12-01T09:00:00Z',
    lastLogin: '2023-06-12T10:30:00Z',
  },
  {
    id: '6',
    name: 'Derartu Tulu',
    email: 'derartu@example.com',
    role: UserRole.USER,
    createdAt: '2023-05-18T15:10:00Z',
    lastLogin: '2023-06-11T12:20:00Z',
  },
  {
    id: '7',
    name: 'Tirunesh Dibaba',
    email: 'tirunesh@example.com',
    role: UserRole.USER,
    createdAt: '2023-04-30T10:45:00Z',
    lastLogin: '2023-06-10T09:50:00Z',
  },
];

const AdminUsers = () => {
  const [users, setUsers] = useState(mockUsers);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [editingUser, setEditingUser] = useState<string | null>(null);
  const [userFormData, setUserFormData] = useState({
    name: '',
    email: '',
    role: UserRole.USER,
  });
  const [showAddUserForm, setShowAddUserForm] = useState(false);
  
  // Filter users based on search term and role filter
  const filteredUsers = users.filter((user) => {
    const matchesSearch = 
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === 'all' || user.role === roleFilter;
    
    return matchesSearch && matchesRole;
  });
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };
  
  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setRoleFilter(e.target.value);
  };
  
  const handleEditUser = (userId: string) => {
    const user = users.find((u) => u.id === userId);
    if (user) {
      setUserFormData({
        name: user.name,
        email: user.email,
        role: user.role,
      });
      setEditingUser(userId);
    }
  };
  
  const handleDeleteUser = (userId: string) => {
    // In a real app, this would call an API to delete the user
    if (window.confirm('Are you sure you want to delete this user?')) {
      setUsers(users.filter((user) => user.id !== userId));
    }
  };
  
  const handleAddNewUser = () => {
    setUserFormData({
      name: '',
      email: '',
      role: UserRole.USER,
    });
    setShowAddUserForm(true);
  };
  
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setUserFormData({ ...userFormData, [name]: value });
  };
  
  const handleSaveUser = () => {
    if (editingUser) {
      // Update existing user
      setUsers(
        users.map((user) =>
          user.id === editingUser
            ? { ...user, name: userFormData.name, email: userFormData.email, role: userFormData.role as UserRole }
            : user
        )
      );
      setEditingUser(null);
    } else if (showAddUserForm) {
      // Add new user
      const newUser = {
        id: Date.now().toString(),
        name: userFormData.name,
        email: userFormData.email,
        role: userFormData.role as UserRole,
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
      };
      setUsers([...users, newUser]);
      setShowAddUserForm(false);
    }
  };
  
  const handleCancelEdit = () => {
    setEditingUser(null);
    setShowAddUserForm(false);
  };
  
  // Format role for display
  const formatRole = (role: UserRole) => {
    switch (role) {
      case UserRole.ADMIN_SUPER:
        return 'Super Admin';
      case UserRole.ADMIN_NUTRITIONIST:
        return 'Nutritionist Admin';
      case UserRole.ADMIN_FITNESS:
        return 'Fitness Admin';
      case UserRole.USER:
        return 'User';
      default:
        return role;
    }
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">Users Management</h2>
        <Button 
          variant="primary" 
          onClick={handleAddNewUser}
          leftIcon={<UserPlus size={16} />}
        >
          Add New User
        </Button>
      </div>
      
      {/* Filters */}
      <Card className="mb-6">
        <Card.Body className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Search */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search users..."
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={searchTerm}
                onChange={handleSearch}
              />
            </div>
            
            {/* Role Filter */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Filter size={16} className="text-gray-400" />
              </div>
              <select
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={roleFilter}
                onChange={handleFilterChange}
              >
                <option value="all">All Roles</option>
                <option value={UserRole.USER}>Regular Users</option>
                <option value={UserRole.ADMIN_FITNESS}>Fitness Admins</option>
                <option value={UserRole.ADMIN_NUTRITIONIST}>Nutritionist Admins</option>
                <option value={UserRole.ADMIN_SUPER}>Super Admins</option>
              </select>
            </div>
            
            {/* Status */}
            <div className="text-right md:text-center">
              <span className="text-gray-600">
                Showing {filteredUsers.length} of {users.length} users
              </span>
            </div>
          </div>
        </Card.Body>
      </Card>
      
      {/* Add/Edit User Form */}
      {(editingUser || showAddUserForm) && (
        <Card className="mb-6">
          <Card.Body className="p-4">
            <h3 className="text-lg font-semibold mb-4">
              {editingUser ? 'Edit User' : 'Add New User'}
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  name="name"
                  value={userFormData.name}
                  onChange={handleFormChange}
                  className="p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                  placeholder="Enter user's full name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  name="email"
                  value={userFormData.email}
                  onChange={handleFormChange}
                  className="p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                  placeholder="Enter user's email"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Role
                </label>
                <select
                  name="role"
                  value={userFormData.role}
                  onChange={handleFormChange}
                  className="p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                >
                  <option value={UserRole.USER}>Regular User</option>
                  <option value={UserRole.ADMIN_FITNESS}>Fitness Admin</option>
                  <option value={UserRole.ADMIN_NUTRITIONIST}>Nutritionist Admin</option>
                  <option value={UserRole.ADMIN_SUPER}>Super Admin</option>
                </select>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3">
              <Button 
                variant="outline" 
                onClick={handleCancelEdit}
                leftIcon={<X size={16} />}
              >
                Cancel
              </Button>
              <Button 
                variant="primary" 
                onClick={handleSaveUser}
                leftIcon={<Check size={16} />}
              >
                Save
              </Button>
            </div>
          </Card.Body>
        </Card>
      )}
      
      {/* Users Table */}
      <Card>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Name
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Email
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Role
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Created
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Last Login
                </th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredUsers.map((user) => (
                <tr key={user.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3">
                        <span className="text-green-700 font-medium">
                          {user.name.charAt(0)}
                        </span>
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{user.name}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                    {user.email}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span 
                      className={`px-2 py-1 text-xs font-medium rounded-full ${
                        user.role === UserRole.ADMIN_SUPER 
                          ? 'bg-purple-100 text-purple-800' 
                          : user.role === UserRole.ADMIN_NUTRITIONIST 
                            ? 'bg-green-100 text-green-800'
                            : user.role === UserRole.ADMIN_FITNESS
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-gray-100 text-gray-800'
                      }`}
                    >
                      {formatRole(user.role)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                    {new Date(user.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-gray-600">
                    {new Date(user.lastLogin).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => handleEditUser(user.id)}
                      className="text-indigo-600 hover:text-indigo-900 mr-3"
                    >
                      <Edit size={16} />
                    </button>
                    <button
                      onClick={() => handleDeleteUser(user.id)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 size={16} />
                    </button>
                  </td>
                </tr>
              ))}
              
              {filteredUsers.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-6 py-4 text-center text-gray-500">
                    No users found matching your search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

export default AdminUsers;