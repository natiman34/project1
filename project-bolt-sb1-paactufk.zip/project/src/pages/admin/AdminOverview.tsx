import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Card from '../../components/ui/Card';
import { 
  Users, 
  TrendingUp, 
  BarChart2, 
  Calendar, 
  FileText,
  Dumbbell,
  Utensils,
  MessageSquare
} from 'lucide-react';

const AdminOverview = () => {
  const { currentUser } = useAuth();
  const [stats, setStats] = useState({
    totalUsers: 124,
    activeUsers: 87,
    fitnessPlans: 8,
    mealPlans: 12,
    contentPieces: 24,
    feedbackMessages: 5
  });
  
  const [recentActions, setRecentActions] = useState([
    {
      id: 1,
      action: 'New user registration',
      user: 'Samuel T.',
      time: '10 minutes ago'
    },
    {
      id: 2,
      action: 'New feedback received',
      user: 'Hanna M.',
      time: '45 minutes ago'
    },
    {
      id: 3,
      action: 'Fitness plan updated',
      user: 'Admin',
      time: '2 hours ago'
    },
    {
      id: 4,
      action: 'Meal plan created',
      user: 'Admin',
      time: '5 hours ago'
    },
    {
      id: 5,
      action: 'Content article published',
      user: 'Admin',
      time: 'Yesterday'
    }
  ]);
  
  // Get current date in a friendly format
  const currentDate = new Date().toLocaleDateString('en-US', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  
  return (
    <div>
      {/* Welcome Section */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900">
          Welcome back, {currentUser?.name}!
        </h2>
        <p className="text-gray-600">
          {currentDate} | Here's what's happening with your platform today.
        </p>
      </div>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
        {/* Users Stat */}
        <Link to={currentUser?.role === 'admin_super' ? '/admin/users' : '#'}>
          <Card hover={currentUser?.role === 'admin_super'} className="h-full">
            <Card.Body className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Users</p>
                  <h3 className="text-2xl font-bold text-gray-900 mt-1">{stats.totalUsers}</h3>
                  <p className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingUp size={16} className="mr-1" />
                    <span>12% increase</span>
                  </p>
                </div>
                <div className="p-3 bg-indigo-100 rounded-full">
                  <Users size={24} className="text-indigo-600" />
                </div>
              </div>
            </Card.Body>
          </Card>
        </Link>
        
        {/* Fitness Plans Stat */}
        <Link to={currentUser?.role === 'admin_super' || currentUser?.role === 'admin_fitness' ? '/admin/fitness' : '#'}>
          <Card hover={currentUser?.role === 'admin_super' || currentUser?.role === 'admin_fitness'} className="h-full">
            <Card.Body className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Fitness Plans</p>
                  <h3 className="text-2xl font-bold text-gray-900 mt-1">{stats.fitnessPlans}</h3>
                  <p className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingUp size={16} className="mr-1" />
                    <span>2 new this month</span>
                  </p>
                </div>
                <div className="p-3 bg-blue-100 rounded-full">
                  <Dumbbell size={24} className="text-blue-600" />
                </div>
              </div>
            </Card.Body>
          </Card>
        </Link>
        
        {/* Meal Plans Stat */}
        <Link to={currentUser?.role === 'admin_super' || currentUser?.role === 'admin_nutritionist' ? '/admin/nutrition' : '#'}>
          <Card hover={currentUser?.role === 'admin_super' || currentUser?.role === 'admin_nutritionist'} className="h-full">
            <Card.Body className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Meal Plans</p>
                  <h3 className="text-2xl font-bold text-gray-900 mt-1">{stats.mealPlans}</h3>
                  <p className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingUp size={16} className="mr-1" />
                    <span>3 new this month</span>
                  </p>
                </div>
                <div className="p-3 bg-green-100 rounded-full">
                  <Utensils size={24} className="text-green-600" />
                </div>
              </div>
            </Card.Body>
          </Card>
        </Link>
        
        {/* Content Stat */}
        <Link to="/admin/content">
          <Card hover className="h-full">
            <Card.Body className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Content Pieces</p>
                  <h3 className="text-2xl font-bold text-gray-900 mt-1">{stats.contentPieces}</h3>
                  <p className="text-sm text-green-600 flex items-center mt-1">
                    <TrendingUp size={16} className="mr-1" />
                    <span>8 new this month</span>
                  </p>
                </div>
                <div className="p-3 bg-amber-100 rounded-full">
                  <FileText size={24} className="text-amber-600" />
                </div>
              </div>
            </Card.Body>
          </Card>
        </Link>
      </div>
      
      {/* Recent Activities & Performance Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* User Activity Chart */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <Card.Body>
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-gray-900">User Activity</h3>
                <div>
                  <select className="p-1 text-sm border border-gray-300 rounded">
                    <option>Last 7 days</option>
                    <option>Last 30 days</option>
                    <option>Last 90 days</option>
                  </select>
                </div>
              </div>
              
              <div className="h-64 relative">
                {/* This would be a real chart in production */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <BarChart2 size={48} className="text-gray-300" />
                  <span className="absolute text-gray-500 text-sm">
                    Chart visualization would appear here
                  </span>
                </div>
              </div>
            </Card.Body>
          </Card>
        </div>
        
        {/* Recent Activities */}
        <div>
          <Card className="h-full">
            <Card.Body>
              <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Activity</h3>
              
              <div className="space-y-4">
                {recentActions.map((action) => (
                  <div key={action.id} className="flex items-start">
                    <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
                      <Calendar size={16} className="text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{action.action}</p>
                      <div className="flex text-sm text-gray-500">
                        <span>{action.user}</span>
                        <span className="mx-1">•</span>
                        <span>{action.time}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card.Body>
          </Card>
        </div>
      </div>
      
      {/* Quick Access & Recent Feedback */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-8">
        {/* Quick Access */}
        <Card>
          <Card.Body>
            <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Access</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {/* Quick Access Cards */}
              {currentUser?.role === 'admin_super' && (
                <Link to="/admin/users">
                  <div className="p-4 bg-white border rounded-lg hover:shadow-md transition-shadow text-center">
                    <Users size={24} className="mx-auto mb-2 text-indigo-600" />
                    <span className="text-sm font-medium">Manage Users</span>
                  </div>
                </Link>
              )}
              
              {(currentUser?.role === 'admin_super' || currentUser?.role === 'admin_fitness') && (
                <Link to="/admin/fitness">
                  <div className="p-4 bg-white border rounded-lg hover:shadow-md transition-shadow text-center">
                    <Dumbbell size={24} className="mx-auto mb-2 text-blue-600" />
                    <span className="text-sm font-medium">Fitness Plans</span>
                  </div>
                </Link>
              )}
              
              {(currentUser?.role === 'admin_super' || currentUser?.role === 'admin_nutritionist') && (
                <Link to="/admin/nutrition">
                  <div className="p-4 bg-white border rounded-lg hover:shadow-md transition-shadow text-center">
                    <Utensils size={24} className="mx-auto mb-2 text-green-600" />
                    <span className="text-sm font-medium">Meal Plans</span>
                  </div>
                </Link>
              )}
              
              <Link to="/admin/content">
                <div className="p-4 bg-white border rounded-lg hover:shadow-md transition-shadow text-center">
                  <FileText size={24} className="mx-auto mb-2 text-amber-600" />
                  <span className="text-sm font-medium">Content</span>
                </div>
              </Link>
              
              {currentUser?.role === 'admin_super' && (
                <Link to="/admin/feedback">
                  <div className="p-4 bg-white border rounded-lg hover:shadow-md transition-shadow text-center">
                    <MessageSquare size={24} className="mx-auto mb-2 text-purple-600" />
                    <span className="text-sm font-medium">Feedback</span>
                  </div>
                </Link>
              )}
              
              <Link to="/admin/settings">
                <div className="p-4 bg-white border rounded-lg hover:shadow-md transition-shadow text-center">
                  <Utensils size={24} className="mx-auto mb-2 text-gray-600" />
                  <span className="text-sm font-medium">Settings</span>
                </div>
              </Link>
            </div>
          </Card.Body>
        </Card>
        
        {/* Recent Feedback (only for super admin) */}
        {currentUser?.role === 'admin_super' && (
          <Card>
            <Card.Body>
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-bold text-gray-900">Recent Feedback</h3>
                <Link to="/admin/feedback" className="text-sm text-green-600 hover:text-green-700">
                  View all
                </Link>
              </div>
              
              <div className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">Selam W.</span>
                    <span className="text-sm text-gray-500">Yesterday</span>
                  </div>
                  <p className="text-gray-600 text-sm">
                    I love the meal plans, but would appreciate more vegetarian Ethiopian options.
                  </p>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">Abebe T.</span>
                    <span className="text-sm text-gray-500">2 days ago</span>
                  </div>
                  <p className="text-gray-600 text-sm">
                    The fitness videos are great! Could you add more traditional dance workouts?
                  </p>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <div className="flex justify-between mb-2">
                    <span className="font-medium">Kidist M.</span>
                    <span className="text-sm text-gray-500">3 days ago</span>
                  </div>
                  <p className="text-gray-600 text-sm">
                    Having some issues with the BMI calculator on mobile devices. Could you check?
                  </p>
                </div>
              </div>
            </Card.Body>
          </Card>
        )}
      </div>
    </div>
  );
};

export default AdminOverview;