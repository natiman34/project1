import { useState } from 'react';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { educationalContent, motivationalContent } from '../../components/utils/MockData';
import { Plus, Edit, Trash2, Search, Filter } from 'lucide-react';
import { EducationalContent, MotivationalContent } from '../../types/content';

type ContentType = 'educational' | 'motivational';

const AdminContent = () => {
  const [activeTab, setActiveTab] = useState<ContentType>('educational');
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  
  // Filter educational content
  const filteredEducationalContent = educationalContent.filter((content) => {
    const matchesSearch = 
      content.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      content.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === 'all' || content.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });
  
  // Filter motivational content
  const filteredMotivationalContent = motivationalContent.filter((content) => {
    const matchesSearch = 
      content.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      content.content.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesSearch;
  });
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
  };
  
  const handleDeleteContent = (contentId: string, type: ContentType) => {
    if (window.confirm(`Are you sure you want to delete this ${type} content?`)) {
      // In a real app, this would call an API to delete the content
      console.log(`Deleting ${type} content with ID: ${contentId}`);
    }
  };
  
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-900">Content Management</h2>
        <Button 
          variant="primary" 
          leftIcon={<Plus size={16} />}
        >
          Create New Content
        </Button>
      </div>
      
      {/* Tabs */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="-mb-px flex space-x-8">
          <button
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'educational'
                ? 'border-green-600 text-green-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('educational')}
          >
            Educational Content
          </button>
          <button
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'motivational'
                ? 'border-green-600 text-green-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
            onClick={() => setActiveTab('motivational')}
          >
            Motivational Content
          </button>
        </nav>
      </div>
      
      {/* Filters */}
      <Card className="mb-6">
        <Card.Body className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Search */}
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                type="text"
                placeholder="Search content..."
                className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                value={searchTerm}
                onChange={handleSearch}
              />
            </div>
            
            {/* Category Filter (only for educational content) */}
            {activeTab === 'educational' && (
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Filter size={16} className="text-gray-400" />
                </div>
                <select
                  className="pl-10 p-2 w-full border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                >
                  <option value="all">All Categories</option>
                  <option value="nutrition">Nutrition</option>
                  <option value="fitness">Fitness</option>
                  <option value="mental-health">Mental Health</option>
                </select>
              </div>
            )}
            
            {/* Status */}
            <div className="text-right md:text-center">
              <span className="text-gray-600">
                Showing {
                  activeTab === 'educational' 
                    ? filteredEducationalContent.length 
                    : filteredMotivationalContent.length
                } of {
                  activeTab === 'educational' 
                    ? educationalContent.length 
                    : motivationalContent.length
                } items
              </span>
            </div>
          </div>
        </Card.Body>
      </Card>
      
      {/* Content List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {activeTab === 'educational' ? (
          filteredEducationalContent.length > 0 ? (
            filteredEducationalContent.map((content) => (
              <EducationalContentCard 
                key={content.id} 
                content={content} 
                onDelete={handleDeleteContent} 
              />
            ))
          ) : (
            <div className="col-span-2 p-8 text-center text-gray-500">
              No educational content found matching your criteria.
            </div>
          )
        ) : (
          filteredMotivationalContent.length > 0 ? (
            filteredMotivationalContent.map((content) => (
              <MotivationalContentCard 
                key={content.id} 
                content={content} 
                onDelete={handleDeleteContent} 
              />
            ))
          ) : (
            <div className="col-span-2 p-8 text-center text-gray-500">
              No motivational content found matching your criteria.
            </div>
          )
        )}
      </div>
    </div>
  );
};

interface EducationalContentCardProps {
  content: EducationalContent;
  onDelete: (id: string, type: ContentType) => void;
}

const EducationalContentCard: React.FC<EducationalContentCardProps> = ({ content, onDelete }) => {
  const getCategoryBadgeClasses = (category: string) => {
    switch (category) {
      case 'nutrition':
        return 'bg-green-100 text-green-800';
      case 'fitness':
        return 'bg-blue-100 text-blue-800';
      case 'mental-health':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const getCategoryName = (category: string) => {
    switch (category) {
      case 'nutrition':
        return 'Nutrition';
      case 'fitness':
        return 'Fitness';
      case 'mental-health':
        return 'Mental Health';
      default:
        return category;
    }
  };
  
  return (
    <Card className="h-full">
      <div className="h-40 overflow-hidden">
        <img 
          src={content.image} 
          alt={content.title} 
          className="w-full h-full object-cover"
        />
      </div>
      <Card.Body className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-gray-900">{content.title}</h3>
          <span className={`text-xs px-2 py-1 rounded-full ${getCategoryBadgeClasses(content.category)}`}>
            {getCategoryName(content.category)}
          </span>
        </div>
        
        <p className="text-sm text-gray-500 mb-2">
          By {content.author} • {new Date(content.createdAt).toLocaleDateString()}
        </p>
        
        <p className="text-gray-600 text-sm line-clamp-3 mb-3">
          {content.content.substring(0, 150)}...
        </p>
        
        <div className="flex justify-end space-x-2">
          <button className="text-indigo-600 hover:text-indigo-900">
            <Edit size={16} />
          </button>
          <button 
            className="text-red-600 hover:text-red-900"
            onClick={() => onDelete(content.id, 'educational')}
          >
            <Trash2 size={16} />
          </button>
        </div>
      </Card.Body>
    </Card>
  );
};

interface MotivationalContentCardProps {
  content: MotivationalContent;
  onDelete: (id: string, type: ContentType) => void;
}

const MotivationalContentCard: React.FC<MotivationalContentCardProps> = ({ content, onDelete }) => {
  return (
    <Card className="h-full">
      <div className="h-40 overflow-hidden">
        <img 
          src={content.image} 
          alt={content.title} 
          className="w-full h-full object-cover"
        />
      </div>
      <Card.Body className="p-4">
        <h3 className="font-semibold text-gray-900 mb-2">{content.title}</h3>
        
        <p className="text-sm text-gray-500 mb-2">
          By {content.author} • {new Date(content.createdAt).toLocaleDateString()}
        </p>
        
        <p className="text-gray-600 text-sm line-clamp-3 mb-3">
          {content.content.substring(0, 150)}...
        </p>
        
        <div className="flex justify-end space-x-2">
          <button className="text-indigo-600 hover:text-indigo-900">
            <Edit size={16} />
          </button>
          <button 
            className="text-red-600 hover:text-red-900"
            onClick={() => onDelete(content.id, 'motivational')}
          >
            <Trash2 size={16} />
          </button>
        </div>
      </Card.Body>
    </Card>
  );
};

export default AdminContent;