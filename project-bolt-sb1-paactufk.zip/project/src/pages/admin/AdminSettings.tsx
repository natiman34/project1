import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import Card from '../../components/ui/Card';
import Button from '../../components/ui/Button';
import { Save, Lock, User, Settings, MoonStar, Mail } from 'lucide-react';

const AdminSettings = () => {
  const { currentUser, updateProfile } = useAuth();
  const [activeTab, setActiveTab] = useState('account');
  const [accountForm, setAccountForm] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
  });
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    feedbackAlerts: true,
    systemUpdates: true,
    newUserRegistrations: currentUser?.role === 'admin_super',
  });
  const [appearanceSettings, setAppearanceSettings] = useState({
    theme: 'light',
    sidebar: 'expanded',
    compactMode: false,
  });
  
  const [accountSuccess, setAccountSuccess] = useState(false);
  const [passwordSuccess, setPasswordSuccess] = useState(false);
  const [notificationSuccess, setNotificationSuccess] = useState(false);
  const [appearanceSuccess, setAppearanceSuccess] = useState(false);
  
  const handleAccountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setAccountForm({ ...accountForm, [name]: value });
  };
  
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPasswordForm({ ...passwordForm, [name]: value });
  };
  
  const handleNotificationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setNotificationSettings({ ...notificationSettings, [name]: checked });
  };
  
  const handleAppearanceChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    const newValue = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setAppearanceSettings({ ...appearanceSettings, [name]: newValue });
  };
  
  const handleAccountSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // In a real app, this would call an API
      await updateProfile({ name: accountForm.name });
      setAccountSuccess(true);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setAccountSuccess(false);
      }, 3000);
    } catch (error) {
      console.error('Failed to update account', error);
    }
  };
  
  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    
    try {
      // In a real app, this would call an API
      // For demo purposes, we'll just show a success message
      setPasswordSuccess(true);
      setPasswordForm({
        currentPassword: '',
        newPassword: '',
        confirmPassword: '',
      });
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setPasswordSuccess(false);
      }, 3000);
    } catch (error) {
      console.error('Failed to update password', error);
    }
  };
  
  const handleNotificationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // In a real app, this would call an API
      setNotificationSuccess(true);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setNotificationSuccess(false);
      }, 3000);
    } catch (error) {
      console.error('Failed to update notification settings', error);
    }
  };
  
  const handleAppearanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // In a real app, this would call an API
      setAppearanceSuccess(true);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setAppearanceSuccess(false);
      }, 3000);
    } catch (error) {
      console.error('Failed to update appearance settings', error);
    }
  };
  
  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 mb-6">Settings</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Settings Navigation */}
        <div className="md:col-span-1">
          <Card>
            <Card.Body className="p-0">
              <nav className="divide-y divide-gray-200">
                <button
                  className={`w-full text-left px-4 py-3 flex items-center ${
                    activeTab === 'account' ? 'bg-green-50 text-green-700' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setActiveTab('account')}
                >
                  <User size={16} className="mr-3" />
                  Account Settings
                </button>
                <button
                  className={`w-full text-left px-4 py-3 flex items-center ${
                    activeTab === 'password' ? 'bg-green-50 text-green-700' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setActiveTab('password')}
                >
                  <Lock size={16} className="mr-3" />
                  Password
                </button>
                <button
                  className={`w-full text-left px-4 py-3 flex items-center ${
                    activeTab === 'notifications' ? 'bg-green-50 text-green-700' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setActiveTab('notifications')}
                >
                  <Mail size={16} className="mr-3" />
                  Notifications
                </button>
                <button
                  className={`w-full text-left px-4 py-3 flex items-center ${
                    activeTab === 'appearance' ? 'bg-green-50 text-green-700' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setActiveTab('appearance')}
                >
                  <MoonStar size={16} className="mr-3" />
                  Appearance
                </button>
                <button
                  className={`w-full text-left px-4 py-3 flex items-center ${
                    activeTab === 'admin' ? 'bg-green-50 text-green-700' : 'text-gray-600 hover:bg-gray-50'
                  }`}
                  onClick={() => setActiveTab('admin')}
                >
                  <Settings size={16} className="mr-3" />
                  Admin Controls
                </button>
              </nav>
            </Card.Body>
          </Card>
        </div>
        
        {/* Settings Content */}
        <div className="md:col-span-3">
          {/* Account Settings */}
          {activeTab === 'account' && (
            <Card>
              <Card.Body className="p-6">
                <h3 className="text-lg font-semibold mb-4">Account Settings</h3>
                
                {accountSuccess && (
                  <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md">
                    Account information updated successfully!
                  </div>
                )}
                
                <form onSubmit={handleAccountSubmit}>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={accountForm.name}
                        onChange={handleAccountChange}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Email Address
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={accountForm.email}
                        onChange={handleAccountChange}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                        disabled
                      />
                      <p className="text-xs text-gray-500 mt-1">
                        Email address cannot be changed directly. Please contact system administrator.
                      </p>
                    </div>
                    
                    <div className="pt-2">
                      <Button 
                        type="submit" 
                        variant="primary"
                        leftIcon={<Save size={16} />}
                      >
                        Save Changes
                      </Button>
                    </div>
                  </div>
                </form>
              </Card.Body>
            </Card>
          )}
          
          {/* Password Settings */}
          {activeTab === 'password' && (
            <Card>
              <Card.Body className="p-6">
                <h3 className="text-lg font-semibold mb-4">Change Password</h3>
                
                {passwordSuccess && (
                  <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md">
                    Password updated successfully!
                  </div>
                )}
                
                <form onSubmit={handlePasswordSubmit}>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="currentPassword" className="block text-sm font-medium text-gray-700 mb-1">
                        Current Password
                      </label>
                      <input
                        type="password"
                        id="currentPassword"
                        name="currentPassword"
                        value={passwordForm.currentPassword}
                        onChange={handlePasswordChange}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="newPassword" className="block text-sm font-medium text-gray-700 mb-1">
                        New Password
                      </label>
                      <input
                        type="password"
                        id="newPassword"
                        name="newPassword"
                        value={passwordForm.newPassword}
                        onChange={handlePasswordChange}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                        Confirm New Password
                      </label>
                      <input
                        type="password"
                        id="confirmPassword"
                        name="confirmPassword"
                        value={passwordForm.confirmPassword}
                        onChange={handlePasswordChange}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      />
                    </div>
                    
                    <div className="pt-2">
                      <Button 
                        type="submit" 
                        variant="primary"
                        leftIcon={<Save size={16} />}
                      >
                        Update Password
                      </Button>
                    </div>
                  </div>
                </form>
              </Card.Body>
            </Card>
          )}
          
          {/* Notification Settings */}
          {activeTab === 'notifications' && (
            <Card>
              <Card.Body className="p-6">
                <h3 className="text-lg font-semibold mb-4">Notification Settings</h3>
                
                {notificationSuccess && (
                  <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md">
                    Notification settings updated successfully!
                  </div>
                )}
                
                <form onSubmit={handleNotificationSubmit}>
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="emailNotifications"
                        name="emailNotifications"
                        checked={notificationSettings.emailNotifications}
                        onChange={handleNotificationChange}
                        className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                      />
                      <label htmlFor="emailNotifications" className="ml-2 block text-sm text-gray-700">
                        Receive Email Notifications
                      </label>
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="feedbackAlerts"
                        name="feedbackAlerts"
                        checked={notificationSettings.feedbackAlerts}
                        onChange={handleNotificationChange}
                        className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                      />
                      <label htmlFor="feedbackAlerts" className="ml-2 block text-sm text-gray-700">
                        New Feedback Alerts
                      </label>
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="systemUpdates"
                        name="systemUpdates"
                        checked={notificationSettings.systemUpdates}
                        onChange={handleNotificationChange}
                        className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                      />
                      <label htmlFor="systemUpdates" className="ml-2 block text-sm text-gray-700">
                        System Updates and Announcements
                      </label>
                    </div>
                    
                    {currentUser?.role === 'admin_super' && (
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          id="newUserRegistrations"
                          name="newUserRegistrations"
                          checked={notificationSettings.newUserRegistrations}
                          onChange={handleNotificationChange}
                          className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                        />
                        <label htmlFor="newUserRegistrations" className="ml-2 block text-sm text-gray-700">
                          New User Registration Alerts
                        </label>
                      </div>
                    )}
                    
                    <div className="pt-2">
                      <Button 
                        type="submit" 
                        variant="primary"
                        leftIcon={<Save size={16} />}
                      >
                        Save Settings
                      </Button>
                    </div>
                  </div>
                </form>
              </Card.Body>
            </Card>
          )}
          
          {/* Appearance Settings */}
          {activeTab === 'appearance' && (
            <Card>
              <Card.Body className="p-6">
                <h3 className="text-lg font-semibold mb-4">Appearance Settings</h3>
                
                {appearanceSuccess && (
                  <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md">
                    Appearance settings updated successfully!
                  </div>
                )}
                
                <form onSubmit={handleAppearanceSubmit}>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="theme" className="block text-sm font-medium text-gray-700 mb-1">
                        Theme
                      </label>
                      <select
                        id="theme"
                        name="theme"
                        value={appearanceSettings.theme}
                        onChange={handleAppearanceChange}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      >
                        <option value="light">Light</option>
                        <option value="dark">Dark</option>
                        <option value="system">System Default</option>
                      </select>
                    </div>
                    
                    <div>
                      <label htmlFor="sidebar" className="block text-sm font-medium text-gray-700 mb-1">
                        Sidebar Display
                      </label>
                      <select
                        id="sidebar"
                        name="sidebar"
                        value={appearanceSettings.sidebar}
                        onChange={handleAppearanceChange}
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      >
                        <option value="expanded">Expanded</option>
                        <option value="collapsed">Collapsed</option>
                        <option value="auto">Auto (Collapse on Small Screens)</option>
                      </select>
                    </div>
                    
                    <div className="flex items-center">
                      <input
                        type="checkbox"
                        id="compactMode"
                        name="compactMode"
                        checked={appearanceSettings.compactMode}
                        onChange={handleAppearanceChange}
                        className="h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                      />
                      <label htmlFor="compactMode" className="ml-2 block text-sm text-gray-700">
                        Compact Mode (Reduce Spacing)
                      </label>
                    </div>
                    
                    <div className="pt-2">
                      <Button 
                        type="submit" 
                        variant="primary"
                        leftIcon={<Save size={16} />}
                      >
                        Save Settings
                      </Button>
                    </div>
                  </div>
                </form>
              </Card.Body>
            </Card>
          )}
          
          {/* Admin Controls */}
          {activeTab === 'admin' && (
            <div className="space-y-6">
              <Card>
                <Card.Body className="p-6">
                  <h3 className="text-lg font-semibold mb-4">Admin Controls</h3>
                  
                  <div className="space-y-4">
                    {currentUser?.role === 'admin_super' ? (
                      <>
                        <div>
                          <Button 
                            variant="outline" 
                            className="w-full justify-between"
                          >
                            Application Backup
                            <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                              Last: 2 days ago
                            </span>
                          </Button>
                        </div>
                        
                        <div>
                          <Button 
                            variant="outline" 
                            className="w-full justify-between"
                          >
                            Maintenance Mode
                            <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                              Disabled
                            </span>
                          </Button>
                        </div>
                        
                        <div>
                          <Button 
                            variant="outline" 
                            className="w-full justify-between"
                          >
                            System Logs
                            <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                              10 new entries
                            </span>
                          </Button>
                        </div>
                        
                        <div>
                          <Button 
                            variant="outline" 
                            className="w-full justify-between"
                          >
                            Error Reports
                            <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                              No new reports
                            </span>
                          </Button>
                        </div>
                      </>
                    ) : (
                      <div className="text-center py-6 text-gray-500">
                        Advanced admin controls are only available to Super Admins.
                      </div>
                    )}
                  </div>
                </Card.Body>
              </Card>
              
              {currentUser?.role === 'admin_super' && (
                <Card>
                  <Card.Body className="p-6">
                    <h3 className="text-lg font-semibold mb-4 text-red-600">Danger Zone</h3>
                    
                    <div className="space-y-4">
                      <div className="border border-red-200 rounded-md p-4">
                        <h4 className="font-medium mb-2">Clear All Data Cache</h4>
                        <p className="text-sm text-gray-600 mb-3">
                          This will clear all cached data. The system will rebuild caches automatically.
                        </p>
                        <Button 
                          variant="outline" 
                          className="text-red-600 border-red-300 hover:bg-red-50"
                        >
                          Clear Cache
                        </Button>
                      </div>
                      
                      <div className="border border-red-200 rounded-md p-4">
                        <h4 className="font-medium mb-2">Reset All Settings</h4>
                        <p className="text-sm text-gray-600 mb-3">
                          This will reset all system settings to their default values.
                        </p>
                        <Button 
                          variant="outline" 
                          className="text-red-600 border-red-300 hover:bg-red-50"
                        >
                          Reset Settings
                        </Button>
                      </div>
                    </div>
                  </Card.Body>
                </Card>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;