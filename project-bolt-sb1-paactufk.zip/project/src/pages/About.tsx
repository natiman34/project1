import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { Check } from 'lucide-react';

const About = () => {
  return (
    <div className="min-h-screen pt-20 pb-16 bg-stone-50">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">About ሁልጊዜጤና Fitness</h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We're on a mission to improve health and wellness in Ethiopia through 
            culturally relevant fitness and nutrition guidance.
          </p>
        </div>
        
        {/* Our Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Our Story</h2>
            <p className="text-gray-700 mb-4">
              ሁልጊዜጤና Fitness was founded with a simple but powerful vision: to create a health 
              and wellness platform that truly understands and celebrates Ethiopian culture.
            </p>
            <p className="text-gray-700 mb-4">
              Our journey began when a group of Ethiopian fitness enthusiasts and nutritionists 
              recognized a significant gap in the health and fitness industry. Most available 
              resources were designed with Western diets and lifestyles in mind, overlooking 
              the rich culinary traditions and unique fitness needs of Ethiopians.
            </p>
            <p className="text-gray-700 mb-4">
              We believed that embracing our cultural heritage—rather than replacing it—was 
              the key to sustainable health. This belief led us to create a platform that 
              integrates traditional Ethiopian foods, movement patterns, and cultural wisdom 
              with modern nutritional science and exercise physiology.
            </p>
            <p className="text-gray-700">
              Today, ሁልጊዜጤና Fitness serves thousands of users, providing them with resources 
              that honor their cultural identity while supporting their health goals. Our name, 
              which means "Always Healthy" in Amharic, reflects our commitment to lifelong 
              wellness through culturally authentic approaches.
            </p>
          </div>
          <div className="relative h-[400px] rounded-xl overflow-hidden shadow-lg">
            <img 
              src="https://images.pexels.com/photos/6551758/pexels-photo-6551758.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
              alt="Our team working together" 
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
              <p className="text-white text-lg font-medium">
                Our dedicated team of health and fitness professionals
              </p>
            </div>
          </div>
        </div>
        
        {/* Mission & Values */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Mission & Values</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              We're guided by principles that put Ethiopian cultural context at the heart of everything we do.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card hover>
              <Card.Body className="text-center py-8 px-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-100 flex items-center justify-center">
                  <svg className="w-8 h-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">Cultural Authenticity</h3>
                <p className="text-gray-600">
                  We honor Ethiopian traditions and incorporate them into our approach to health and fitness, 
                  creating solutions that resonate with our cultural identity.
                </p>
              </Card.Body>
            </Card>
            
            <Card hover>
              <Card.Body className="text-center py-8 px-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-amber-100 flex items-center justify-center">
                  <svg className="w-8 h-8 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">Scientific Integrity</h3>
                <p className="text-gray-600">
                  We combine traditional wisdom with modern science, ensuring that our recommendations 
                  are both culturally relevant and scientifically sound.
                </p>
              </Card.Body>
            </Card>
            
            <Card hover>
              <Card.Body className="text-center py-8 px-6">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-red-100 flex items-center justify-center">
                  <svg className="w-8 h-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
                  </svg>
                </div>
                <h3 className="text-xl font-semibold mb-3">Community Empowerment</h3>
                <p className="text-gray-600">
                  We believe in building a supportive community that empowers individuals to take 
                  control of their health and inspire others to do the same.
                </p>
              </Card.Body>
            </Card>
          </div>
        </div>
        
        {/* Our Team */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Meet Our Expert Team</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Our diverse team of Ethiopian health and fitness professionals brings together 
              expertise in nutrition, exercise science, and cultural knowledge.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Team Member 1 */}
            <Card>
              <div className="h-64 overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/6551798/pexels-photo-6551798.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                  alt="Alem Tadesse" 
                  className="w-full h-full object-cover"
                />
              </div>
              <Card.Body className="text-center">
                <h3 className="font-bold text-lg">Alem Tadesse</h3>
                <p className="text-green-600 font-medium mb-2">Founder & CEO</p>
                <p className="text-gray-600 text-sm">
                  With 15+ years in the fitness industry, Alem combines her passion for Ethiopian 
                  culture with expertise in public health.
                </p>
              </Card.Body>
            </Card>
            
            {/* Team Member 2 */}
            <Card>
              <div className="h-64 overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/6551800/pexels-photo-6551800.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                  alt="Dawit Bekele" 
                  className="w-full h-full object-cover"
                />
              </div>
              <Card.Body className="text-center">
                <h3 className="font-bold text-lg">Dawit Bekele</h3>
                <p className="text-green-600 font-medium mb-2">Head Nutritionist</p>
                <p className="text-gray-600 text-sm">
                  A registered dietitian specializing in Ethiopian cuisine, Dawit develops our 
                  culturally tailored meal plans.
                </p>
              </Card.Body>
            </Card>
            
            {/* Team Member 3 */}
            <Card>
              <div className="h-64 overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/6551768/pexels-photo-6551768.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                  alt="Tigist Haile" 
                  className="w-full h-full object-cover"
                />
              </div>
              <Card.Body className="text-center">
                <h3 className="font-bold text-lg">Tigist Haile</h3>
                <p className="text-green-600 font-medium mb-2">Fitness Director</p>
                <p className="text-gray-600 text-sm">
                  A certified personal trainer and former athlete, Tigist creates workout programs 
                  that incorporate traditional Ethiopian movement patterns.
                </p>
              </Card.Body>
            </Card>
            
            {/* Team Member 4 */}
            <Card>
              <div className="h-64 overflow-hidden">
                <img 
                  src="https://images.pexels.com/photos/6232994/pexels-photo-6232994.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                  alt="Solomon Abebe" 
                  className="w-full h-full object-cover"
                />
              </div>
              <Card.Body className="text-center">
                <h3 className="font-bold text-lg">Solomon Abebe</h3>
                <p className="text-green-600 font-medium mb-2">Technology Lead</p>
                <p className="text-gray-600 text-sm">
                  With a background in health informatics, Solomon ensures that our platform 
                  delivers personalized health guidance to every user.
                </p>
              </Card.Body>
            </Card>
          </div>
        </div>
        
        {/* Our Approach */}
        <div className="mb-20">
          <div className="bg-white rounded-xl shadow-sm overflow-hidden">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="p-8 lg:p-12">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Our Approach</h2>
                <p className="text-gray-700 mb-6">
                  At ሁልጊዜጤና Fitness, we believe that effective health and fitness solutions must 
                  respect and incorporate Ethiopian cultural traditions. Our approach centers on 
                  three key principles:
                </p>
                
                <div className="space-y-4">
                  <div className="flex">
                    <div className="flex-shrink-0 mt-1">
                      <Check className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="ml-3">
                      <h3 className="font-medium text-gray-900">Cultural Integration</h3>
                      <p className="text-gray-600">
                        Rather than imposing foreign dietary guidelines or workout routines, we 
                        start with Ethiopian foods, movement patterns, and cultural practices as 
                        our foundation.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 mt-1">
                      <Check className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="ml-3">
                      <h3 className="font-medium text-gray-900">Evidence-Based Adaptations</h3>
                      <p className="text-gray-600">
                        We apply scientific principles to optimize traditional practices, helping 
                        you achieve your health goals while maintaining cultural connections.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 mt-1">
                      <Check className="h-5 w-5 text-green-600" />
                    </div>
                    <div className="ml-3">
                      <h3 className="font-medium text-gray-900">Community Support</h3>
                      <p className="text-gray-600">
                        We foster a supportive community that understands the unique cultural 
                        factors influencing health behaviors among Ethiopians.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8">
                  <Link to="/services">
                    <Button variant="primary">
                      Explore Our Services
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="bg-green-600">
                <img 
                  src="https://images.pexels.com/photos/6551139/pexels-photo-6551139.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                  alt="Our approach in action" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
        
        {/* Testimonials */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">What Our Members Say</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Hear from Ethiopians who have transformed their health with our culturally tailored approach.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <Card>
              <Card.Body className="p-6">
                <div className="flex items-center mb-4">
                  <div className="mr-4">
                    <img 
                      src="https://images.pexels.com/photos/6551771/pexels-photo-6551771.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                      alt="Meron Alemu" 
                      className="w-16 h-16 rounded-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Meron Alemu</h4>
                    <div className="flex text-amber-400">
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                    </div>
                  </div>
                </div>
                <blockquote className="text-gray-600 italic">
                  "For years I struggled with fitness programs that asked me to abandon my 
                  cultural foods. ሁልጊዜጤና Fitness showed me how to enjoy injera and wot while 
                  still reaching my health goals. I've lost 18kg and feel more connected to 
                  my roots than ever."
                </blockquote>
              </Card.Body>
            </Card>
            
            {/* Testimonial 2 */}
            <Card>
              <Card.Body className="p-6">
                <div className="flex items-center mb-4">
                  <div className="mr-4">
                    <img 
                      src="https://images.pexels.com/photos/6551770/pexels-photo-6551770.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                      alt="Yonas Kebede" 
                      className="w-16 h-16 rounded-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Yonas Kebede</h4>
                    <div className="flex text-amber-400">
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                    </div>
                  </div>
                </div>
                <blockquote className="text-gray-600 italic">
                  "The fitness plans that incorporate traditional Ethiopian dance movements 
                  have transformed my workout routine. I used to dread exercise, but now I 
                  look forward to it because it connects me to my heritage while improving 
                  my health."
                </blockquote>
              </Card.Body>
            </Card>
            
            {/* Testimonial 3 */}
            <Card>
              <Card.Body className="p-6">
                <div className="flex items-center mb-4">
                  <div className="mr-4">
                    <img 
                      src="https://images.pexels.com/photos/6551141/pexels-photo-6551141.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                      alt="Bethlehem Desta" 
                      className="w-16 h-16 rounded-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">Bethlehem Desta</h4>
                    <div className="flex text-amber-400">
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                      <span>★</span>
                    </div>
                  </div>
                </div>
                <blockquote className="text-gray-600 italic">
                  "As someone with a family history of diabetes, I was worried about my health. 
                  The nutritional guidance from ሁልጊዜጤና has helped me understand how to enjoy Ethiopian 
                  cuisine while managing my blood sugar. My latest check-up showed remarkable improvements!"
                </blockquote>
              </Card.Body>
            </Card>
          </div>
        </div>
        
        {/* CTA Section */}
        <div className="bg-green-700 rounded-xl text-white overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            <div className="p-8 lg:p-12">
              <h2 className="text-2xl font-bold mb-4">Join Our Community</h2>
              <p className="mb-6">
                Become part of a growing community of Ethiopians committed to improving their 
                health while honoring their cultural heritage. Together, we can build a 
                healthier future without losing touch with our roots.
              </p>
              <Link to="/register">
                <Button 
                  variant="secondary" 
                  size="lg"
                  className="bg-white text-green-700 hover:bg-gray-100"
                >
                  Sign Up Now
                </Button>
              </Link>
            </div>
            <div className="hidden lg:block relative">
              <img 
                src="https://images.pexels.com/photos/6551752/pexels-photo-6551752.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                alt="Join our community" 
                className="h-full w-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;