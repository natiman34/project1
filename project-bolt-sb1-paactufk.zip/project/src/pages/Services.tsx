import { useState } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { fitnessCategories, fitnessPlans, mealCategories, mealPlans, educationalContent, motivationalContent } from '../components/utils/MockData';
import Card from '../components/ui/Card';
import Button from '../components/ui/Button';
import FitnessPlans from './services/FitnessPlans';
import FitnessPlanDetail from './services/FitnessPlanDetail';
import NutritionPlans from './services/NutritionPlans';
import NutritionPlanDetail from './services/NutritionPlanDetail';
import MotivationalContent from './services/MotivationalContent';
import EducationalContent from './services/EducationalContent';
import EducationalContentDetail from './services/EducationalContentDetail';
import MotivationalContentDetail from './services/MotivationalContentDetail';

const Services = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Detect if we're on the main services page
  const isMainServicesPage = location.pathname === '/services' || location.pathname === '/services/';
  
  return (
    <div className="min-h-screen pt-20 pb-16 bg-stone-50">
      <div className="container mx-auto px-4">
        <Routes>
          <Route 
            path="/" 
            element={<ServicesMain />} 
          />
          <Route 
            path="/fitness" 
            element={<FitnessPlans categories={fitnessCategories} plans={fitnessPlans} />} 
          />
          <Route 
            path="/fitness/:id" 
            element={<FitnessPlanDetail plans={fitnessPlans} />} 
          />
          <Route 
            path="/nutrition" 
            element={<NutritionPlans categories={mealCategories} plans={mealPlans} />} 
          />
          <Route 
            path="/nutrition/:id" 
            element={<NutritionPlanDetail plans={mealPlans} />} 
          />
          <Route 
            path="/motivation" 
            element={<MotivationalContent content={motivationalContent} />} 
          />
          <Route 
            path="/motivation/:id" 
            element={<MotivationalContentDetail content={motivationalContent} />} 
          />
          <Route 
            path="/education" 
            element={<EducationalContent content={educationalContent} />} 
          />
          <Route 
            path="/education/:id" 
            element={<EducationalContentDetail content={educationalContent} />} 
          />
        </Routes>
        
        {/* Back button for non-main services pages */}
        {!isMainServicesPage && (
          <div className="mt-8">
            <Button 
              variant="outline" 
              onClick={() => navigate(-1)}
            >
              Back
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

const ServicesMain = () => {
  const navigate = useNavigate();
  
  const services = [
    {
      id: 'fitness',
      title: 'Fitness Plans',
      description: 'Discover culturally tailored workout programs designed by Ethiopian fitness experts',
      image: 'https://images.pexels.com/photos/4162435/pexels-photo-4162435.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      path: '/services/fitness'
    },
    {
      id: 'nutrition',
      title: 'Nutrition Plans',
      description: 'Explore meal plans featuring delicious Ethiopian foods that support your health goals',
      image: 'https://images.pexels.com/photos/5836781/pexels-photo-5836781.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      path: '/services/nutrition'
    },
    {
      id: 'motivation',
      title: 'Motivational Content',
      description: 'Find inspiration and motivation for your health and fitness journey',
      image: 'https://images.pexels.com/photos/7319228/pexels-photo-7319228.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      path: '/services/motivation'
    },
    {
      id: 'education',
      title: 'Educational Resources',
      description: 'Learn about nutrition, fitness, and health through an Ethiopian cultural lens',
      image: 'https://images.pexels.com/photos/8112590/pexels-photo-8112590.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750',
      path: '/services/education'
    }
  ];
  
  return (
    <div>
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Our Services</h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          Discover our comprehensive range of services designed to help you achieve your health and 
          fitness goals through culturally relevant Ethiopian approaches.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {services.map((service) => (
          <Card key={service.id} hover className="h-full">
            <Card.Image 
              src={service.image} 
              alt={service.title}
              className="h-48"
            />
            <Card.Body>
              <Card.Title className="mb-2">{service.title}</Card.Title>
              <p className="text-gray-600 mb-4">
                {service.description}
              </p>
              <Button 
                variant="primary"
                onClick={() => navigate(service.path)}
              >
                Explore
              </Button>
            </Card.Body>
          </Card>
        ))}
      </div>
      
      {/* Testimonials */}
      <div className="mt-20">
        <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
          What Our Members Are Saying
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card>
            <Card.Body>
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <img 
                    src="https://images.pexels.com/photos/6551790/pexels-photo-6551790.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                    alt="Member" 
                    className="w-14 h-14 rounded-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold">Yonas Kebede</h4>
                  <div className="flex text-amber-400">
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "The fitness plans here are perfect for me. I love that they incorporate traditional Ethiopian movements. 
                I've lost 12kg in 4 months following the weight loss program!"
              </p>
            </Card.Body>
          </Card>
          
          <Card>
            <Card.Body>
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <img 
                    src="https://images.pexels.com/photos/6551138/pexels-photo-6551138.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                    alt="Member" 
                    className="w-14 h-14 rounded-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold">Hiwot Tekle</h4>
                  <div className="flex text-amber-400">
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "I was struggling to find nutrition advice that made sense with my Ethiopian diet. 
                These meal plans have been life-changing - I can eat my favorite foods AND reach my fitness goals!"
              </p>
            </Card.Body>
          </Card>
          
          <Card>
            <Card.Body>
              <div className="flex items-center mb-4">
                <div className="mr-4">
                  <img 
                    src="https://images.pexels.com/photos/3764119/pexels-photo-3764119.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750" 
                    alt="Member" 
                    className="w-14 h-14 rounded-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold">Abebe Worku</h4>
                  <div className="flex text-amber-400">
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                    <span>★</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "The educational resources helped me understand nutrition in a way that respects our cultural 
                foods. I've completely changed my relationship with food and exercise."
              </p>
            </Card.Body>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Services;