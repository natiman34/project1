import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { UserRole, BMIResult } from '../types/user';

const BMI = () => {
  const { currentUser, updateProfile } = useAuth();
  const [height, setHeight] = useState<number | ''>('');
  const [weight, setWeight] = useState<number | ''>('');
  const [bmi, setBmi] = useState<number | null>(null);
  const [bmiCategory, setBmiCategory] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [success, setSuccess] = useState<boolean>(false);
  
  const calculateBMI = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess(false);
    
    if (height === '' || weight === '') {
      setError('Please enter both height and weight values.');
      return;
    }
    
    if (typeof height === 'number' && typeof weight === 'number') {
      // Height in m and weight in kg
      const heightInMeters = height / 100;
      const bmiValue = parseFloat((weight / (heightInMeters * heightInMeters)).toFixed(1));
      setBmi(bmiValue);
      
      // Determine BMI category
      let category = '';
      if (bmiValue < 18.5) {
        category = 'Underweight';
      } else if (bmiValue >= 18.5 && bmiValue < 25) {
        category = 'Normal weight';
      } else if (bmiValue >= 25 && bmiValue < 30) {
        category = 'Overweight';
      } else {
        category = 'Obesity';
      }
      
      setBmiCategory(category);
      setSuccess(true);
      
      // If user is logged in, save BMI result
      if (currentUser) {
        const newBmiResult: BMIResult = {
          id: Date.now().toString(),
          height,
          weight,
          bmi: bmiValue,
          category,
          date: new Date().toISOString(),
        };
        
        const updatedResults = [...(currentUser.bmiResults || []), newBmiResult];
        updateProfile({ bmiResults: updatedResults });
      }
    }
  };
  
  // Get Ethiopian food recommendations based on BMI category
  const getFoodRecommendations = () => {
    if (!bmiCategory) return [];
    
    switch (bmiCategory) {
      case 'Underweight':
        return [
          'Doro Wat (Ethiopian Chicken Stew) with extra chicken',
          'Shiro (chickpea stew) with injera',
          'Kik Alicha (yellow split pea stew) with olive oil',
          'Kitfo (minced raw beef) - a protein-rich dish',
          'Teff porridge with honey and nuts'
        ];
      case 'Normal weight':
        return [
          'Balanced injera with mixed vegetables',
          'Mesir Wat (red lentil stew)',
          'Gomen (collard greens)',
          'Tibs (sautéed meat) in moderate portions',
          'Bozena Shiro (chickpea stew with beef)'
        ];
      case 'Overweight':
        return [
          'Gomen (collard greens) without excess oil',
          'Atakilt Wat (cabbage, carrots, and potatoes)',
          'Tikil Gomen (cabbage stew)',
          'Azifa (green lentil salad)',
          'Smaller portions of injera with vegetable stews'
        ];
      case 'Obesity':
        return [
          'Salata (Ethiopian tomato salad)',
          'Fosolia (green beans and carrots)',
          'Ye`abesha Gomen (collard greens) without oil',
          'Alicha Vegetables (mild vegetable stew)',
          'Limited injera with vegetable-based dishes'
        ];
      default:
        return [];
    }
  };
  
  const getFitnessRecommendations = () => {
    if (!bmiCategory) return [];
    
    switch (bmiCategory) {
      case 'Underweight':
        return [
          'Strength training 3-4 times per week',
          'Focus on compound movements (squats, deadlifts)',
          'Moderate cardio (20 minutes, 2-3 times weekly)',
          'Ethiopian traditional dances for enjoyable activity',
          'Ensure adequate rest between workouts'
        ];
      case 'Normal weight':
        return [
          'Balanced workout routine (3-5 times weekly)',
          'Mix of strength training and cardio',
          'Ethiopian Eskista dance for cardio',
          'Regular hiking activities',
          'Focus on maintaining current habits'
        ];
      case 'Overweight':
        return [
          'Cardio exercises 4-5 times weekly (30-45 minutes)',
          'Strength training 2-3 times weekly',
          'Daily walking (10,000 steps goal)',
          'Traditional Ethiopian dances for fun cardio',
          'Consider group fitness classes for motivation'
        ];
      case 'Obesity':
        return [
          'Start with walking daily (15-30 minutes)',
          'Low-impact exercises like swimming',
          'Gentle strength training with professional guidance',
          'Focus on consistency rather than intensity',
          'Gradually increase duration as fitness improves'
        ];
      default:
        return [];
    }
  };
  
  return (
    <div className="min-h-screen pt-20 pb-16 bg-stone-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-2 text-center">BMI Calculator</h1>
          <p className="text-gray-600 mb-8 text-center">
            Check your Body Mass Index and get personalized Ethiopian food and fitness recommendations
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* BMI Calculator Form */}
            <Card className="h-full">
              <Card.Body>
                <h2 className="text-xl font-semibold mb-4">Calculate Your BMI</h2>
                
                {error && (
                  <div className="bg-red-50 text-red-700 p-3 rounded-md mb-4">
                    {error}
                  </div>
                )}
                
                <form onSubmit={calculateBMI}>
                  <div className="mb-4">
                    <label htmlFor="height" className="block text-sm font-medium text-gray-700 mb-1">
                      Height (cm)
                    </label>
                    <input
                      type="number"
                      id="height"
                      value={height}
                      onChange={(e) => setHeight(e.target.value ? parseFloat(e.target.value) : '')}
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      placeholder="e.g., 170"
                      min="50"
                      max="250"
                    />
                  </div>
                  
                  <div className="mb-6">
                    <label htmlFor="weight" className="block text-sm font-medium text-gray-700 mb-1">
                      Weight (kg)
                    </label>
                    <input
                      type="number"
                      id="weight"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value ? parseFloat(e.target.value) : '')}
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                      placeholder="e.g., 70"
                      min="20"
                      max="300"
                      step="0.1"
                    />
                  </div>
                  
                  <Button type="submit" variant="primary" fullWidth>
                    Calculate BMI
                  </Button>
                </form>
                
                {success && bmi !== null && (
                  <div className="mt-6 p-4 bg-green-50 rounded-lg">
                    <h3 className="font-semibold text-lg text-gray-900 mb-2">Your BMI Result</h3>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-700">BMI Value:</span>
                      <span className="font-semibold text-lg">{bmi}</span>
                    </div>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-gray-700">Category:</span>
                      <span 
                        className={`font-semibold ${
                          bmiCategory === 'Normal weight' 
                            ? 'text-green-600' 
                            : bmiCategory === 'Underweight' 
                              ? 'text-amber-600' 
                              : 'text-red-600'
                        }`}
                      >
                        {bmiCategory}
                      </span>
                    </div>
                  </div>
                )}
              </Card.Body>
            </Card>
            
            {/* BMI Info and Recommendations */}
            <div className="space-y-6">
              <Card>
                <Card.Body>
                  <h2 className="text-xl font-semibold mb-4">What is BMI?</h2>
                  <p className="text-gray-700 mb-3">
                    Body Mass Index (BMI) is a measurement that uses your height and weight to estimate how much body fat you have.
                  </p>
                  <p className="text-gray-700 mb-3">
                    While BMI is a useful screening tool, it does not diagnose body fatness or health.
                    A healthcare provider can help you interpret your results and consider other factors.
                  </p>
                  
                  <h3 className="font-medium text-gray-900 mt-4 mb-2">BMI Categories:</h3>
                  <ul className="space-y-2">
                    <li className="flex justify-between">
                      <span className="text-gray-700">Underweight:</span>
                      <span className="font-medium">Below 18.5</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-gray-700">Normal weight:</span>
                      <span className="font-medium">18.5 – 24.9</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-gray-700">Overweight:</span>
                      <span className="font-medium">25.0 – 29.9</span>
                    </li>
                    <li className="flex justify-between">
                      <span className="text-gray-700">Obesity:</span>
                      <span className="font-medium">30.0 and above</span>
                    </li>
                  </ul>
                </Card.Body>
              </Card>
              
              {success && bmi !== null && (
                <Card>
                  <Card.Body>
                    <h2 className="text-xl font-semibold mb-4">Your Personal Recommendations</h2>
                    
                    <div className="mb-4">
                      <h3 className="font-medium text-green-700 mb-2">Ethiopian Food Suggestions:</h3>
                      <ul className="space-y-1">
                        {getFoodRecommendations().map((food, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-green-500 mr-2">•</span>
                            <span className="text-gray-700">{food}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                    
                    <div>
                      <h3 className="font-medium text-green-700 mb-2">Fitness Recommendations:</h3>
                      <ul className="space-y-1">
                        {getFitnessRecommendations().map((activity, index) => (
                          <li key={index} className="flex items-start">
                            <span className="text-green-500 mr-2">•</span>
                            <span className="text-gray-700">{activity}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </Card.Body>
                </Card>
              )}
            </div>
          </div>
          
          {/* BMI Tracking Section for Logged In Users */}
          {currentUser && currentUser.bmiResults && currentUser.bmiResults.length > 0 && (
            <div className="mt-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Your BMI History</h2>
              
              <div className="overflow-x-auto">
                <table className="min-w-full bg-white rounded-lg overflow-hidden shadow">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Height (cm)</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Weight (kg)</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">BMI</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Category</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {[...currentUser.bmiResults]
                      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                      .map((result) => (
                        <tr key={result.id}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">
                            {new Date(result.date).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{result.height}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{result.weight}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">{result.bmi}</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm">
                            <span
                              className={`px-2 py-1 text-xs rounded-full ${
                                result.category === 'Normal weight' 
                                  ? 'bg-green-100 text-green-800' 
                                  : result.category === 'Underweight' 
                                    ? 'bg-amber-100 text-amber-800' 
                                    : 'bg-red-100 text-red-800'
                              }`}
                            >
                              {result.category}
                            </span>
                          </td>
                        </tr>
                      ))
                    }
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BMI;