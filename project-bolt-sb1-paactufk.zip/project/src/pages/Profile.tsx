import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import Button from '../components/ui/Button';
import Card from '../components/ui/Card';
import { User, UserRole } from '../types/user';

const Profile = () => {
  const { currentUser, updateProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [userData, setUserData] = useState<Partial<User>>({
    name: currentUser?.name || '',
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserData({ ...userData, [name]: value });
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!userData.name) {
      return setError('Name cannot be empty');
    }
    
    setError('');
    setSuccess('');
    setLoading(true);
    
    try {
      await updateProfile(userData);
      setSuccess('Profile updated successfully!');
      setIsEditing(false);
    } catch (err) {
      setError('Failed to update profile');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  
  const toggleEdit = () => {
    if (isEditing) {
      // Reset form if canceling edit
      setUserData({
        name: currentUser?.name || '',
      });
      setError('');
      setSuccess('');
    }
    setIsEditing(!isEditing);
  };
  
  if (!currentUser) return null;
  
  // Get the last BMI result if available
  const lastBmiResult = currentUser.bmiResults?.length > 0 
    ? currentUser.bmiResults.sort((a, b) => 
        new Date(b.date).getTime() - new Date(a.date).getTime()
      )[0] 
    : null;
  
  return (
    <div className="min-h-screen pt-28 pb-16 bg-stone-50">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Your Profile</h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Profile Card */}
            <div className="md:col-span-1">
              <Card>
                <Card.Body className="text-center py-8">
                  <div className="w-24 h-24 rounded-full bg-green-100 mx-auto mb-4 flex items-center justify-center">
                    <span className="text-3xl text-green-700 font-bold">
                      {currentUser.name.charAt(0).toUpperCase()}
                    </span>
                  </div>
                  
                  <h2 className="text-xl font-bold text-gray-900 mb-1">{currentUser.name}</h2>
                  <p className="text-gray-600 mb-4">{currentUser.email}</p>
                  
                  <div className="inline-block px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium mb-4">
                    {currentUser.role === UserRole.ADMIN_SUPER 
                      ? 'Super Admin' 
                      : currentUser.role === UserRole.ADMIN_NUTRITIONIST 
                        ? 'Nutritionist Admin'
                        : currentUser.role === UserRole.ADMIN_FITNESS
                          ? 'Fitness Admin'
                          : 'Member'}
                  </div>
                  
                  <div className="mt-4">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={toggleEdit}
                    >
                      {isEditing ? 'Cancel' : 'Edit Profile'}
                    </Button>
                  </div>
                </Card.Body>
              </Card>
            </div>
            
            {/* Main Content */}
            <div className="md:col-span-2">
              {/* Edit Profile Form */}
              {isEditing ? (
                <Card>
                  <Card.Body>
                    <h3 className="text-xl font-semibold mb-4">Edit Profile</h3>
                    
                    {error && (
                      <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md">
                        {error}
                      </div>
                    )}
                    
                    {success && (
                      <div className="mb-4 p-3 bg-green-50 text-green-700 rounded-md">
                        {success}
                      </div>
                    )}
                    
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                          Full Name
                        </label>
                        <input
                          id="name"
                          name="name"
                          type="text"
                          value={userData.name}
                          onChange={handleChange}
                          className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                        />
                      </div>
                      
                      <div className="pt-2">
                        <Button 
                          type="submit" 
                          variant="primary" 
                          isLoading={loading}
                          disabled={loading}
                        >
                          Save Changes
                        </Button>
                      </div>
                    </form>
                  </Card.Body>
                </Card>
              ) : (
                <>
                  {/* Profile Info */}
                  <Card className="mb-6">
                    <Card.Body>
                      <h3 className="text-xl font-semibold mb-4">Account Information</h3>
                      
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Email</h4>
                          <p className="mt-1">{currentUser.email}</p>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Account Type</h4>
                          <p className="mt-1">
                            {currentUser.role === UserRole.ADMIN_SUPER 
                              ? 'Super Administrator' 
                              : currentUser.role === UserRole.ADMIN_NUTRITIONIST 
                                ? 'Nutritionist Administrator'
                                : currentUser.role === UserRole.ADMIN_FITNESS
                                  ? 'Fitness Administrator'
                                  : 'Standard User'}
                          </p>
                        </div>
                        
                        <div>
                          <h4 className="text-sm font-medium text-gray-500">Member Since</h4>
                          <p className="mt-1">
                            {new Date(currentUser.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    </Card.Body>
                  </Card>
                  
                  {/* Health Summary */}
                  <Card>
                    <Card.Body>
                      <h3 className="text-xl font-semibold mb-4">Health Summary</h3>
                      
                      {lastBmiResult ? (
                        <div>
                          <div className="bg-green-50 rounded-lg p-4 mb-4">
                            <div className="flex items-center justify-between">
                              <div>
                                <h4 className="font-medium text-gray-900">Latest BMI Result</h4>
                                <p className="text-sm text-gray-500">
                                  {new Date(lastBmiResult.date).toLocaleDateString()}
                                </p>
                              </div>
                              <div className="text-right">
                                <p className="text-2xl font-bold text-green-700">{lastBmiResult.bmi}</p>
                                <span 
                                  className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                                    lastBmiResult.category === 'Normal weight' 
                                      ? 'bg-green-100 text-green-800' 
                                      : lastBmiResult.category === 'Underweight' 
                                        ? 'bg-amber-100 text-amber-800' 
                                        : 'bg-red-100 text-red-800'
                                  }`}
                                >
                                  {lastBmiResult.category}
                                </span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="space-y-3">
                            <div className="flex justify-between">
                              <span className="text-gray-600">Height</span>
                              <span className="font-medium">{lastBmiResult.height} cm</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-gray-600">Weight</span>
                              <span className="font-medium">{lastBmiResult.weight} kg</span>
                            </div>
                            <div className="border-t pt-3 mt-3">
                              <div className="flex justify-between items-center">
                                <span className="text-gray-600">BMI Measurements</span>
                                <span className="font-medium">{currentUser.bmiResults?.length || 0} total</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-6">
                          <p className="text-gray-500 mb-4">No BMI measurements yet</p>
                          <Button 
                            variant="primary" 
                            size="sm" 
                            onClick={() => window.location.href = '/bmi'}
                          >
                            Calculate Your BMI
                          </Button>
                        </div>
                      )}
                    </Card.Body>
                  </Card>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;