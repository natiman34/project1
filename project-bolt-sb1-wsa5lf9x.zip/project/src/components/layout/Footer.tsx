import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail, Phone, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-emerald-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Meri Ethiopian Fitness</h3>
            <p className="text-emerald-200 mb-4">
              Empowering Ethiopians with culturally relevant fitness and nutrition guidance for a healthier lifestyle.
            </p>
            <div className="flex space-x-4">
              <a href="https://facebook.com" className="hover:text-yellow-300 transition-colors" aria-label="Facebook">
                <Facebook size={20} />
              </a>
              <a href="https://twitter.com" className="hover:text-yellow-300 transition-colors" aria-label="Twitter">
                <Twitter size={20} />
              </a>
              <a href="https://instagram.com" className="hover:text-yellow-300 transition-colors" aria-label="Instagram">
                <Instagram size={20} />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/about" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  About Us
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  Services
                </Link>
              </li>
              <li>
                <Link to="/bmi" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  BMI Calculator
                </Link>
              </li>
              <li>
                <Link to="/contact" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Services</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  Nutrition Plans
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  Fitness Programs
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  Health Education
                </Link>
              </li>
              <li>
                <Link to="/services" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  Motivational Content
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <Phone size={16} className="mr-2" />
                <span className="text-emerald-200">+251 912 345 678</span>
              </li>
              <li className="flex items-center">
                <Mail size={16} className="mr-2" />
                <a href="mailto:info@meriefit.com" className="text-emerald-200 hover:text-yellow-300 transition-colors">
                  info@meriefit.com
                </a>
              </li>
              <li className="flex items-start">
                <MapPin size={16} className="mr-2 mt-1" />
                <span className="text-emerald-200">Bole Road, Addis Ababa, Ethiopia</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-emerald-700 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-emerald-300 text-sm">
            &copy; {new Date().getFullYear()} Meri Ethiopian Fitness. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <ul className="flex space-x-4 text-sm">
              <li>
                <Link to="/privacy" className="text-emerald-300 hover:text-yellow-300 transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-emerald-300 hover:text-yellow-300 transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;