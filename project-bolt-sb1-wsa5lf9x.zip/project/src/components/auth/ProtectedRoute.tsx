import React from 'react';
import { Navigate } from 'react-router-dom';
import { useUser, UserRole } from '../../contexts/UserContext';

interface ProtectedRouteProps {
  element: React.ReactNode;
  role?: UserRole;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ element, role }) => {
  const { user, isAuthenticated } = useUser();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (role && user?.role !== role) {
    return <Navigate to="/" replace />;
  }

  return <>{element}</>;
};

export default ProtectedRoute;