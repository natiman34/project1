import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Activity, Utensils, Brain, BookOpen } from 'lucide-react';

const Services: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'fitness' | 'nutrition' | 'motivation' | 'education'>('fitness');
  const [expandedPlan, setExpandedPlan] = useState<string | null>(null);

  const togglePlan = (planId: string) => {
    if (expandedPlan === planId) {
      setExpandedPlan(null);
    } else {
      setExpandedPlan(planId);
    }
  };

  // Mock data - in a real app, this would come from an API
  const fitnessPlans = [
    {
      id: 'fitness1',
      title: 'Beginner Ethiopian Dance Cardio',
      description: 'A 4-week program introducing cardio workouts based on traditional Ethiopian dance movements.',
      level: 'Beginner',
      duration: '4 weeks',
      frequency: '3 times per week',
      details: 'This program introduces you to the basics of Ethiopian dance as a form of cardio exercise. Each session is 30 minutes long and includes a warm-up, main workout, and cool-down. The movements are designed to improve your cardiovascular health while celebrating Ethiopian cultural dance traditions.'
    },
    {
      id: 'fitness2',
      title: 'Strength Training for All Levels',
      description: 'Build strength with this progressive program that can be done with minimal equipment.',
      level: 'All Levels',
      duration: '8 weeks',
      frequency: '4 times per week',
      details: 'This strength training program is designed to build muscle and increase overall strength. It includes bodyweight exercises that can be done at home, as well as options for those with access to weights. The program progressively increases in intensity over the 8 weeks.'
    },
    {
      id: 'fitness3',
      title: 'Advanced Habesha HIIT',
      description: 'High-intensity interval training with an Ethiopian twist for experienced fitness enthusiasts.',
      level: 'Advanced',
      duration: '6 weeks',
      frequency: '5 times per week',
      details: 'This high-intensity interval training program combines traditional Ethiopian movements with modern HIIT principles. Each session is 45 minutes long and designed to maximize calorie burn and improve cardiovascular fitness. This program is best suited for those with previous fitness experience.'
    }
  ];

  const nutritionPlans = [
    {
      id: 'nutrition1',
      title: 'Ethiopian Weight Loss Meal Plan',
      description: 'A balanced meal plan featuring Ethiopian dishes optimized for weight loss.',
      goal: 'Weight Loss',
      duration: 'Ongoing',
      details: 'This meal plan features traditional Ethiopian dishes modified to support weight loss goals. It includes portion control guidance, nutritional information, and suggestions for ingredient substitutions to reduce calories while maintaining flavor. The plan includes breakfast, lunch, dinner, and snack options.'
    },
    {
      id: 'nutrition2',
      title: 'Muscle Building Ethiopian Diet',
      description: 'High-protein meal options based on Ethiopian cuisine to support muscle growth.',
      goal: 'Muscle Gain',
      duration: 'Ongoing',
      details: 'This meal plan focuses on high-protein Ethiopian dishes to support muscle building goals. It includes traditional protein sources like misir wot (lentil stew) and doro wot (chicken stew), along with guidance on timing your meals around workouts for optimal results.'
    },
    {
      id: 'nutrition3',
      title: 'Balanced Ethiopian Family Nutrition',
      description: 'Family-friendly meal plans that balance tradition with optimal nutrition.',
      goal: 'Overall Health',
      duration: 'Ongoing',
      details: 'This comprehensive meal plan is designed for families looking to maintain a balanced diet while enjoying Ethiopian cuisine. It includes a variety of dishes to ensure nutritional diversity, with options for customization based on individual family members\' needs and preferences.'
    }
  ];

  const motivationalContent = [
    {
      id: 'motivation1',
      title: 'Finding Strength in Community',
      content: 'In Ethiopian culture, community is at the heart of everything we do. This same principle applies to fitness and health journeys. By connecting with others who share your goals, you create a support system that can help you through challenges and celebrate your victories. Remember the Ethiopian proverb: "When spider webs unite, they can tie up a lion." Your fitness community, whether online or in person, can help you achieve what might seem impossible alone.'
    },
    {
      id: 'motivation2',
      title: 'Embracing the Journey',
      content: 'In Ethiopian coffee ceremonies, we take time to appreciate each step of the process. Similarly, your fitness journey isn\'t just about the destination—it\'s about appreciating each step along the way. Every workout completed, every healthy meal prepared, and every small improvement is worthy of celebration. As we say in Amharic, "Chuhet chuhet Inkulal begru yihedul" (Step by step, an egg will walk). Progress happens gradually, but consistently.'
    },
    {
      id: 'motivation3',
      title: 'Resilience Through Challenges',
      content: 'Ethiopian history is filled with stories of resilience and perseverance. When facing challenges in your fitness journey, draw inspiration from this cultural strength. There will be days when motivation is low or progress seems slow, but continuing despite these obstacles builds not just physical strength, but mental fortitude as well. As the Ethiopian saying goes, "Keshoh belay tolo yelem" (There is nothing faster than patience). Trust the process and keep moving forward.'
    }
  ];

  const educationalContent = [
    {
      id: 'education1',
      title: 'Nutritional Benefits of Teff',
      content: 'Teff, the tiny grain used to make injera, is a nutritional powerhouse. It\'s high in protein, fiber, and minerals like iron and calcium. As a complex carbohydrate, it provides sustained energy for workouts and daily activities. Teff is also naturally gluten-free, making it suitable for those with celiac disease or gluten sensitivity. Incorporating teff into your diet can support muscle recovery, bone health, and overall energy levels.'
    },
    {
      id: 'education2',
      title: 'The Health Benefits of Ethiopian Spices',
      content: 'Ethiopian cuisine is known for its complex spice blends, many of which offer significant health benefits. Berbere, a staple spice blend, contains paprika, fenugreek, and other spices with anti-inflammatory properties. Turmeric, often used in Ethiopian cooking, contains curcumin, which has been studied for its potential benefits for joint health and recovery. Even korerima (Ethiopian cardamom) may help with digestion and has antioxidant properties.'
    },
    {
      id: 'education3',
      title: 'Balancing Traditional Foods with Fitness Goals',
      content: 'Ethiopian cuisine can be adapted to support various fitness goals. For weight loss, focus on vegetable-based wots (stews) and control portions of injera. For muscle building, emphasize protein-rich dishes like misir wot (lentil stew) and doro wot (chicken stew). The key is understanding the nutritional content of traditional foods and adjusting portions and preparation methods to align with your goals, while still honoring the cultural significance and flavors of these dishes.'
    }
  ];

  return (
    <div className="bg-emerald-50">
      {/* Hero Section */}
      <section className="relative bg-emerald-700 text-white py-20">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/6551141/pexels-photo-6551141.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Our Services
            </motion.h1>
            <motion.p 
              className="text-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Discover our comprehensive range of fitness programs, nutrition plans, and educational resources designed with Ethiopian culture in mind.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Services Navigation */}
      <section className="bg-white py-8 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center space-x-2 md:space-x-6">
            <button
              onClick={() => setActiveTab('fitness')}
              className={`flex items-center px-4 py-2 rounded-md mb-2 ${
                activeTab === 'fitness'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
              } transition-colors`}
            >
              <Activity size={20} className="mr-2" />
              Fitness Plans
            </button>
            <button
              onClick={() => setActiveTab('nutrition')}
              className={`flex items-center px-4 py-2 rounded-md mb-2 ${
                activeTab === 'nutrition'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
              } transition-colors`}
            >
              <Utensils size={20} className="mr-2" />
              Nutrition Plans
            </button>
            <button
              onClick={() => setActiveTab('motivation')}
              className={`flex items-center px-4 py-2 rounded-md mb-2 ${
                activeTab === 'motivation'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
              } transition-colors`}
            >
              <Brain size={20} className="mr-2" />
              Motivational Content
            </button>
            <button
              onClick={() => setActiveTab('education')}
              className={`flex items-center px-4 py-2 rounded-md mb-2 ${
                activeTab === 'education'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
              } transition-colors`}
            >
              <BookOpen size={20} className="mr-2" />
              Educational Tips
            </button>
          </div>
        </div>
      </section>

      {/* Content Sections */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Fitness Plans */}
          {activeTab === 'fitness' && (
            <div>
              <h2 className="text-3xl font-bold text-emerald-800 mb-8 text-center">Fitness Programs</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {fitnessPlans.map((plan) => (
                  <div key={plan.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div className="p-6">
                      <h3 className="text-xl font-semibold mb-2 text-emerald-800">{plan.title}</h3>
                      <p className="text-gray-700 mb-4">{plan.description}</p>
                      <div className="flex flex-wrap mb-4">
                        <span className="bg-emerald-100 text-emerald-800 text-xs font-semibold px-2.5 py-0.5 rounded mr-2 mb-2">
                          {plan.level}
                        </span>
                        <span className="bg-emerald-100 text-emerald-800 text-xs font-semibold px-2.5 py-0.5 rounded mr-2 mb-2">
                          {plan.duration}
                        </span>
                        <span className="bg-emerald-100 text-emerald-800 text-xs font-semibold px-2.5 py-0.5 rounded mb-2">
                          {plan.frequency}
                        </span>
                      </div>
                      <button
                        onClick={() => togglePlan(plan.id)}
                        className="flex items-center justify-between w-full text-emerald-600 hover:text-emerald-700 font-medium"
                      >
                        <span>{expandedPlan === plan.id ? 'Show Less' : 'Show More'}</span>
                        <ChevronDown
                          size={20}
                          className={`transition-transform duration-300 ${
                            expandedPlan === plan.id ? 'rotate-180' : ''
                          }`}
                        />
                      </button>
                      {expandedPlan === plan.id && (
                        <div className="mt-4 pt-4 border-t border-gray-200">
                          <p className="text-gray-700">{plan.details}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Nutrition Plans */}
          {activeTab === 'nutrition' && (
            <div>
              <h2 className="text-3xl font-bold text-emerald-800 mb-8 text-center">Nutrition Plans</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {nutritionPlans.map((plan) => (
                  <div key={plan.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
                    <div className="p-6">
                      <h3 className="text-xl font-semibold mb-2 text-emerald-800">{plan.title}</h3>
                      <p className="text-gray-700 mb-4">{plan.description}</p>
                      <div className="flex flex-wrap mb-4">
                        <span className="bg-emerald-100 text-emerald-800 text-xs font-semibold px-2.5 py-0.5 rounded mr-2 mb-2">
                          Goal: {plan.goal}
                        </span>
                        <span className="bg-emerald-100 text-emerald-800 text-xs font-semibold px-2.5 py-0.5 rounded mb-2">
                          {plan.duration}
                        </span>
                      </div>
                      <button
                        onClick={() => togglePlan(plan.id)}
                        className="flex items-center justify-between w-full text-emerald-600 hover:text-emerald-700 font-medium"
                      >
                        <span>{expandedPlan === plan.id ? 'Show Less' : 'Show More'}</span>
                        <ChevronDown
                          size={20}
                          className={`transition-transform duration-300 ${
                            expandedPlan === plan.id ? 'rotate-180' : ''
                          }`}
                        />
                      </button>
                      {expandedPlan === plan.id && (
                        <div className="mt-4 pt-4 border-t border-gray-200">
                          <p className="text-gray-700">{plan.details}</p>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Motivational Content */}
          {activeTab === 'motivation' && (
            <div>
              <h2 className="text-3xl font-bold text-emerald-800 mb-8 text-center">Motivational Content</h2>
              <div className="space-y-8 max-w-4xl mx-auto">
                {motivationalContent.map((item) => (
                  <div key={item.id} className="bg-white rounded-lg shadow-sm p-6">
                    <h3 className="text-xl font-semibold mb-4 text-emerald-800">{item.title}</h3>
                    <p className="text-gray-700">{item.content}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Educational Tips */}
          {activeTab === 'education' && (
            <div>
              <h2 className="text-3xl font-bold text-emerald-800 mb-8 text-center">Educational Tips</h2>
              <div className="space-y-8 max-w-4xl mx-auto">
                {educationalContent.map((item) => (
                  <div key={item.id} className="bg-white rounded-lg shadow-sm p-6">
                    <h3 className="text-xl font-semibold mb-4 text-emerald-800">{item.title}</h3>
                    <p className="text-gray-700">{item.content}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Transform Your Health?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join Meri Ethiopian Fitness today and get access to all our fitness programs, nutrition plans, and educational resources.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a
              href="/signup"
              className="bg-yellow-500 hover:bg-yellow-400 text-emerald-900 font-bold py-3 px-8 rounded-md transition-colors"
            >
              Sign Up Now
            </a>
            <a
              href="/contact"
              className="bg-transparent hover:bg-emerald-600 text-white font-semibold py-3 px-8 border border-white rounded-md transition-colors"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;