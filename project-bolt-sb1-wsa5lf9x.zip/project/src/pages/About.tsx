import React from 'react';
import { motion } from 'framer-motion';
import { Users, Award, Heart, Globe } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="bg-emerald-50">
      {/* Hero Section */}
      <section className="relative bg-emerald-700 text-white py-20">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/6551096/pexels-photo-6551096.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              About Meri Ethiopian Fitness
            </motion.h1>
            <motion.p 
              className="text-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Bridging traditional Ethiopian wellness practices with modern fitness science for a healthier community.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-emerald-800 mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                Meri Ethiopian Fitness was founded in 2023 with a simple mission: to create a fitness and nutrition platform that honors Ethiopian culture while incorporating modern health science.
              </p>
              <p className="text-gray-700 mb-4">
                Our founder, Meron Abebe, a certified nutritionist and fitness trainer, noticed a gap in the wellness industry. While there were many fitness apps and nutrition guides available, none addressed the unique dietary patterns and cultural practices of Ethiopians.
              </p>
              <p className="text-gray-700">
                With a team of Ethiopian nutritionists, fitness experts, and health educators, we've created a platform that provides culturally relevant fitness programs, nutrition plans based on traditional Ethiopian foods, and health education that resonates with our community.
              </p>
            </div>
            <div className="rounded-lg overflow-hidden shadow-lg">
              <img 
                src="https://images.pexels.com/photos/6551415/pexels-photo-6551415.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Team meeting" 
                className="w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Values Section */}
      <section className="py-16 bg-emerald-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-emerald-800 mb-4">Our Mission & Values</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              We're committed to improving the health and wellbeing of Ethiopians through culturally relevant fitness and nutrition guidance.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-emerald-600 mb-4">
                <Heart size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Cultural Relevance</h3>
              <p className="text-gray-700">
                We honor Ethiopian traditions and incorporate them into modern fitness and nutrition practices.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-emerald-600 mb-4">
                <Award size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Excellence</h3>
              <p className="text-gray-700">
                We strive for excellence in all our services, backed by scientific research and expert knowledge.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-emerald-600 mb-4">
                <Users size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Community</h3>
              <p className="text-gray-700">
                We build a supportive community where members can share experiences and motivate each other.
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="text-emerald-600 mb-4">
                <Globe size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Accessibility</h3>
              <p className="text-gray-700">
                We make health and fitness information accessible to all Ethiopians, regardless of location or background.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-emerald-800 mb-4">Our Team</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Meet the experts behind Meri Ethiopian Fitness who are passionate about bringing you the best in health and wellness.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-emerald-50 rounded-lg overflow-hidden shadow-sm">
              <img 
                src="https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Meron Abebe" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1 text-emerald-800">Meron Abebe</h3>
                <p className="text-emerald-600 mb-3">Founder & CEO</p>
                <p className="text-gray-700">
                  Certified nutritionist and fitness trainer with over 10 years of experience in the health and wellness industry.
                </p>
              </div>
            </div>
            <div className="bg-emerald-50 rounded-lg overflow-hidden shadow-sm">
              <img 
                src="https://images.pexels.com/photos/6551094/pexels-photo-6551094.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Dawit Bekele" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1 text-emerald-800">Dawit Bekele</h3>
                <p className="text-emerald-600 mb-3">Head of Fitness</p>
                <p className="text-gray-700">
                  Former Olympic athlete and certified personal trainer specializing in strength training and cardio workouts.
                </p>
              </div>
            </div>
            <div className="bg-emerald-50 rounded-lg overflow-hidden shadow-sm">
              <img 
                src="https://images.pexels.com/photos/7991577/pexels-photo-7991577.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Sara Haile" 
                className="w-full h-64 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1 text-emerald-800">Sara Haile</h3>
                <p className="text-emerald-600 mb-3">Head of Nutrition</p>
                <p className="text-gray-700">
                  Registered dietitian with expertise in Ethiopian cuisine and its nutritional properties.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-emerald-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-emerald-800 mb-4">Frequently Asked Questions</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Find answers to common questions about our services and approach.
            </p>
          </div>
          <div className="max-w-3xl mx-auto">
            <div className="mb-6 bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">How are your nutrition plans different?</h3>
              <p className="text-gray-700">
                Our nutrition plans are uniquely designed around traditional Ethiopian foods and eating patterns. We provide detailed nutritional information for Ethiopian dishes and offer modifications to make them more aligned with various fitness goals.
              </p>
            </div>
            <div className="mb-6 bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Do I need special equipment for the workouts?</h3>
              <p className="text-gray-700">
                Most of our workout routines require minimal equipment and can be done at home. For those who have access to a gym, we offer alternative exercises that utilize gym equipment.
              </p>
            </div>
            <div className="mb-6 bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">How often are new plans added?</h3>
              <p className="text-gray-700">
                We add new fitness and nutrition plans monthly. Our team is constantly researching and developing content that is both effective and culturally relevant.
              </p>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Can I use the app if I'm not Ethiopian?</h3>
              <p className="text-gray-700">
                Absolutely! While our content is designed with Ethiopian culture in mind, anyone interested in exploring Ethiopian cuisine and fitness approaches is welcome to join our community.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;