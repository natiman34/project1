import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Calculator, Info, ArrowRight } from 'lucide-react';
import { useUser } from '../contexts/UserContext';

const BMI: React.FC = () => {
  const { user, updateUser, isAuthenticated } = useUser();
  const [height, setHeight] = useState<string>('');
  const [weight, setWeight] = useState<string>('');
  const [bmiResult, setBmiResult] = useState<number | null>(null);
  const [bmiCategory, setBmiCategory] = useState<string>('');
  const [showInfo, setShowInfo] = useState<boolean>(false);

  const calculateBMI = (e: React.FormEvent) => {
    e.preventDefault();
    
    const heightInMeters = parseFloat(height) / 100;
    const weightInKg = parseFloat(weight);
    
    if (isNaN(heightInMeters) || isNaN(weightInKg) || heightInMeters <= 0 || weightInKg <= 0) {
      alert('Please enter valid height and weight values.');
      return;
    }
    
    const bmi = weightInKg / (heightInMeters * heightInMeters);
    const roundedBMI = Math.round(bmi * 10) / 10;
    
    setBmiResult(roundedBMI);
    
    // Determine BMI category
    if (roundedBMI < 18.5) {
      setBmiCategory('Underweight');
    } else if (roundedBMI >= 18.5 && roundedBMI < 25) {
      setBmiCategory('Normal weight');
    } else if (roundedBMI >= 25 && roundedBMI < 30) {
      setBmiCategory('Overweight');
    } else {
      setBmiCategory('Obesity');
    }
    
    // Update user's BMI result if authenticated
    if (isAuthenticated && user) {
      updateUser({ bmiResult: roundedBMI });
    }
  };

  const getBMICategoryColor = () => {
    switch (bmiCategory) {
      case 'Underweight':
        return 'text-blue-600';
      case 'Normal weight':
        return 'text-green-600';
      case 'Overweight':
        return 'text-yellow-600';
      case 'Obesity':
        return 'text-red-600';
      default:
        return '';
    }
  };

  const toggleInfo = () => {
    setShowInfo(!showInfo);
  };

  return (
    <div className="bg-emerald-50">
      {/* Hero Section */}
      <section className="relative bg-emerald-700 text-white py-20">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/6551415/pexels-photo-6551415.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              BMI Calculator
            </motion.h1>
            <motion.p 
              className="text-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Calculate your Body Mass Index (BMI) and get personalized recommendations based on your results.
            </motion.p>
          </div>
        </div>
      </section>

      {/* BMI Calculator Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            <div>
              <div className="bg-white rounded-lg shadow-sm p-8">
                <div className="flex items-center mb-6">
                  <Calculator className="h-8 w-8 text-emerald-600 mr-3" />
                  <h2 className="text-2xl font-bold text-emerald-800">Calculate Your BMI</h2>
                </div>
                
                <form onSubmit={calculateBMI} className="space-y-6">
                  <div>
                    <label htmlFor="height" className="block text-sm font-medium text-gray-700 mb-1">
                      Height (cm)
                    </label>
                    <input
                      type="number"
                      id="height"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      required
                      min="1"
                      placeholder="e.g., 170"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="weight" className="block text-sm font-medium text-gray-700 mb-1">
                      Weight (kg)
                    </label>
                    <input
                      type="number"
                      id="weight"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      required
                      min="1"
                      step="0.1"
                      placeholder="e.g., 70"
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
                    />
                  </div>
                  
                  <div>
                    <button
                      type="submit"
                      className="w-full flex justify-center items-center px-4 py-3 border border-transparent rounded-md shadow-sm text-base font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
                    >
                      Calculate BMI
                    </button>
                  </div>
                </form>
                
                {bmiResult !== null && (
                  <div className="mt-8 pt-6 border-t border-gray-200">
                    <h3 className="text-xl font-semibold mb-4 text-emerald-800">Your Results</h3>
                    <div className="bg-emerald-50 p-4 rounded-md">
                      <p className="text-gray-700 mb-2">
                        Your BMI is: <span className="font-bold text-emerald-700">{bmiResult}</span>
                      </p>
                      <p className="text-gray-700">
                        Category: <span className={`font-bold ${getBMICategoryColor()}`}>{bmiCategory}</span>
                      </p>
                    </div>
                    
                    <div className="mt-6">
                      <h4 className="font-semibold text-emerald-800 mb-2">What this means:</h4>
                      <p className="text-gray-700 mb-4">
                        {bmiCategory === 'Underweight' && 'You may need to gain some weight. Consider consulting with a nutritionist for a healthy weight gain plan.'}
                        {bmiCategory === 'Normal weight' && 'Your weight is within the healthy range. Maintain your current lifestyle with a balanced diet and regular exercise.'}
                        {bmiCategory === 'Overweight' && 'You may benefit from losing some weight. Focus on a balanced diet and regular physical activity.'}
                        {bmiCategory === 'Obesity' && 'It\'s recommended to lose weight to reduce health risks. Consider consulting with healthcare professionals for a personalized plan.'}
                      </p>
                      
                      {!isAuthenticated && (
                        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4">
                          <div className="flex">
                            <div className="flex-shrink-0">
                              <Info className="h-5 w-5 text-yellow-400" />
                            </div>
                            <div className="ml-3">
                              <p className="text-sm text-yellow-700">
                                <a href="/signup" className="font-medium text-yellow-700 underline">Sign up</a> or <a href="/login" className="font-medium text-yellow-700 underline">log in</a> to save your BMI results and get personalized recommendations.
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center">
                    <Info className="h-6 w-6 text-emerald-600 mr-3" />
                    <h2 className="text-2xl font-bold text-emerald-800">About BMI</h2>
                  </div>
                  <button
                    onClick={toggleInfo}
                    className="text-emerald-600 hover:text-emerald-700 font-medium flex items-center"
                  >
                    {showInfo ? 'Show Less' : 'Show More'}
                    <ArrowRight size={16} className={`ml-1 transition-transform duration-300 ${showInfo ? 'rotate-90' : ''}`} />
                  </button>
                </div>
                
                <p className="text-gray-700 mb-4">
                  Body Mass Index (BMI) is a simple calculation using a person's height and weight. The formula is BMI = kg/m² where kg is a person's weight in kilograms and m² is their height in meters squared.
                </p>
                
                {showInfo && (
                  <div className="mt-4 space-y-4">
                    <p className="text-gray-700">
                      BMI is an inexpensive and easy-to-perform method of screening for weight categories that may lead to health problems. However, it is important to remember that BMI is only one factor in determining overall health.
                    </p>
                    
                    <h3 className="text-lg font-semibold text-emerald-800 mt-6 mb-2">BMI Categories:</h3>
                    <ul className="list-disc list-inside space-y-2 text-gray-700">
                      <li><span className="font-medium text-blue-600">Underweight</span>: BMI less than 18.5</li>
                      <li><span className="font-medium text-green-600">Normal weight</span>: BMI 18.5 to 24.9</li>
                      <li><span className="font-medium text-yellow-600">Overweight</span>: BMI 25 to 29.9</li>
                      <li><span className="font-medium text-red-600">Obesity</span>: BMI 30 or greater</li>
                    </ul>
                    
                    <h3 className="text-lg font-semibold text-emerald-800 mt-6 mb-2">Limitations of BMI:</h3>
                    <p className="text-gray-700">
                      BMI does not directly measure body fat and doesn't account for factors such as:
                    </p>
                    <ul className="list-disc list-inside space-y-2 text-gray-700">
                      <li>Muscle mass (athletes may have a high BMI due to increased muscle mass)</li>
                      <li>Age (older adults tend to have more body fat than younger adults with the same BMI)</li>
                      <li>Gender (women generally have more body fat than men with the same BMI)</li>
                      <li>Ethnicity (different ethnic groups may have different associations between BMI and body fat)</li>
                    </ul>
                    
                    <p className="text-gray-700 mt-4">
                      For a more comprehensive assessment of your health, it's recommended to consult with healthcare professionals who can consider multiple factors beyond BMI.
                    </p>
                  </div>
                )}
              </div>
              
              <div className="bg-emerald-600 rounded-lg shadow-sm p-8 text-white">
                <h3 className="text-xl font-semibold mb-4">Ethiopian Perspective on Health</h3>
                <p className="mb-4">
                  Traditional Ethiopian culture emphasizes the importance of balanced nutrition through diverse foods like injera (made from teff, a nutritious grain), various wots (stews), and fresh vegetables.
                </p>
                <p className="mb-4">
                  Physical activity has historically been integrated into daily life through activities like traditional dance, which combines cultural expression with cardiovascular exercise.
                </p>
                <p>
                  At Meri Ethiopian Fitness, we blend these traditional approaches with modern health science to create a holistic approach to wellness that honors Ethiopian heritage.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Recommendations Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-emerald-800 mb-4">Personalized Recommendations</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Based on your BMI, here are some Ethiopian-inspired recommendations to help you achieve your health goals.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-emerald-50 rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-semibold mb-4 text-emerald-800 border-b border-emerald-200 pb-2">For Weight Loss</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Focus on vegetable-based Ethiopian wots like misir wot (lentil stew) and gomen (collard greens)</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Limit injera portions to one piece per meal</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Incorporate Ethiopian dance movements into your cardio routine</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Stay hydrated with Ethiopian spiced tea (without sugar)</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Try our "Beginner Ethiopian Dance Cardio" program</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-emerald-50 rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-semibold mb-4 text-emerald-800 border-b border-emerald-200 pb-2">For Maintenance</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Balance your plate with equal portions of injera, protein, and vegetables</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Enjoy traditional Ethiopian coffee in moderation</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Maintain regular physical activity with a mix of cardio and strength training</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Practice mindful eating during traditional Ethiopian communal meals</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Try our "Balanced Ethiopian Family Nutrition" plan</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-emerald-50 rounded-lg p-6 shadow-sm">
              <h3 className="text-xl font-semibold mb-4 text-emerald-800 border-b border-emerald-200 pb-2">For Weight Gain</h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Increase portions of protein-rich dishes like doro wot (chicken stew)</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Add extra niter kibbeh (spiced clarified butter) to your meals</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Incorporate strength training to build muscle mass</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Enjoy nutrient-dense snacks like kolo (roasted barley) with nuts</span>
                </li>
                <li className="flex items-start">
                  <span className="text-emerald-600 mr-2">•</span>
                  <span>Try our "Muscle Building Ethiopian Diet" plan</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready for a Personalized Plan?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Sign up to get access to customized fitness and nutrition plans based on your BMI and personal goals.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <a
              href="/signup"
              className="bg-yellow-500 hover:bg-yellow-400 text-emerald-900 font-bold py-3 px-8 rounded-md transition-colors"
            >
              Sign Up Now
            </a>
            <a
              href="/services"
              className="bg-transparent hover:bg-emerald-600 text-white font-semibold py-3 px-8 border border-white rounded-md transition-colors"
            >
              Explore Services
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default BMI;