import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ChevronDown, Activity, Utensils, Heart, Award, Users } from 'lucide-react';

const Home: React.FC = () => {
  const [showMore, setShowMore] = useState(false);

  const toggleShowMore = () => {
    setShowMore(!showMore);
  };

  return (
    <div className="bg-emerald-50">
      {/* Hero Section */}
      <section className="relative bg-emerald-700 text-white">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/6551133/pexels-photo-6551133.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 relative z-10">
          <div className="max-w-3xl">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Ethiopian-Inspired Fitness & Nutrition
            </motion.h1>
            <motion.p 
              className="text-xl mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Discover culturally relevant fitness programs and nutrition plans based on traditional Ethiopian foods and practices.
            </motion.p>
            <motion.div 
              className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Link
                to="/signup"
                className="bg-yellow-500 hover:bg-yellow-400 text-emerald-900 font-bold py-3 px-6 rounded-md transition-colors text-center"
              >
                Sign Up Free
              </Link>
              <button
                onClick={toggleShowMore}
                className="bg-transparent hover:bg-emerald-600 text-white font-semibold py-3 px-6 border border-white rounded-md transition-colors flex items-center justify-center"
              >
                Learn More
                <ChevronDown size={20} className={`ml-2 transition-transform duration-300 ${showMore ? 'rotate-180' : ''}`} />
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Learn More Section */}
      {showMore && (
        <motion.section 
          className="bg-white py-12"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          transition={{ duration: 0.5 }}
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-center mb-12 text-emerald-800">Why Choose Meri Ethiopian Fitness?</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-emerald-50 p-6 rounded-lg">
                <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Utensils className="text-emerald-600" size={28} />
                </div>
                <h3 className="text-xl font-semibold text-center mb-3 text-emerald-800">Ethiopian Nutrition</h3>
                <p className="text-gray-700 text-center">
                  Nutrition plans based on traditional Ethiopian foods like injera, shiro, and berbere spices, optimized for your fitness goals.
                </p>
              </div>
              <div className="bg-emerald-50 p-6 rounded-lg">
                <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Activity className="text-emerald-600" size={28} />
                </div>
                <h3 className="text-xl font-semibold text-center mb-3 text-emerald-800">Customized Fitness</h3>
                <p className="text-gray-700 text-center">
                  Workout routines that incorporate traditional Ethiopian movements and modern exercise science for optimal results.
                </p>
              </div>
              <div className="bg-emerald-50 p-6 rounded-lg">
                <div className="bg-emerald-100 w-16 h-16 rounded-full flex items-center justify-center mb-4 mx-auto">
                  <Heart className="text-emerald-600" size={28} />
                </div>
                <h3 className="text-xl font-semibold text-center mb-3 text-emerald-800">Holistic Approach</h3>
                <p className="text-gray-700 text-center">
                  We combine physical fitness, nutrition, and mental wellbeing for a complete approach to health.
                </p>
              </div>
            </div>
            <div className="text-center mt-10">
              <Link
                to="/about"
                className="inline-block bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-6 rounded-md transition-colors"
              >
                Learn More About Us
              </Link>
            </div>
          </div>
        </motion.section>
      )}

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-emerald-800 mb-4">Our Services</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Discover our comprehensive range of services designed to help you achieve your health and fitness goals with a cultural touch.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-emerald-50 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="text-emerald-600 mb-4">
                <Utensils size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Ethiopian Nutrition Plans</h3>
              <p className="text-gray-700 mb-4">
                Customized meal plans featuring traditional Ethiopian foods with detailed nutritional information.
              </p>
              <Link to="/services" className="text-emerald-600 hover:text-emerald-700 font-medium">
                Learn More →
              </Link>
            </div>
            <div className="bg-emerald-50 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="text-emerald-600 mb-4">
                <Activity size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Fitness Programs</h3>
              <p className="text-gray-700 mb-4">
                Tailored workout routines for all fitness levels, from beginners to advanced athletes.
              </p>
              <Link to="/services" className="text-emerald-600 hover:text-emerald-700 font-medium">
                Learn More →
              </Link>
            </div>
            <div className="bg-emerald-50 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="text-emerald-600 mb-4">
                <Award size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-emerald-800">Health Education</h3>
              <p className="text-gray-700 mb-4">
                Educational resources on nutrition, fitness, and overall wellness with an Ethiopian perspective.
              </p>
              <Link to="/services" className="text-emerald-600 hover:text-emerald-700 font-medium">
                Learn More →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-emerald-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-emerald-800 mb-4">Success Stories</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Hear from our community members who have transformed their lives with Meri Ethiopian Fitness.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-emerald-200 rounded-full flex items-center justify-center text-emerald-700 font-bold text-xl">
                  A
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">Abebe T.</h4>
                  <p className="text-sm text-gray-500">Addis Ababa</p>
                </div>
              </div>
              <p className="text-gray-700">
                "The nutrition plans helped me understand how to balance my traditional Ethiopian diet with my fitness goals. I've lost 15kg in 6 months!"
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-emerald-200 rounded-full flex items-center justify-center text-emerald-700 font-bold text-xl">
                  M
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">Meron G.</h4>
                  <p className="text-sm text-gray-500">Bahir Dar</p>
                </div>
              </div>
              <p className="text-gray-700">
                "As a busy professional, the workout routines fit perfectly into my schedule. I love that they incorporate movements from Ethiopian dance!"
              </p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-emerald-200 rounded-full flex items-center justify-center text-emerald-700 font-bold text-xl">
                  T
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold">Tewodros B.</h4>
                  <p className="text-sm text-gray-500">Hawassa</p>
                </div>
              </div>
              <p className="text-gray-700">
                "The BMI calculator and personalized recommendations helped me understand my health better. Now I'm on track with both fitness and nutrition."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Start Your Fitness Journey?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Join Meri Ethiopian Fitness today and discover a healthier lifestyle with culturally relevant fitness and nutrition guidance.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Link
              to="/signup"
              className="bg-yellow-500 hover:bg-yellow-400 text-emerald-900 font-bold py-3 px-8 rounded-md transition-colors"
            >
              Sign Up Now
            </Link>
            <Link
              to="/contact"
              className="bg-transparent hover:bg-emerald-600 text-white font-semibold py-3 px-8 border border-white rounded-md transition-colors"
            >
              Contact Us
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;