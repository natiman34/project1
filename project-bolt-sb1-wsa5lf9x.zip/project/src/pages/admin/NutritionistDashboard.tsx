import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Utensils, Plus, Edit, Trash2, Search, Filter, Save, X } from 'lucide-react';

const NutritionistDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'mealPlans' | 'foods'>('mealPlans');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddingPlan, setIsAddingPlan] = useState(false);
  const [isEditingPlan, setIsEditingPlan] = useState<string | null>(null);
  
  // Mock data - in a real app, this would come from an API
  const mockMealPlans = [
    { 
      id: '1', 
      title: 'Ethiopian Weight Loss Meal Plan', 
      description: 'A balanced meal plan featuring Ethiopian dishes optimized for weight loss.',
      goal: 'Weight Loss',
      duration: '4 weeks',
      createdAt: '2023-05-15',
      updatedAt: '2023-06-22'
    },
    { 
      id: '2', 
      title: 'Muscle Building Ethiopian Diet', 
      description: 'High-protein meal options based on Ethiopian cuisine to support muscle growth.',
      goal: 'Muscle Gain',
      duration: '8 weeks',
      createdAt: '2023-04-10',
      updatedAt: '2023-07-05'
    },
    { 
      id: '3', 
      title: 'Balanced Ethiopian Family Nutrition', 
      description: 'Family-friendly meal plans that balance tradition with optimal nutrition.',
      goal: 'Overall Health',
      duration: 'Ongoing',
      createdAt: '2023-08-18',
      updatedAt: '2023-08-18'
    }
  ];
  
  const mockFoods = [
    { 
      id: '1', 
      name: 'Injera', 
      category: 'Staple',
      calories: 379,
      protein: 13,
      carbs: 80,
      fat: 1,
      description: 'Fermented flatbread made from teff flour'
    },
    { 
      id: '2', 
      name: 'Doro Wat', 
      category: 'Protein',
      calories: 450,
      protein: 35,
      carbs: 15,
      fat: 25,
      description: 'Spicy chicken stew with berbere spice'
    },
    { 
      id: '3', 
      name: 'Misir Wat', 
      category: 'Legume',
      calories: 250,
      protein: 18,
      carbs: 40,
      fat: 3,
      description: 'Red lentil stew with berbere and other spices'
    },
    { 
      id: '4', 
      name: 'Gomen', 
      category: 'Vegetable',
      calories: 100,
      protein: 5,
      carbs: 10,
      fat: 5,
      description: 'Collard greens sautéed with spices'
    },
    { 
      id: '5', 
      name: 'Kitfo', 
      category: 'Protein',
      calories: 320,
      protein: 30,
      carbs: 0,
      fat: 22,
      description: 'Minced raw beef seasoned with mitmita and niter kibbeh'
    }
  ];
  
  const filteredMealPlans = mockMealPlans.filter(plan => 
    plan.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
    plan.description.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const filteredFoods = mockFoods.filter(food => 
    food.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    food.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const [newPlan, setNewPlan] = useState({
    title: '',
    description: '',
    goal: '',
    duration: ''
  });

  const handleNewPlanChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewPlan(prev => ({ ...prev, [name]: value }));
  };

  const handleAddPlan = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would send data to an API
    console.log('Adding new plan:', newPlan);
    setIsAddingPlan(false);
    setNewPlan({
      title: '',
      description: '',
      goal: '',
      duration: ''
    });
  };

  const handleEditPlan = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would send data to an API
    console.log('Editing plan:', newPlan);
    setIsEditingPlan(null);
  };

  const startEditPlan = (planId: string) => {
    const planToEdit = mockMealPlans.find(plan => plan.id === planId);
    if (planToEdit) {
      setNewPlan({
        title: planToEdit.title,
        description: planToEdit.description,
        goal: planToEdit.goal,
        duration: planToEdit.duration
      });
      setIsEditingPlan(planId);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Dashboard Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-emerald-800">Nutritionist Dashboard</h1>
            <div className="flex items-center">
              <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                <span className="font-semibold text-emerald-700">N</span>
              </div>
              <span className="ml-2 font-medium">Nutritionist</span>
            </div>
          </div>
        </div>
      </header>

      {/* Dashboard Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow overflow-hidden">
          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex">
              <button
                onClick={() => setActiveTab('mealPlans')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'mealPlans'
                    ? 'border-b-2 border-emerald-500 text-emerald-600'
                    : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Meal Plans
              </button>
              <button
                onClick={() => setActiveTab('foods')}
                className={`px-6 py-4 text-sm font-medium ${
                  activeTab === 'foods'
                    ? 'border-b-2 border-emerald-500 text-emerald-600'
                    : 'text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Ethiopian Foods
              </button>
            </nav>
          </div>

          {/* Meal Plans Tab */}
          {activeTab === 'mealPlans' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                <div className="flex flex-col sm:flex-row justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">Manage Meal Plans</h3>
                  <div className="mt-3 sm:mt-0 flex items-center">
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={18} className="text-gray-400" />
                      </div>
                      <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="focus:ring-emerald-500 focus:border-emerald-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                        placeholder="Search meal plans"
                      />
                    </div>
                    <button 
                      onClick={() => setIsAddingPlan(true)}
                      className="ml-3 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
                    >
                      <Plus size={16} className="mr-2" />
                      Add Plan
                    </button>
                  </div>
                </div>
              </div>

              {/* Add/Edit Meal Plan Form */}
              {(isAddingPlan || isEditingPlan) && (
                <div className="px-4 py-5 sm:px-6 border-b border-gray-200 bg-gray-50">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {isAddingPlan ? 'Add New Meal Plan' : 'Edit Meal Plan'}
                  </h3>
                  <form onSubmit={isAddingPlan ? handleAddPlan : handleEditPlan} className="space-y-4">
                    <div className="grid grid-cols-1 gap-y-4 gap-x-4 sm:grid-cols-6">
                      <div className="sm:col-span-3">
                        <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                          Title
                        </label>
                        <input
                          type="text"
                          name="title"
                          id="title"
                          value={newPlan.title}
                          onChange={handleNewPlanChange}
                          required
                          className="mt-1 focus:ring-emerald-500 focus:border-emerald-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        />
                      </div>
                      <div className="sm:col-span-3">
                        <label htmlFor="goal" className="block text-sm font-medium text-gray-700">
                          Goal
                        </label>
                        <select
                          id="goal"
                          name="goal"
                          value={newPlan.goal}
                          onChange={handleNewPlanChange}
                          required
                          className="mt-1 block w-full py-2 px-3 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-emerald-500 focus:border-emerald-500 sm:text-sm"
                        >
                          <option value="">Select a goal</option>
                          <option value="Weight Loss">Weight Loss</option>
                          <option value="Muscle Gain">Muscle Gain</option>
                          <option value="Overall Health">Overall Health</option>
                          <option value="Athletic Performance">Athletic Performance</option>
                        </select>
                      </div>
                      <div className="sm:col-span-3">
                        <label htmlFor="duration" className="block text-sm font-medium text-gray-700">
                          Duration
                        </label>
                        <input
                          type="text"
                          name="duration"
                          id="duration"
                          value={newPlan.duration}
                          onChange={handleNewPlanChange}
                          required
                          placeholder="e.g., 4 weeks, Ongoing"
                          className="mt-1 focus:ring-emerald-500 focus:border-emerald-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        />
                      </div>
                      <div className="sm:col-span-6">
                        <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                          Description
                        </label>
                        <textarea
                          id="description"
                          name="description"
                          rows={3}
                          value={newPlan.description}
                          onChange={handleNewPlanChange}
                          required
                          className="mt-1 focus:ring-emerald-500 focus:border-emerald-500 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end space-x-3">
                      <button
                        type="button"
                        onClick={() => {
                          setIsAddingPlan(false);
                          setIsEditingPlan(null);
                        }}
                        className="inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
                      >
                        <X size={16} className="mr-2" />
                        Cancel
                      </button>
                      <button
                        type="submit"
                        className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
                      >
                        <Save size={16} className="mr-2" />
                        {isAddingPlan ? 'Add Plan' : 'Save Changes'}
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* Meal Plans List */}
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Title
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Goal
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Duration
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Last Updated
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredMealPlans.map((plan) => (
                      <tr key={plan.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 bg-emerald-100 rounded-full flex items-center justify-center">
                              <Utensils className="h-5 w-5 text-emerald-600" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{plan.title}</div>
                              <div className="text-sm text-gray-500">{plan.description}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-emerald-100 text-emerald-800">
                            {plan.goal}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {plan.duration}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {plan.updatedAt}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button 
                            onClick={() => startEditPlan(plan.id)}
                            className="text-emerald-600 hover:text-emerald-900 mr-3"
                          >
                            <Edit size={18} />
                          </button>
                          <button className="text-red-600 hover:text-red-900">
                            <Trash2 size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {/* Foods Tab */}
          {activeTab === 'foods' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                <div className="flex flex-col sm:flex-row justify-between items-center">
                  <h3 className="text-lg font-medium text-gray-900">Ethiopian Foods Database</h3>
                  <div className="mt-3 sm:mt-0 flex items-center">
                    <div className="relative rounded-md shadow-sm">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <Search size={18} className="text-gray-400" />
                      </div>
                      <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="focus:ring-emerald-500 focus:border-emerald-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
                        placeholder="Search foods"
                      />
                    </div>
                    <div className="ml-3">
                      <button className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500">
                        <Filter size={16} className="mr-2" />
                        Filter
                      </button>
                    </div>
                    <button className="ml-3 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500">
                      <Plus size={16} className="mr-2" />
                      Add Food
                    </button>
                  </div>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Food
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Category
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Calories
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Macros (g)
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredFoods.map((food) => (
                      <tr key={food.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 bg-emerald-100 rounded-full flex items-center justify-center">
                              <Utensils className="h-5 w-5 text-emerald-600" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{food.name}</div>
                              <div className="text-sm text-gray-500">{food.description}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-emerald-100 text-emerald-800">
                            {food.category}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {food.calories} kcal
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          <div className="flex space-x-2">
                            <span className="px-2 py-1 text-xs rounded bg-blue-100 text-blue-800">P: {food.protein}g</span>
                            <span className="px-2 py-1 text-xs rounded bg-yellow-100 text-yellow-800">C: {food.carbs}g</span>
                            <span className="px-2 py-1 text-xs rounded bg-red-100 text-red-800">F: {food.fat}g</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button className="text-emerald-600 hover:text-emerald-900 mr-3">
                            <Edit size={18} />
                          </button>
                          <button className="text-red-600 hover:text-red-900">
                            <Trash2 size={18} />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}
        </div>

        {/* Nutritional Tips Section */}
        <div className="mt-8 bg-white rounded-lg shadow overflow-hidden">
          <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
            <h3 className="text-lg font-medium text-gray-900">Nutritional Tips</h3>
            <p className="mt-1 text-sm text-gray-500">
              Create and manage nutritional tips to be displayed on the website.
            </p>
          </div>
          <div className="p-6">
            <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <p className="text-sm text-yellow-700">
                    Tips are displayed in the Educational Tips section of the Services page.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="border border-gray-200 rounded-md p-4">
                <h4 className="font-medium text-gray-900">The Health Benefits of Ethiopian Spices</h4>
                <p className="mt-1 text-sm text-gray-500">
                  Ethiopian cuisine is known for its complex spice blends, many of which offer significant health benefits. Berbere, a staple spice blend, contains paprika, fenugreek, and other spices with anti-inflammatory properties.
                </p>
                <div className="mt-2 flex justify-end space-x-2">
                  <button className="text-emerald-600 hover:text-emerald-900">
                    <Edit size={16} />
                  </button>
                  <button className="text-red-600 hover:text-red-900">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              
              <div className="border border-gray-200 rounded-md p-4">
                <h4 className="font-medium text-gray-900">Nutritional Benefits of Teff</h4>
                <p className="mt-1 text-sm text-gray-500">
                  Teff, the tiny grain used to make injera, is a nutritional powerhouse. It's high in protein, fiber, and minerals like iron and calcium. As a complex carbohydrate, it provides sustained energy for workouts and daily activities.
                </p>
                <div className="mt-2 flex justify-end space-x-2">
                  <button className="text-emerald-600 hover:text-emerald-900">
                    <Edit size={16} />
                  </button>
                  <button className="text-red-600 hover:text-red-900">
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              
              <div className="mt-4">
                <button className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500">
                  <Plus size={16} className="mr-2" />
                  Add New Tip
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default NutritionistDashboard;