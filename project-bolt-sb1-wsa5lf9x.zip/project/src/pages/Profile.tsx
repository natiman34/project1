import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, Calculator, Edit2, Save, X } from 'lucide-react';
import { useUser } from '../contexts/UserContext';

const Profile: React.FC = () => {
  const { user, updateUser, logout } = useUser();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser(formData);
    setIsEditing(false);
  };

  const cancelEdit = () => {
    setFormData({
      name: user?.name || '',
      email: user?.email || ''
    });
    setIsEditing(false);
  };

  return (
    <div className="bg-emerald-50 min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-emerald-700 text-white py-16">
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/6551096/pexels-photo-6551096.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center opacity-20"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-3xl">
            <motion.h1 
              className="text-4xl md:text-5xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Your Profile
            </motion.h1>
            <motion.p 
              className="text-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              Manage your account and view your health information.
            </motion.p>
          </div>
        </div>
      </section>

      {/* Profile Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Profile Card */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-lg shadow-sm p-8">
                <div className="text-center mb-6">
                  <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <User size={40} className="text-emerald-600" />
                  </div>
                  <h2 className="text-2xl font-bold text-emerald-800">{user?.name}</h2>
                  <p className="text-gray-600">{user?.role.charAt(0).toUpperCase() + user?.role.slice(1)}</p>
                </div>

                {isEditing ? (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                        Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                        Email
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-emerald-500 focus:border-emerald-500"
                      />
                    </div>
                    <div className="flex space-x-2">
                      <button
                        type="submit"
                        className="flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
                      >
                        <Save size={16} className="mr-2" />
                        Save
                      </button>
                      <button
                        type="button"
                        onClick={cancelEdit}
                        className="flex items-center justify-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
                      >
                        <X size={16} className="mr-2" />
                        Cancel
                      </button>
                    </div>
                  </form>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center">
                      <Mail size={20} className="text-emerald-600 mr-3" />
                      <div>
                        <p className="text-sm text-gray-500">Email</p>
                        <p className="text-gray-800">{user?.email}</p>
                      </div>
                    </div>
                    {user?.bmiResult && (
                      <div className="flex items-center">
                        <Calculator size={20} className="text-emerald-600 mr-3" />
                        <div>
                          <p className="text-sm text-gray-500">BMI</p>
                          <p className="text-gray-800">{user.bmiResult}</p>
                        </div>
                      </div>
                    )}
                    <button
                      onClick={() => setIsEditing(true)}
                      className="flex items-center justify-center w-full px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500 mt-4"
                    >
                      <Edit2 size={16} className="mr-2" />
                      Edit Profile
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-2">
              {/* Health Summary */}
              <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
                <h3 className="text-xl font-semibold mb-6 text-emerald-800 border-b border-gray-200 pb-2">Health Summary</h3>
                
                {user?.bmiResult ? (
                  <div>
                    <div className="mb-6">
                      <h4 className="font-medium text-gray-700 mb-2">Your BMI</h4>
                      <div className="bg-emerald-50 p-4 rounded-md">
                        <p className="text-gray-700 mb-2">
                          Current BMI: <span className="font-bold text-emerald-700">{user.bmiResult}</span>
                        </p>
                        <p className="text-gray-700">
                          Category: <span className="font-bold text-emerald-700">
                            {user.bmiResult < 18.5 ? 'Underweight' : 
                             user.bmiResult < 25 ? 'Normal weight' : 
                             user.bmiResult < 30 ? 'Overweight' : 'Obesity'}
                          </span>
                        </p>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-medium text-gray-700 mb-2">Recommendations</h4>
                      <ul className="space-y-2 text-gray-700">
                        {user.bmiResult < 18.5 ? (
                          <>
                            <li className="flex items-start">
                              <span className="text-emerald-600 mr-2">•</span>
                              <span>Focus on nutrient-dense Ethiopian foods like doro wot and kitfo</span>
                            </li>
                            <li className="flex items-start">
                              <span className="text-emerald-600 mr-2">•</span>
                              <span>Incorporate strength training to build muscle mass</span>
                            </li>
                          </>
                        ) : user.bmiResult < 25 ? (
                          <>
                            <li className="flex items-start">
                              <span className="text-emerald-600 mr-2">•</span>
                              <span>Maintain your balanced diet with traditional Ethiopian meals</span>
                            </li>
                            <li className="flex items-start">
                              <span className="text-emerald-600 mr-2">•</span>
                              <span>Continue with regular physical activity</span>
                            </li>
                          </>
                        ) : (
                          <>
                            <li className="flex items-start">
                              <span className="text-emerald-600 mr-2">•</span>
                              <span>Focus on vegetable-based Ethiopian wots and control portions</span>
                            </li>
                            <li className="flex items-start">
                              <span className="text-emerald-600 mr-2">•</span>
                              <span>Increase cardio activity with our Ethiopian dance workouts</span>
                            </li>
                          </>
                        )}
                        <li className="flex items-start">
                          <span className="text-emerald-600 mr-2">•</span>
                          <span>Check out our personalized meal and fitness plans</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calculator size={40} className="mx-auto text-emerald-400 mb-4" />
                    <p className="text-gray-600 mb-4">You haven't calculated your BMI yet.</p>
                    <a
                      href="/bmi"
                      className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-emerald-600 hover:bg-emerald-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
                    >
                      Calculate BMI
                    </a>
                  </div>
                )}
              </div>
              
              {/* Recommended Plans */}
              <div className="bg-white rounded-lg shadow-sm p-8">
                <h3 className="text-xl font-semibold mb-6 text-emerald-800 border-b border-gray-200 pb-2">Recommended Plans</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <h4 className="font-semibold text-emerald-700 mb-2">Ethiopian Weight Management</h4>
                    <p className="text-gray-600 text-sm mb-3">
                      A 4-week program featuring traditional Ethiopian foods optimized for your health goals.
                    </p>
                    <a
                      href="/services"
                      className="text-emerald-600 hover:text-emerald-700 text-sm font-medium"
                    >
                      View Details →
                    </a>
                  </div>
                  
                  <div className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <h4 className="font-semibold text-emerald-700 mb-2">Habesha Fitness Routine</h4>
                    <p className="text-gray-600 text-sm mb-3">
                      Workout routines inspired by Ethiopian dance and movement traditions.
                    </p>
                    <a
                      href="/services"
                      className="text-emerald-600 hover:text-emerald-700 text-sm font-medium"
                    >
                      View Details →
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Account Settings */}
      <section className="py-8 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-xl font-semibold mb-6 text-emerald-800 border-b border-gray-200 pb-2">Account Settings</h3>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-b border-gray-100">
                <div>
                  <h4 className="font-medium text-gray-800">Password</h4>
                  <p className="text-sm text-gray-500">Update your password</p>
                </div>
                <button className="text-emerald-600 hover:text-emerald-700 text-sm font-medium">
                  Change
                </button>
              </div>
              
              <div className="flex justify-between items-center py-3 border-b border-gray-100">
                <div>
                  <h4 className="font-medium text-gray-800">Notifications</h4>
                  <p className="text-sm text-gray-500">Manage your notification preferences</p>
                </div>
                <button className="text-emerald-600 hover:text-emerald-700 text-sm font-medium">
                  Manage
                </button>
              </div>
              
              <div className="flex justify-between items-center py-3">
                <div>
                  <h4 className="font-medium text-gray-800">Delete Account</h4>
                  <p className="text-sm text-gray-500">Permanently delete your account and all data</p>
                </div>
                <button className="text-red-600 hover:text-red-700 text-sm font-medium">
                  Delete
                </button>
              </div>
            </div>
            
            <div className="mt-8 pt-6 border-t border-gray-200">
              <button
                onClick={logout}
                className="w-full sm:w-auto px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-emerald-500"
              >
                Log Out
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Profile;